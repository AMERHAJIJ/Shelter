import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/Login';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import Shelters from './components/Shelters';
import Capacity from './components/Capacity';
import Emergency from './components/Emergency';
import QRLogs from './components/QRLogs';
import Families from './components/Families';
import Unregistered from './components/Unregistered';
import Resources from './components/Resources';
import Notifications from './components/Notifications';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
}

function AppRoutes() {
  const { isAuthenticated } = useAuth();
  
  return (
    <Routes>
      <Route path="/login" element={
        isAuthenticated ? <Navigate to="/" replace /> : <Login />
      } />
      <Route path="/" element={
        <ProtectedRoute>
          <Layout>
            <Dashboard />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/shelters" element={
        <ProtectedRoute>
          <Layout>
            <Shelters />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/capacity" element={
        <ProtectedRoute>
          <Layout>
            <Capacity />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/emergency" element={
        <ProtectedRoute>
          <Layout>
            <Emergency />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/qr-logs" element={
        <ProtectedRoute>
          <Layout>
            <QRLogs />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/families" element={
        <ProtectedRoute>
          <Layout>
            <Families />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/unregistered" element={
        <ProtectedRoute>
          <Layout>
            <Unregistered />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/resources" element={
        <ProtectedRoute>
          <Layout>
            <Resources />
          </Layout>
        </ProtectedRoute>
      } />
      <Route path="/notifications" element={
        <ProtectedRoute>
          <Layout>
            <Notifications />
          </Layout>
        </ProtectedRoute>
      } />
    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <LanguageProvider>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </LanguageProvider>
    </Router>
  );
}
