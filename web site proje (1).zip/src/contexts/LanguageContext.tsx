import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'tr' | 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations: Record<Language, Record<string, string>> = {
  tr: {
    // Login
    'admin_panel': 'Yönetim Paneli',
    'shelter_system': 'Barınak Yönetim Sistemi',
    'account_type': 'Hesap Türü',
    'admin': 'Admin',
    'staff': 'Staff',
    'username': 'Kullanıcı Adı',
    'password': 'Şifre',
    'login': 'Giriş Yap',
    'demo_note': 'Demo: admin/123456 veya staff/123456',
    
    // Dashboard
    'dashboard': 'Kontrol Paneli',
    'welcome': 'Hoş Geldiniz',
    'central_admin': 'Merkezi Yönetici',
    'shelter_staff': 'Barınak Personeli',
    'total_people': 'Toplam Kişi',
    'total_shelters': 'Toplam Barınak',
    'emergency_requests': 'Acil Talepler',
    'capacity_usage': 'Kapasite Kullanımı',
    'emergency_summary': 'Acil Durum Özeti',
    'shelters_status': 'Barınak Durumu',
    'main_shelter': 'Ana Barınak',
    'small_shelter': 'Küçük Barınak',
    'open': 'Açık',
    'closed': 'Kapalı',
    'full': 'Dolu',
    
    // Shelters
    'shelter_management': 'Barınak Yönetimi',
    'manage_shelters_desc': 'Sistemdeki tüm barınakları yönetin',
    'add_shelter': 'Yeni Barınak',
    'shelter_name': 'Barınak Adı',
    'location': 'Konum',
    'type': 'Tür',
    'status': 'Durum',
    'capacity': 'Kapasite',
    'actions': 'İşlemler',
    'main': 'Ana',
    'small': 'Küçük',
    'linked_to': 'Bağlı',
    
    // Capacity
    'capacity_management': 'Kapasite Yönetimi',
    'capacity_desc': 'Barınak bölümleri ve kapasiteleri',
    'total_capacity': 'Toplam Kapasite',
    'occupied': 'Dolu',
    'available': 'Boş',
    'usage': 'Kullanım',
    'overall_occupancy': 'Genel Doluluk',
    'auto_update_qr': 'QR tarama ile otomatik güncellenir',
    'sections': 'Bölümler',
    'families': 'Aileler',
    'individuals': 'Bireyler',
    'children': 'Çocuklar',
    'special_needs': 'Özel İhtiyaç',
    'unregistered': 'Kayıtsız',
    'current': 'Mevcut',
    'max': 'Maksimum',
    'update': 'Güncelle',
    
    // Emergency
    'emergency_management': 'Acil Durum Talepleri',
    'emergency_desc': 'Tüm acil durum çağrılarını yönetin',
    'all': 'Tümü',
    'new': 'Yeni',
    'in_progress': 'Devam Eden',
    'completed': 'Tamamlandı',
    'sos': 'SOS',
    'ambulance': 'Ambulans',
    'transfer': 'Transfer',
    'high': 'Yüksek',
    'medium': 'Orta',
    'low': 'Düşük',
    'call': 'Ara',
    'navigate': 'Yol Tarifi',
    'start': 'Başlat',
    'complete': 'Tamamla',
    
    // QR Logs
    'qr_logs': 'QR Giriş/Çıkış Kayıtları',
    'qr_logs_desc': 'Tüm QR tarama kayıtlarını izleyin',
    'entry': 'Giriş',
    'exit': 'Çıkış',
    'net_change': 'Net Değişim',
    'people_count': 'Kişi Sayısı',
    'time': 'Zaman',
    
    // Families
    'family_management': 'Aile Yönetimi',
    'family_desc': 'Aileleri bir arada tutun',
    'total_families': 'Toplam Aile',
    'all_arrived': 'Hepsi Geldi',
    'partial': 'Kısmi',
    'scattered': 'Dağınık',
    'members_arrived': 'Üye Geldi',
    'all_together': 'Hep Birlikte',
    'separated': 'Ayrılmış',
    'incomplete': 'Eksik',
    
    // Unregistered
    'unregistered_management': 'Kayıtsız Kişi Yönetimi',
    'unregistered_desc': 'Kayıtsız gelen kişileri sisteme ekleyin',
    'add_record': 'Yeni Kayıt Ekle',
    'select_shelter': 'Barınak Seçin',
    'people_count_label': 'Kişi Sayısı',
    'notes': 'Notlar',
    'save': 'Kaydet',
    'cancel': 'İptal',
    'recent_entries': 'Son Kayıtlar',
    
    // Resources
    'resource_management': 'Kaynak Yönetimi',
    'resource_desc': 'Barınaklardaki kaynakları takip edin',
    'critical_shelters': 'Kritik Barınaklar',
    'water': 'Su',
    'medicine': 'İlaç',
    'blankets': 'Battaniye',
    'food': 'Yemek',
    'sufficient': 'Yeterli',
    'depleted': 'Tükendi',
    'request': 'Talep Et',
    'good': 'İyi',
    'critical': 'Kritik',
    
    // Notifications
    'notification_management': 'Bildirim Yönetimi',
    'notification_desc': 'Kullanıcılara bildirim gönderin',
    'total_sent': 'Gönderilen',
    'today': 'Bugün',
    'recipients': 'Alıcılar',
    'send_notification': 'Yeni Bildirim Gönder',
    'notification_type': 'Bildirim Türü',
    'shelter_opened': 'Barınak Açıldı',
    'shelter_closed': 'Barınak Kapandı',
    'earthquake': 'Deprem',
    'instruction': 'Talimat',
    'title': 'Başlık',
    'message': 'Mesaj',
    'region': 'Bölge',
    'target': 'Hedef',
    'send': 'Gönder',
    'recent_notifications': 'Son Bildirimler',
    'sent': 'Gönderildi',
    
    // Common
    'logout': 'Çıkış',
    'settings': 'Ayarlar',
    'ago': 'önce',
    'min': 'dk',
    'hour': 'saat',
  },
  en: {
    // Login
    'admin_panel': 'Admin Panel',
    'shelter_system': 'Shelter Management System',
    'account_type': 'Account Type',
    'admin': 'Admin',
    'staff': 'Staff',
    'username': 'Username',
    'password': 'Password',
    'login': 'Login',
    'demo_note': 'Demo: admin/123456 or staff/123456',
    
    // Dashboard
    'dashboard': 'Dashboard',
    'welcome': 'Welcome',
    'central_admin': 'Central Administrator',
    'shelter_staff': 'Shelter Staff',
    'total_people': 'Total People',
    'total_shelters': 'Total Shelters',
    'emergency_requests': 'Emergency Requests',
    'capacity_usage': 'Capacity Usage',
    'emergency_summary': 'Emergency Summary',
    'shelters_status': 'Shelters Status',
    'main_shelter': 'Main Shelter',
    'small_shelter': 'Small Shelter',
    'open': 'Open',
    'closed': 'Closed',
    'full': 'Full',
    
    // Shelters
    'shelter_management': 'Shelter Management',
    'manage_shelters_desc': 'Manage all shelters in the system',
    'add_shelter': 'Add Shelter',
    'shelter_name': 'Shelter Name',
    'location': 'Location',
    'type': 'Type',
    'status': 'Status',
    'capacity': 'Capacity',
    'actions': 'Actions',
    'main': 'Main',
    'small': 'Small',
    'linked_to': 'Linked to',
    
    // Capacity
    'capacity_management': 'Capacity Management',
    'capacity_desc': 'Shelter sections and capacities',
    'total_capacity': 'Total Capacity',
    'occupied': 'Occupied',
    'available': 'Available',
    'usage': 'Usage',
    'overall_occupancy': 'Overall Occupancy',
    'auto_update_qr': 'Auto-updated via QR scanning',
    'sections': 'Sections',
    'families': 'Families',
    'individuals': 'Individuals',
    'children': 'Children',
    'special_needs': 'Special Needs',
    'unregistered': 'Unregistered',
    'current': 'Current',
    'max': 'Maximum',
    'update': 'Update',
    
    // Emergency
    'emergency_management': 'Emergency Requests',
    'emergency_desc': 'Manage all emergency calls',
    'all': 'All',
    'new': 'New',
    'in_progress': 'In Progress',
    'completed': 'Completed',
    'sos': 'SOS',
    'ambulance': 'Ambulance',
    'transfer': 'Transfer',
    'high': 'High',
    'medium': 'Medium',
    'low': 'Low',
    'call': 'Call',
    'navigate': 'Navigate',
    'start': 'Start',
    'complete': 'Complete',
    
    // QR Logs
    'qr_logs': 'QR Entry/Exit Logs',
    'qr_logs_desc': 'Track all QR scan records',
    'entry': 'Entry',
    'exit': 'Exit',
    'net_change': 'Net Change',
    'people_count': 'People Count',
    'time': 'Time',
    
    // Families
    'family_management': 'Family Management',
    'family_desc': 'Keep families together',
    'total_families': 'Total Families',
    'all_arrived': 'All Arrived',
    'partial': 'Partial',
    'scattered': 'Scattered',
    'members_arrived': 'Members Arrived',
    'all_together': 'All Together',
    'separated': 'Separated',
    'incomplete': 'Incomplete',
    
    // Unregistered
    'unregistered_management': 'Unregistered Management',
    'unregistered_desc': 'Add unregistered people to the system',
    'add_record': 'Add New Record',
    'select_shelter': 'Select Shelter',
    'people_count_label': 'People Count',
    'notes': 'Notes',
    'save': 'Save',
    'cancel': 'Cancel',
    'recent_entries': 'Recent Entries',
    
    // Resources
    'resource_management': 'Resource Management',
    'resource_desc': 'Track shelter resources',
    'critical_shelters': 'Critical Shelters',
    'water': 'Water',
    'medicine': 'Medicine',
    'blankets': 'Blankets',
    'food': 'Food',
    'sufficient': 'Sufficient',
    'depleted': 'Depleted',
    'request': 'Request',
    'good': 'Good',
    'critical': 'Critical',
    
    // Notifications
    'notification_management': 'Notification Management',
    'notification_desc': 'Send notifications to users',
    'total_sent': 'Total Sent',
    'today': 'Today',
    'recipients': 'Recipients',
    'send_notification': 'Send New Notification',
    'notification_type': 'Notification Type',
    'shelter_opened': 'Shelter Opened',
    'shelter_closed': 'Shelter Closed',
    'earthquake': 'Earthquake',
    'instruction': 'Instruction',
    'title': 'Title',
    'message': 'Message',
    'region': 'Region',
    'target': 'Target',
    'send': 'Send',
    'recent_notifications': 'Recent Notifications',
    'sent': 'Sent',
    
    // Common
    'logout': 'Logout',
    'settings': 'Settings',
    'ago': 'ago',
    'min': 'min',
    'hour': 'hour',
  },
  ar: {
    // Login
    'admin_panel': 'لوحة الإدارة',
    'shelter_system': 'نظام إدارة الملاجئ',
    'account_type': 'نوع الحساب',
    'admin': 'مدير',
    'staff': 'موظف',
    'username': 'اسم المستخدم',
    'password': 'كلمة المرور',
    'login': 'تسجيل الدخول',
    'demo_note': 'تجريبي: admin/123456 أو staff/123456',
    
    // Dashboard
    'dashboard': 'لوحة التحكم',
    'welcome': 'مرحباً',
    'central_admin': 'مدير مركزي',
    'shelter_staff': 'موظف ملجأ',
    'total_people': 'إجمالي الأشخاص',
    'total_shelters': 'إجمالي الملاجئ',
    'emergency_requests': 'طلبات الطوارئ',
    'capacity_usage': 'استخدام السعة',
    'emergency_summary': 'ملخص الطوارئ',
    'shelters_status': 'حالة الملاجئ',
    'main_shelter': 'ملجأ رئيسي',
    'small_shelter': 'ملجأ صغير',
    'open': 'مفتوح',
    'closed': 'مغلق',
    'full': 'ممتلئ',
    
    // Shelters
    'shelter_management': 'إدارة الملاجئ',
    'manage_shelters_desc': 'إدارة جميع الملاجئ في النظام',
    'add_shelter': 'إضافة ملجأ',
    'shelter_name': 'اسم الملجأ',
    'location': 'الموقع',
    'type': 'النوع',
    'status': 'الحالة',
    'capacity': 'السعة',
    'actions': 'الإجراءات',
    'main': 'رئيسي',
    'small': 'صغير',
    'linked_to': 'مرتبط بـ',
    
    // Capacity
    'capacity_management': 'إدارة السعة',
    'capacity_desc': 'أقسام الملجأ والسعات',
    'total_capacity': 'السعة الإجمالية',
    'occupied': 'مشغول',
    'available': 'متاح',
    'usage': 'الاستخدام',
    'overall_occupancy': 'الإشغال الإجمالي',
    'auto_update_qr': 'يتم التحديث تلقائياً عبر مسح QR',
    'sections': 'الأقسام',
    'families': 'عائلات',
    'individuals': 'أفراد',
    'children': 'أطفال',
    'special_needs': 'احتياجات خاصة',
    'unregistered': 'غير مسجلين',
    'current': 'الحالي',
    'max': 'الأقصى',
    'update': 'تحديث',
    
    // Emergency
    'emergency_management': 'طلبات الطوارئ',
    'emergency_desc': 'إدارة جميع مكالمات الطوارئ',
    'all': 'الكل',
    'new': 'جديد',
    'in_progress': 'قيد التنفيذ',
    'completed': 'مكتمل',
    'sos': 'SOS',
    'ambulance': 'إسعاف',
    'transfer': 'نقل',
    'high': 'عالي',
    'medium': 'متوسط',
    'low': 'منخفض',
    'call': 'اتصال',
    'navigate': 'التنقل',
    'start': 'بدء',
    'complete': 'إنهاء',
    
    // QR Logs
    'qr_logs': 'سجلات الدخول/الخروج QR',
    'qr_logs_desc': 'تتبع جميع سجلات مسح QR',
    'entry': 'دخول',
    'exit': 'خروج',
    'net_change': 'التغيير الصافي',
    'people_count': 'عدد الأشخاص',
    'time': 'الوقت',
    
    // Families
    'family_management': 'إدارة العائلات',
    'family_desc': 'إبقاء العائلات معاً',
    'total_families': 'إجمالي العائلات',
    'all_arrived': 'وصل الجميع',
    'partial': 'جزئي',
    'scattered': 'متفرقون',
    'members_arrived': 'أفراد وصلوا',
    'all_together': 'معاً',
    'separated': 'منفصلون',
    'incomplete': 'غير مكتمل',
    
    // Unregistered
    'unregistered_management': 'إدارة غير المسجلين',
    'unregistered_desc': 'إضافة الأشخاص غير المسجلين للنظام',
    'add_record': 'إضافة سجل جديد',
    'select_shelter': 'اختر الملجأ',
    'people_count_label': 'عدد الأشخاص',
    'notes': 'ملاحظات',
    'save': 'حفظ',
    'cancel': 'إلغاء',
    'recent_entries': 'الإدخالات الأخيرة',
    
    // Resources
    'resource_management': 'إدارة الموارد',
    'resource_desc': 'تتبع موارد الملاجئ',
    'critical_shelters': 'ملاجئ حرجة',
    'water': 'ماء',
    'medicine': 'دواء',
    'blankets': 'بطانيات',
    'food': 'طعام',
    'sufficient': 'كافي',
    'depleted': 'نفد',
    'request': 'طلب',
    'good': 'جيد',
    'critical': 'حرج',
    
    // Notifications
    'notification_management': 'إدارة الإشعارات',
    'notification_desc': 'إرسال إشعارات للمستخدمين',
    'total_sent': 'إجمالي المُرسل',
    'today': 'اليوم',
    'recipients': 'المستلمون',
    'send_notification': 'إرسال إشعار جديد',
    'notification_type': 'نوع الإشعار',
    'shelter_opened': 'فتح ملجأ',
    'shelter_closed': 'إغلاق ملجأ',
    'earthquake': 'زلزال',
    'instruction': 'تعليمات',
    'title': 'العنوان',
    'message': 'الرسالة',
    'region': 'المنطقة',
    'target': 'الهدف',
    'send': 'إرسال',
    'recent_notifications': 'الإشعارات الأخيرة',
    'sent': 'تم الإرسال',
    
    // Common
    'logout': 'تسجيل خروج',
    'settings': 'الإعدادات',
    'ago': 'منذ',
    'min': 'دقيقة',
    'hour': 'ساعة',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('tr');
  
  const t = (key: string): string => {
    return translations[language][key] || key;
  };
  
  const isRTL = language === 'ar';
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      <div dir={isRTL ? 'rtl' : 'ltr'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}
