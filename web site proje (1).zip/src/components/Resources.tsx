import { Droplet, Pill, BedDouble, Apple, Building2, Plus } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Resources() {
  const { t } = useLanguage();
  
  const shelters = [
    {
      id: 1,
      name: 'Merkez Kadıköy',
      status: 'critical',
      resources: [
        { type: 'water', current: 500, min: 200, icon: Droplet, color: 'blue' },
        { type: 'medicine', current: 50, min: 100, icon: Pill, color: 'red' },
        { type: 'blankets', current: 10, min: 150, icon: BedDouble, color: 'purple' },
        { type: 'food', current: 300, min: 200, icon: Apple, color: 'green' },
      ],
    },
    {
      id: 2,
      name: 'Beşiktaş Spor Salonu',
      status: 'good',
      resources: [
        { type: 'water', current: 800, min: 300, icon: Droplet, color: 'blue' },
        { type: 'medicine', current: 150, min: 100, icon: Pill, color: 'red' },
        { type: 'blankets', current: 200, min: 150, icon: BedDouble, color: 'purple' },
        { type: 'food', current: 400, min: 250, icon: Apple, color: 'green' },
      ],
    },
  ];
  
  const totalResources = 4;
  const criticalShelters = shelters.filter(s => s.status === 'critical').length;
  const totalWater = shelters.reduce((sum, s) => 
    sum + (s.resources.find(r => r.type === 'water')?.current || 0), 0
  );
  const totalMedicine = shelters.reduce((sum, s) => 
    sum + (s.resources.find(r => r.type === 'medicine')?.current || 0), 0
  );
  
  const getResourceStatus = (current: number, min: number) => {
    const percent = (current / min) * 100;
    if (percent >= 100) return { label: t('sufficient'), color: 'green', percent };
    if (percent >= 50) return { label: 'Low', color: 'orange', percent };
    return { label: t('depleted'), color: 'red', percent };
  };
  
  const getProgressColor = (percent: number) => {
    if (percent >= 100) return 'bg-green-500';
    if (percent >= 50) return 'bg-orange-500';
    return 'bg-red-500';
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'good':
        return <span className="px-4 py-2 bg-green-100 text-green-700 text-sm font-semibold rounded-full">✓ {t('good')}</span>;
      case 'critical':
        return <span className="px-4 py-2 bg-orange-100 text-orange-700 text-sm font-semibold rounded-full">⚠️ {t('critical')}</span>;
      default:
        return null;
    }
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('resource_management')}</h1>
        <p className="text-gray-600">{t('resource_desc')}</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">Total Resources</div>
          <div className="text-3xl font-bold text-gray-900">{totalResources}</div>
        </div>
        <div className="bg-orange-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-orange-600 mb-2">{t('critical_shelters')}</div>
          <div className="text-3xl font-bold text-orange-700">{criticalShelters}</div>
        </div>
        <div className="bg-blue-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-blue-600 mb-2">{t('water')} Total</div>
          <div className="text-3xl font-bold text-blue-700">{totalWater}</div>
        </div>
        <div className="bg-red-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-red-600 mb-2">{t('medicine')} Total</div>
          <div className="text-3xl font-bold text-red-700">{totalMedicine}</div>
        </div>
      </div>
      
      {/* Shelters List */}
      <div className="space-y-6">
        {shelters.map((shelter) => (
          <div 
            key={shelter.id} 
            className={`bg-white rounded-2xl shadow-lg p-6 border-2 ${
              shelter.status === 'critical' ? 'border-orange-300' : 'border-gray-200'
            }`}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Building2 className="w-6 h-6 text-blue-600" />
                <h3 className="text-xl font-bold text-gray-900">{shelter.name}</h3>
              </div>
              {getStatusBadge(shelter.status)}
            </div>
            
            {/* Resources Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {shelter.resources.map((resource) => {
                const Icon = resource.icon;
                const status = getResourceStatus(resource.current, resource.min);
                const available = resource.current - resource.min;
                
                return (
                  <div 
                    key={resource.type} 
                    className="bg-gray-50 rounded-xl p-6"
                  >
                    {/* Icon */}
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-4 ${
                      resource.color === 'blue' ? 'bg-blue-100' :
                      resource.color === 'red' ? 'bg-red-100' :
                      resource.color === 'purple' ? 'bg-purple-100' :
                      'bg-green-100'
                    }`}>
                      <Icon className={`w-7 h-7 ${
                        resource.color === 'blue' ? 'text-blue-600' :
                        resource.color === 'red' ? 'text-red-600' :
                        resource.color === 'purple' ? 'text-purple-600' :
                        'text-green-600'
                      }`} />
                    </div>
                    
                    {/* Title */}
                    <h4 className="font-bold text-gray-900 mb-4 capitalize">
                      {resource.type === 'water' ? t('water') :
                       resource.type === 'medicine' ? t('medicine') :
                       resource.type === 'blankets' ? t('blankets') :
                       t('food')}
                    </h4>
                    
                    {/* Stats */}
                    <div className="space-y-2 mb-4 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">{t('current')}:</span>
                        <span className="font-bold text-gray-900">{resource.current}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">{t('min')}:</span>
                        <span className="font-bold text-gray-900">{resource.min}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Avail:</span>
                        <span className={`font-bold ${available >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {available}
                        </span>
                      </div>
                    </div>
                    
                    {/* Progress */}
                    <div className="mb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className={`h-full ${getProgressColor(status.percent)} transition-all`}
                            style={{ width: `${Math.min(status.percent, 100)}%` }}
                          />
                        </div>
                        <span className={`text-xs font-bold ${
                          status.color === 'green' ? 'text-green-600' :
                          status.color === 'orange' ? 'text-orange-600' :
                          'text-red-600'
                        }`}>
                          {Math.round(status.percent)}%
                        </span>
                      </div>
                    </div>
                    
                    {/* Status */}
                    <div className={`text-center text-sm font-semibold mb-3 ${
                      status.color === 'green' ? 'text-green-700' :
                      status.color === 'orange' ? 'text-orange-700' :
                      'text-red-700'
                    }`}>
                      {status.label}
                    </div>
                    
                    {/* Request Button */}
                    {status.percent < 100 && (
                      <button className={`w-full py-2 text-white rounded-lg text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
                        status.color === 'orange' ? 'bg-orange-600 hover:bg-orange-700' :
                        'bg-red-600 hover:bg-red-700'
                      }`}>
                        <Plus className="w-4 h-4" />
                        {t('request')}
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
