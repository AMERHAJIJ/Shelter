import { AlertTriangle, Ambulance, TruckIcon, Phone, Navigation, Play, CheckCircle, MapPin, Clock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Emergency() {
  const { t } = useLanguage();
  
  const requests = [
    {
      id: 1,
      type: 'sos',
      name: 'Mehmet Yılmaz',
      location: 'Kadıköy',
      time: '2 min ago',
      priority: 'high',
      status: 'new',
      notes: 'Trapped in building, 3rd floor',
    },
    {
      id: 2,
      type: 'ambulance',
      name: 'Ayşe Demir',
      location: 'Beşiktaş',
      time: '5 min ago',
      priority: 'high',
      status: 'in_progress',
      notes: 'Injured leg, needs medical attention',
    },
    {
      id: 3,
      type: 'transfer',
      name: 'Ali Kaya',
      location: 'Moda',
      time: '12 min ago',
      priority: 'medium',
      status: 'new',
      notes: 'Family of 5, needs transport to main shelter',
    },
    {
      id: 4,
      type: 'ambulance',
      name: 'Fatma Özkan',
      location: 'Etiler',
      time: '18 min ago',
      priority: 'medium',
      status: 'in_progress',
      notes: 'Elderly person, breathing difficulties',
    },
    {
      id: 5,
      type: 'sos',
      name: 'Can Arslan',
      location: 'Caddebostan',
      time: '25 min ago',
      priority: 'low',
      status: 'completed',
      notes: 'Lost contact with family members',
    },
  ];
  
  const stats = [
    { label: t('all'), value: requests.length, color: 'gray' },
    { label: t('new'), value: requests.filter(r => r.status === 'new').length, color: 'red' },
    { label: t('in_progress'), value: requests.filter(r => r.status === 'in_progress').length, color: 'yellow' },
    { label: t('completed'), value: requests.filter(r => r.status === 'completed').length, color: 'green' },
    { label: t('sos'), value: requests.filter(r => r.type === 'sos').length, color: 'red' },
    { label: t('ambulance'), value: requests.filter(r => r.type === 'ambulance').length, color: 'orange' },
    { label: t('transfer'), value: requests.filter(r => r.type === 'transfer').length, color: 'blue' },
  ];
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'sos': return AlertTriangle;
      case 'ambulance': return Ambulance;
      case 'transfer': return TruckIcon;
      default: return AlertTriangle;
    }
  };
  
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'sos': return 'text-red-600';
      case 'ambulance': return 'text-orange-600';
      case 'transfer': return 'text-blue-600';
      default: return 'text-gray-600';
    }
  };
  
  const getBorderColor = (type: string) => {
    switch (type) {
      case 'sos': return 'border-red-300';
      case 'ambulance': return 'border-orange-300';
      case 'transfer': return 'border-blue-300';
      default: return 'border-gray-300';
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return <span className="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full">{t('new')}</span>;
      case 'in_progress':
        return <span className="px-3 py-1 bg-yellow-100 text-yellow-700 text-xs font-semibold rounded-full">{t('in_progress')}</span>;
      case 'completed':
        return <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">{t('completed')}</span>;
      default:
        return null;
    }
  };
  
  const getPriorityDot = (priority: string) => {
    switch (priority) {
      case 'high':
        return <div className="w-3 h-3 bg-red-500 rounded-full"></div>;
      case 'medium':
        return <div className="w-3 h-3 bg-orange-500 rounded-full"></div>;
      case 'low':
        return <div className="w-3 h-3 bg-gray-400 rounded-full"></div>;
      default:
        return null;
    }
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('emergency_management')}</h1>
        <p className="text-gray-600">{t('emergency_desc')}</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl shadow p-4 text-center">
            <div className={`text-2xl font-bold ${
              stat.color === 'red' ? 'text-red-600' :
              stat.color === 'yellow' ? 'text-yellow-600' :
              stat.color === 'green' ? 'text-green-600' :
              stat.color === 'orange' ? 'text-orange-600' :
              stat.color === 'blue' ? 'text-blue-600' :
              'text-gray-900'
            }`}>
              {stat.value}
            </div>
            <div className="text-xs text-gray-600 mt-1">{stat.label}</div>
          </div>
        ))}
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-xl shadow p-4">
        <div className="flex flex-wrap gap-2">
          <span className="text-sm font-semibold text-gray-700 mr-2">Filters:</span>
          {[t('all'), t('sos'), t('ambulance'), t('transfer')].map((filter) => (
            <button 
              key={filter}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium rounded-lg transition-colors"
            >
              {filter}
            </button>
          ))}
          <div className="w-px bg-gray-300 mx-2"></div>
          {[t('new'), t('in_progress'), t('completed')].map((filter) => (
            <button 
              key={filter}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium rounded-lg transition-colors"
            >
              {filter}
            </button>
          ))}
        </div>
      </div>
      
      {/* Requests List */}
      <div className="space-y-4">
        {requests.map((request) => {
          const Icon = getTypeIcon(request.type);
          
          return (
            <div 
              key={request.id} 
              className={`bg-white rounded-2xl shadow-lg p-6 border-l-4 ${getBorderColor(request.type)} hover:shadow-xl transition-shadow`}
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Icon className={`w-6 h-6 ${getTypeColor(request.type)}`} />
                  <h3 className="text-lg font-bold text-gray-900">{request.name}</h3>
                  {getPriorityDot(request.priority)}
                </div>
                {getStatusBadge(request.status)}
              </div>
              
              {/* Info */}
              <div className="flex items-center gap-6 mb-4 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{request.location}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{request.time}</span>
                </div>
              </div>
              
              {/* Notes */}
              <div className="bg-gray-50 rounded-xl p-4 mb-4">
                <p className="text-sm text-gray-700">&quot;{request.notes}&quot;</p>
              </div>
              
              {/* Actions */}
              <div className="flex items-center gap-3">
                <button className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition-colors flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  {t('call')}
                </button>
                <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors flex items-center gap-2">
                  <Navigation className="w-4 h-4" />
                  {t('navigate')}
                </button>
                {request.status === 'new' && (
                  <button className="px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg font-semibold transition-colors flex items-center gap-2">
                    <Play className="w-4 h-4" />
                    {t('start')}
                  </button>
                )}
                {request.status === 'in_progress' && (
                  <button className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition-colors flex items-center gap-2">
                    <CheckCircle className="w-4 h-4" />
                    {t('complete')}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
