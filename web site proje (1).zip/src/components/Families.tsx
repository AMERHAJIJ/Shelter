import { Users, CheckCircle, XCircle, MapPin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Families() {
  const { t } = useLanguage();
  
  const families = [
    {
      id: 1,
      headName: 'Mehmet Yılmaz',
      totalMembers: 4,
      arrivedMembers: 4,
      status: 'all_together',
      members: [
        { name: 'Mehmet', relation: 'Head', arrived: true, shelter: 'Kadıköy' },
        { name: 'Ayşe', relation: 'Spouse', arrived: true, shelter: 'Kadıköy' },
        { name: 'Ali', relation: 'Son', arrived: true, shelter: 'Kadıköy' },
        { name: 'Zeynep', relation: 'Daughter', arrived: true, shelter: 'Kadıköy' },
      ],
      shelters: ['Merkez Kadıköy Barınağı'],
    },
    {
      id: 2,
      headName: 'Can Demir',
      totalMembers: 5,
      arrivedMembers: 3,
      status: 'incomplete',
      members: [
        { name: 'Can', relation: 'Head', arrived: true, shelter: 'Beşiktaş' },
        { name: 'Fatma', relation: 'Spouse', arrived: true, shelter: 'Beşiktaş' },
        { name: 'Ahmet', relation: 'Son', arrived: false, shelter: null },
        { name: 'Elif', relation: 'Daughter', arrived: true, shelter: 'Beşiktaş' },
        { name: 'Murat', relation: 'Son', arrived: false, shelter: null },
      ],
      shelters: ['Beşiktaş Spor Salonu'],
    },
    {
      id: 3,
      headName: 'Kemal Özkan',
      totalMembers: 3,
      arrivedMembers: 3,
      status: 'separated',
      members: [
        { name: 'Kemal', relation: 'Head', arrived: true, shelter: 'Kadıköy' },
        { name: 'Emine', relation: 'Spouse', arrived: true, shelter: 'Beşiktaş' },
        { name: 'Deniz', relation: 'Daughter', arrived: true, shelter: 'Moda' },
      ],
      shelters: ['Merkez Kadıköy', 'Beşiktaş Spor Salonu', 'Moda İlkokulu'],
    },
  ];
  
  const totalFamilies = families.length;
  const allArrived = families.filter(f => f.status === 'all_together').length;
  const partial = families.filter(f => f.status === 'incomplete').length;
  const scattered = families.filter(f => f.status === 'separated').length;
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'all_together': return 'border-green-500 bg-green-50';
      case 'separated': return 'border-orange-500 bg-orange-50';
      case 'incomplete': return 'border-red-500 bg-red-50';
      default: return 'border-gray-300';
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'all_together':
        return <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">{t('all_together')}</span>;
      case 'separated':
        return <span className="px-3 py-1 bg-orange-100 text-orange-700 text-xs font-semibold rounded-full">{t('separated')}</span>;
      case 'incomplete':
        return <span className="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full">{t('incomplete')}</span>;
      default:
        return null;
    }
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('family_management')}</h1>
        <p className="text-gray-600">{t('family_desc')}</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">{t('total_families')}</div>
          <div className="text-3xl font-bold text-gray-900">{totalFamilies}</div>
        </div>
        <div className="bg-green-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-green-600 mb-2">{t('all_arrived')}</div>
          <div className="text-3xl font-bold text-green-700">{allArrived}</div>
        </div>
        <div className="bg-red-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-red-600 mb-2">{t('partial')}</div>
          <div className="text-3xl font-bold text-red-700">{partial}</div>
        </div>
        <div className="bg-orange-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-orange-600 mb-2">{t('scattered')}</div>
          <div className="text-3xl font-bold text-orange-700">{scattered}</div>
        </div>
      </div>
      
      {/* Families List */}
      <div className="space-y-6">
        {families.map((family) => (
          <div 
            key={family.id} 
            className={`bg-white rounded-2xl shadow-lg p-6 border-2 ${getStatusColor(family.status)}`}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-3">
                <Users className="w-8 h-8 text-blue-600" />
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{family.headName} Family</h3>
                  <p className="text-sm text-gray-600">
                    {family.arrivedMembers} / {family.totalMembers} {t('members_arrived')}
                  </p>
                </div>
              </div>
              {getStatusBadge(family.status)}
            </div>
            
            {/* Members Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {family.members.map((member, index) => (
                <div 
                  key={index} 
                  className={`p-4 rounded-xl border-2 ${
                    member.arrived 
                      ? 'border-green-200 bg-green-50' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    {member.arrived ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <XCircle className="w-5 h-5 text-gray-400" />
                    )}
                  </div>
                  <div className="font-semibold text-gray-900 mb-1">{member.name}</div>
                  <div className="text-xs text-gray-600 mb-2">{member.relation}</div>
                  {member.shelter && (
                    <div className="text-xs text-gray-700 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {member.shelter}
                    </div>
                  )}
                  {!member.arrived && (
                    <div className="text-xs text-red-600 font-semibold mt-1">
                      Not arrived
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            {/* Location Summary */}
            <div className="bg-white rounded-xl p-4 border border-gray-200">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-700 mb-2">
                    {family.shelters.length === 1 ? 'All at:' : 'Locations:'}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {family.shelters.map((shelter, index) => (
                      <span 
                        key={index} 
                        className={`px-3 py-1 text-xs font-semibold rounded-full ${
                          family.shelters.length === 1 
                            ? 'bg-green-100 text-green-700'
                            : 'bg-orange-100 text-orange-700'
                        }`}
                      >
                        {shelter}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
