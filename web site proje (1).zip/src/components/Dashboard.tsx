import { Users, Building2, AlertTriangle, TrendingUp, MapPin, Clock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

export default function Dashboard() {
  const { t } = useLanguage();
  const { user } = useAuth();
  
  const stats = [
    { label: t('total_people'), value: '1,847', trend: '+12%', icon: Users, color: 'bg-blue-500' },
    { label: t('total_shelters'), value: '12', trend: '+2', icon: Building2, color: 'bg-green-500' },
    { label: t('emergency_requests'), value: '23', trend: '-5%', icon: AlertTriangle, color: 'bg-red-500' },
    { label: t('capacity_usage'), value: '68%', trend: '+8%', icon: TrendingUp, color: 'bg-purple-500' },
  ];
  
  const emergencyStats = [
    { label: t('sos'), value: 8, color: 'bg-red-500' },
    { label: t('ambulance'), value: 12, color: 'bg-orange-500' },
    { label: t('transfer'), value: 3, color: 'bg-blue-500' },
  ];
  
  const shelters = [
    { name: 'Merkez Kadıköy', type: t('main_shelter'), capacity: 324, max: 500, status: t('open'), location: 'Kadıköy, İstanbul' },
    { name: 'Beşiktaş Spor Salonu', type: t('main_shelter'), capacity: 600, max: 600, status: t('full'), location: 'Beşiktaş, İstanbul' },
    { name: 'Moda İlkokulu', type: t('small_shelter'), capacity: 98, max: 150, status: t('open'), location: 'Moda, Kadıköy' },
    { name: 'Caddebostan Park', type: t('small_shelter'), capacity: 125, max: 200, status: t('open'), location: 'Caddebostan' },
  ];
  
  const getProgressColor = (percent: number) => {
    if (percent >= 90) return 'bg-red-500';
    if (percent >= 70) return 'bg-orange-500';
    return 'bg-green-500';
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('dashboard')}</h1>
        <p className="text-gray-600">
          {t('welcome')}, {user?.username} - {user?.role === 'admin' ? t('central_admin') : t('shelter_staff')}
        </p>
      </div>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className={`${stat.color} w-12 h-12 rounded-xl flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-green-600 text-sm font-semibold bg-green-50 px-2 py-1 rounded-lg">
                  {stat.trend}
                </span>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </div>
          );
        })}
      </div>
      
      {/* Emergency Summary */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">{t('emergency_summary')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {emergencyStats.map((stat, index) => (
            <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
              <div className={`${stat.color} w-16 h-16 rounded-xl flex items-center justify-center`}>
                <span className="text-2xl font-bold text-white">{stat.value}</span>
              </div>
              <div>
                <div className="font-semibold text-gray-900">{stat.label}</div>
                <div className="text-sm text-gray-600">{t('new')} {t('emergency_requests')}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Shelters Status */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">{t('shelters_status')}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {shelters.map((shelter, index) => {
            const percent = Math.round((shelter.capacity / shelter.max) * 100);
            const isFull = percent >= 100;
            
            return (
              <div key={index} className={`border-2 rounded-xl p-6 transition-all hover:shadow-lg ${
                isFull ? 'border-red-300 bg-red-50' : 'border-gray-200'
              }`}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Building2 className={`w-5 h-5 ${isFull ? 'text-red-600' : 'text-blue-600'}`} />
                      <h3 className="font-bold text-gray-900">{shelter.name}</h3>
                    </div>
                    <div className="text-sm text-gray-600">{shelter.type}</div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    isFull 
                      ? 'bg-red-100 text-red-700'
                      : 'bg-green-100 text-green-700'
                  }`}>
                    {shelter.status}
                  </span>
                </div>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-2xl font-bold text-gray-900">
                      {shelter.capacity} / {shelter.max}
                    </span>
                    <span className={`text-lg font-bold ${
                      isFull ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {percent}%
                    </span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${getProgressColor(percent)} transition-all`}
                      style={{ width: `${Math.min(percent, 100)}%` }}
                    />
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>{shelter.location}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'View All Shelters', icon: Building2, color: 'bg-green-500' },
            { label: 'Emergency Alerts', icon: AlertTriangle, color: 'bg-red-500' },
            { label: 'Manage Capacity', icon: TrendingUp, color: 'bg-purple-500' },
            { label: 'Send Notification', icon: Clock, color: 'bg-blue-500' },
          ].map((action, index) => {
            const Icon = action.icon;
            return (
              <button
                key={index}
                className="p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all group"
              >
                <div className={`${action.color} w-12 h-12 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-sm font-semibold text-gray-900">{action.label}</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
