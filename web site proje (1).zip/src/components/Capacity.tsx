import { Users, User, Baby, HeartHandshake, UserX } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Capacity() {
  const { t } = useLanguage();
  
  const sections = [
    { 
      id: 'families', 
      label: t('families'), 
      icon: Users, 
      current: 145, 
      max: 200, 
      color: 'blue' 
    },
    { 
      id: 'individuals', 
      label: t('individuals'), 
      icon: User, 
      current: 89, 
      max: 150, 
      color: 'green' 
    },
    { 
      id: 'children', 
      label: t('children'), 
      icon: Baby, 
      current: 67, 
      max: 100, 
      color: 'purple' 
    },
    { 
      id: 'special', 
      label: t('special_needs'), 
      icon: HeartHandshake, 
      current: 23, 
      max: 50, 
      color: 'pink' 
    },
    { 
      id: 'unregistered', 
      label: t('unregistered'), 
      icon: UserX, 
      current: 12, 
      max: 50, 
      color: 'gray' 
    },
  ];
  
  const totalCurrent = sections.reduce((sum, s) => sum + s.current, 0);
  const totalMax = sections.reduce((sum, s) => sum + s.max, 0);
  const totalAvailable = totalMax - totalCurrent;
  const overallPercent = Math.round((totalCurrent / totalMax) * 100);
  
  const getProgressColor = (percent: number) => {
    if (percent >= 90) return 'bg-red-500';
    if (percent >= 75) return 'bg-orange-500';
    return 'bg-green-500';
  };
  
  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; text: string; light: string }> = {
      blue: { bg: 'bg-blue-500', text: 'text-blue-700', light: 'bg-blue-50' },
      green: { bg: 'bg-green-500', text: 'text-green-700', light: 'bg-green-50' },
      purple: { bg: 'bg-purple-500', text: 'text-purple-700', light: 'bg-purple-50' },
      pink: { bg: 'bg-pink-500', text: 'text-pink-700', light: 'bg-pink-50' },
      gray: { bg: 'bg-gray-500', text: 'text-gray-700', light: 'bg-gray-50' },
    };
    return colors[color] || colors.gray;
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('capacity_management')}</h1>
        <p className="text-gray-600">{t('capacity_desc')}</p>
      </div>
      
      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">{t('total_capacity')}</div>
          <div className="text-3xl font-bold text-gray-900">{totalMax}</div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">{t('occupied')}</div>
          <div className="text-3xl font-bold text-blue-600">{totalCurrent}</div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">{t('available')}</div>
          <div className="text-3xl font-bold text-green-600">{totalAvailable}</div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">{t('usage')}</div>
          <div className={`text-3xl font-bold ${
            overallPercent >= 90 ? 'text-red-600' : overallPercent >= 75 ? 'text-orange-600' : 'text-green-600'
          }`}>
            {overallPercent}%
          </div>
        </div>
      </div>
      
      {/* Overall Progress */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-900">{t('overall_occupancy')}</h2>
          <span className="text-2xl font-bold text-gray-900">{overallPercent}%</span>
        </div>
        <div className="h-4 bg-gray-200 rounded-full overflow-hidden mb-3">
          <div 
            className={`h-full ${getProgressColor(overallPercent)} transition-all`}
            style={{ width: `${overallPercent}%` }}
          />
        </div>
        <p className="text-sm text-gray-600">{t('auto_update_qr')}</p>
      </div>
      
      {/* Sections */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">{t('sections')}:</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sections.map((section) => {
            const Icon = section.icon;
            const percent = Math.round((section.current / section.max) * 100);
            const available = section.max - section.current;
            const colors = getColorClasses(section.color);
            
            return (
              <div 
                key={section.id} 
                className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow"
              >
                {/* Icon & Title */}
                <div className={`${colors.light} w-16 h-16 rounded-2xl flex items-center justify-center mb-4`}>
                  <Icon className={`w-8 h-8 ${colors.text}`} />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-4">{section.label}</h3>
                
                {/* Stats */}
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">{t('current')}:</span>
                    <span className="font-bold text-gray-900">{section.current}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">{t('max')}:</span>
                    <span className="font-bold text-gray-900">{section.max}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">{t('available')}:</span>
                    <span className="font-bold text-green-600">{available}</span>
                  </div>
                </div>
                
                {/* Progress */}
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden mr-3">
                      <div 
                        className={`h-full ${getProgressColor(percent)} transition-all`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                    <span className="text-sm font-bold text-gray-700">{percent}%</span>
                  </div>
                </div>
                
                {/* Button */}
                <button className={`w-full py-3 ${colors.bg} text-white rounded-xl font-semibold hover:opacity-90 transition-opacity`}>
                  {t('update')} {t('capacity')}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
