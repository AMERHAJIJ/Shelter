import { UserX, Plus, Building2, Users, Clock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useState } from 'react';

export default function Unregistered() {
  const { t } = useLanguage();
  const [shelter, setShelter] = useState('');
  const [peopleCount, setPeopleCount] = useState('');
  const [notes, setNotes] = useState('');
  
  const entries = [
    {
      id: 1,
      shelter: 'Merkez Kadıköy',
      people: 12,
      notes: 'Family of 5 + 7 individuals without registration',
      time: '15 min ago',
    },
    {
      id: 2,
      shelter: 'Beşiktaş Spor Salonu',
      people: 8,
      notes: 'Emergency walk-ins, no prior registration',
      time: '45 min ago',
    },
    {
      id: 3,
      shelter: 'Moda İlkokulu',
      people: 3,
      notes: 'Elderly couple with caregiver',
      time: '1 hour ago',
    },
  ];
  
  const totalUnregistered = entries.reduce((sum, e) => sum + e.people, 0);
  const sheltersAffected = new Set(entries.map(e => e.shelter)).size;
  const totalEntries = entries.length;
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log({ shelter, peopleCount, notes });
    // Reset form
    setShelter('');
    setPeopleCount('');
    setNotes('');
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('unregistered_management')}</h1>
        <p className="text-gray-600">{t('unregistered_desc')}</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-purple-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-purple-600 mb-2">Total {t('unregistered')}</div>
          <div className="text-3xl font-bold text-purple-700">{totalUnregistered}</div>
        </div>
        <div className="bg-blue-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-blue-600 mb-2">Shelters Affected</div>
          <div className="text-3xl font-bold text-blue-700">{sheltersAffected}</div>
        </div>
        <div className="bg-green-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-green-600 mb-2">Total Entries</div>
          <div className="text-3xl font-bold text-green-700">{totalEntries}</div>
        </div>
      </div>
      
      {/* Add Form */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <Plus className="w-6 h-6 text-purple-600" />
          <h2 className="text-xl font-bold text-gray-900">{t('add_record')}</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Shelter Selection */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('select_shelter')}:
            </label>
            <select
              value={shelter}
              onChange={(e) => setShelter(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none transition-colors"
              required
            >
              <option value="">{t('select_shelter')}</option>
              <option value="kadikoy">Merkez Kadıköy</option>
              <option value="besiktas">Beşiktaş Spor Salonu</option>
              <option value="moda">Moda İlkokulu</option>
              <option value="etiler">Etiler Kültür Merkezi</option>
            </select>
          </div>
          
          {/* People Count */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('people_count_label')}:
            </label>
            <input
              type="number"
              min="1"
              value={peopleCount}
              onChange={(e) => setPeopleCount(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none transition-colors"
              placeholder="Enter number of people"
              required
            />
          </div>
          
          {/* Notes */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('notes')}:
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none transition-colors resize-none"
              placeholder="Optional notes about the unregistered people..."
            />
          </div>
          
          {/* Buttons */}
          <div className="flex items-center gap-3">
            <button
              type="submit"
              className="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              {t('save')}
            </button>
            <button
              type="button"
              onClick={() => {
                setShelter('');
                setPeopleCount('');
                setNotes('');
              }}
              className="px-6 py-3 bg-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
            >
              {t('cancel')}
            </button>
          </div>
        </form>
      </div>
      
      {/* Recent Entries */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">{t('recent_entries')}:</h2>
        <div className="space-y-4">
          {entries.map((entry) => (
            <div 
              key={entry.id} 
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <UserX className="w-6 h-6 text-purple-600" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Building2 className="w-5 h-5 text-blue-600" />
                      <h3 className="font-bold text-gray-900">{entry.shelter}</h3>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-500">
                      <Clock className="w-4 h-4" />
                      <span>{entry.time}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 mb-3">
                    <Users className="w-5 h-5 text-purple-600" />
                    <span className="font-semibold text-gray-900">{entry.people} people</span>
                    <span className="text-gray-500">·</span>
                    <span className="text-sm text-gray-600">{t('unregistered')}</span>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-gray-700">&quot;{entry.notes}&quot;</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
