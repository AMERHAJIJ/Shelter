import { useState } from 'react';
import { Building2, MapPin, Edit, Trash2, Plus, ToggleRight, ToggleLeft } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Shelters() {
  const { t } = useLanguage();
  
  const [shelters, setShelters] = useState([
    { id: 1, name: 'Merkez Kadıköy', location: 'Kadıköy, İstanbul', type: 'main', status: 'open', capacity: 324, max: 500, linkedTo: null },
    { id: 2, name: 'Moda İlkokulu', location: 'Moda, Kadıköy', type: 'small', status: 'open', capacity: 98, max: 150, linkedTo: 1 },
    { id: 3, name: 'Beşiktaş Spor Salonu', location: 'Beşiktaş, İstanbul', type: 'main', status: 'open', capacity: 600, max: 600, linkedTo: null },
    { id: 4, name: 'Etiler Kültür Merkezi', location: 'Etiler, Beşiktaş', type: 'small', status: 'open', capacity: 45, max: 100, linkedTo: 3 },
  ]);
  
  const toggleStatus = (id: number) => {
    setShelters(shelters.map(shelter => 
      shelter.id === id 
        ? { ...shelter, status: shelter.status === 'open' ? 'closed' : 'open' }
        : shelter
    ));
  };
  
  const getProgressColor = (percent: number) => {
    if (percent >= 90) return 'bg-red-500';
    if (percent >= 70) return 'bg-orange-500';
    return 'bg-green-500';
  };
  
  const mainShelters = shelters.filter(s => s.type === 'main').length;
  const smallShelters = shelters.filter(s => s.type === 'small').length;
  const openShelters = shelters.filter(s => s.status === 'open').length;
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('shelter_management')}</h1>
          <p className="text-gray-600">{t('manage_shelters_desc')}</p>
        </div>
        <button className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center gap-2 shadow-lg">
          <Plus className="w-5 h-5" />
          {t('add_shelter')}
        </button>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow p-4 text-center">
          <div className="text-2xl font-bold text-gray-900">{shelters.length}</div>
          <div className="text-sm text-gray-600">{t('total_shelters')}</div>
        </div>
        <div className="bg-blue-50 rounded-xl shadow p-4 text-center">
          <div className="text-2xl font-bold text-blue-700">{mainShelters}</div>
          <div className="text-sm text-blue-600">{t('main')} {t('total_shelters')}</div>
        </div>
        <div className="bg-green-50 rounded-xl shadow p-4 text-center">
          <div className="text-2xl font-bold text-green-700">{smallShelters}</div>
          <div className="text-sm text-green-600">{t('small')} {t('total_shelters')}</div>
        </div>
        <div className="bg-emerald-50 rounded-xl shadow p-4 text-center">
          <div className="text-2xl font-bold text-emerald-700">{openShelters}</div>
          <div className="text-sm text-emerald-600">{t('open')} {t('total_shelters')}</div>
        </div>
      </div>
      
      {/* Table */}
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t('shelter_name')}</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t('location')}</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t('type')}</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t('status')}</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t('capacity')}</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t('actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {shelters.map((shelter) => {
                const percent = Math.round((shelter.capacity / shelter.max) * 100);
                const linkedShelter = shelter.linkedTo ? shelters.find(s => s.id === shelter.linkedTo) : null;
                
                return (
                  <tr key={shelter.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <Building2 className={`w-5 h-5 ${
                          shelter.type === 'main' ? 'text-blue-600' : 'text-green-600'
                        }`} />
                        <div>
                          <div className="font-semibold text-gray-900">{shelter.name}</div>
                          <div className="text-sm text-gray-500">ID: {shelter.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>{shelter.location}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        shelter.type === 'main'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-green-100 text-green-700'
                      }`}>
                        {shelter.type === 'main' ? t('main') : t('small')}
                      </span>
                      {linkedShelter && (
                        <div className="text-xs text-gray-500 mt-1">
                          → {t('linked_to')} #{linkedShelter.id}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <button 
                        onClick={() => toggleStatus(shelter.id)}
                        className="flex items-center gap-2 transition-colors"
                      >
                        {shelter.status === 'open' ? (
                          <>
                            <ToggleRight className="w-6 h-6 text-green-600" />
                            <span className="text-sm font-semibold text-green-700">{t('open')}</span>
                          </>
                        ) : (
                          <>
                            <ToggleLeft className="w-6 h-6 text-gray-400" />
                            <span className="text-sm font-semibold text-gray-500">{t('closed')}</span>
                          </>
                        )}
                      </button>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-2">
                        <div className="text-sm font-semibold text-gray-900">
                          {shelter.capacity} / {shelter.max}
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${getProgressColor(percent)} transition-all`}
                              style={{ width: `${Math.min(percent, 100)}%` }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-gray-600 w-12">{percent}%</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
