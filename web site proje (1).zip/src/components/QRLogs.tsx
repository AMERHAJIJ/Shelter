import { ArrowDown, ArrowUp, User, Building2, Users, Clock, Filter } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function QRLogs() {
  const { t } = useLanguage();
  
  const logs = [
    {
      id: 1,
      type: 'entry',
      name: 'Mehmet Yılmaz',
      userId: 'USR-001',
      shelter: 'Kadıköy',
      section: 'Families',
      people: 4,
      time: '2 min ago',
      qrCode: 'QR-2024-001-ENTRY',
    },
    {
      id: 2,
      type: 'exit',
      name: 'Ali Kaya',
      userId: 'USR-003',
      shelter: 'Kadıköy',
      section: 'Families',
      people: 3,
      time: '12 min ago',
      qrCode: 'QR-2024-003-EXIT',
    },
    {
      id: 3,
      type: 'entry',
      name: 'Ayşe Demir',
      userId: 'USR-007',
      shelter: 'Beşiktaş',
      section: 'Individuals',
      people: 1,
      time: '18 min ago',
      qrCode: 'QR-2024-007-ENTRY',
    },
    {
      id: 4,
      type: 'entry',
      name: 'Fatma Özkan',
      userId: 'USR-012',
      shelter: 'Moda',
      section: 'Special Needs',
      people: 2,
      time: '25 min ago',
      qrCode: 'QR-2024-012-ENTRY',
    },
    {
      id: 5,
      type: 'exit',
      name: 'Can Arslan',
      userId: 'USR-005',
      shelter: 'Beşiktaş',
      section: 'Individuals',
      people: 1,
      time: '35 min ago',
      qrCode: 'QR-2024-005-EXIT',
    },
  ];
  
  const totalLogs = logs.length;
  const totalEntries = logs.filter(l => l.type === 'entry').length;
  const totalExits = logs.filter(l => l.type === 'exit').length;
  const netChange = totalEntries - totalExits;
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('qr_logs')}</h1>
        <p className="text-gray-600">{t('qr_logs_desc')}</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="text-sm text-gray-600 mb-2">Total Logs</div>
          <div className="text-3xl font-bold text-gray-900">{totalLogs}</div>
        </div>
        <div className="bg-green-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-green-600 mb-2">{t('entry')}</div>
          <div className="text-3xl font-bold text-green-700">+{totalEntries}</div>
        </div>
        <div className="bg-red-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-red-600 mb-2">{t('exit')}</div>
          <div className="text-3xl font-bold text-red-700">-{totalExits}</div>
        </div>
        <div className="bg-purple-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-purple-600 mb-2">{t('net_change')}</div>
          <div className="text-3xl font-bold text-purple-700">
            {netChange > 0 ? '+' : ''}{netChange}
          </div>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-xl shadow p-4">
        <div className="flex flex-wrap items-center gap-3">
          <Filter className="w-5 h-5 text-gray-600" />
          <span className="text-sm font-semibold text-gray-700">Filter:</span>
          {[t('all'), t('entry'), t('exit')].map((filter) => (
            <button 
              key={filter}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium rounded-lg transition-colors"
            >
              {filter}
            </button>
          ))}
          <select className="px-4 py-2 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg border-none outline-none">
            <option>All Shelters</option>
            <option>Kadıköy</option>
            <option>Beşiktaş</option>
            <option>Moda</option>
          </select>
        </div>
      </div>
      
      {/* Logs Table */}
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Type</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">User</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Shelter</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Section</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">People</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Time</th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">QR Code</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {log.type === 'entry' ? (
                        <>
                          <ArrowDown className="w-5 h-5 text-green-600" />
                          <span className="w-3 h-3 bg-green-500 rounded-full"></span>
                        </>
                      ) : (
                        <>
                          <ArrowUp className="w-5 h-5 text-red-600" />
                          <span className="w-3 h-3 bg-red-500 rounded-full"></span>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-gray-400" />
                      <div>
                        <div className="font-semibold text-gray-900">{log.name}</div>
                        <div className="text-xs text-gray-500">{log.userId}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-blue-600" />
                      <span className="text-sm text-gray-900">{log.shelter}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full">
                      {log.section}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-purple-600" />
                      <span className="font-bold text-gray-900">{log.people}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>{log.time}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <code className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-mono rounded">
                      {log.qrCode}
                    </code>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <p className="text-sm text-gray-600 text-center">
            {t('auto_update_qr')}
          </p>
        </div>
      </div>
    </div>
  );
}
