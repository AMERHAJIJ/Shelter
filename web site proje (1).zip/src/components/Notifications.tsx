import { Bell, Send, MapPin, Users, Clock } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useState } from 'react';

export default function Notifications() {
  const { t } = useLanguage();
  const [notifType, setNotifType] = useState('shelter_opened');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [region, setRegion] = useState('all');
  const [target, setTarget] = useState('all');
  
  const notifications = [
    {
      id: 1,
      type: 'shelter_opened',
      title: 'Kadıköy Shelter Opened',
      message: 'Merkez Kadıköy shelter is now open and accepting people',
      region: 'Kadıköy',
      target: 'All',
      time: '5 min ago',
      status: 'sent',
    },
    {
      id: 2,
      type: 'earthquake',
      title: 'Earthquake Alert',
      message: 'Stay calm and follow safety instructions. Move to shelters.',
      region: 'All',
      target: 'All',
      time: '1 hour ago',
      status: 'sent',
    },
    {
      id: 3,
      type: 'shelter_closed',
      title: 'Beşiktaş Shelter Full',
      message: 'Beşiktaş shelter has reached capacity. Please go to alternative shelters.',
      region: 'Beşiktaş',
      target: 'All',
      time: '2 hours ago',
      status: 'sent',
    },
  ];
  
  const totalSent = notifications.length;
  const sentToday = notifications.filter(n => n.time.includes('min') || n.time.includes('hour')).length;
  const recipients = 2500;
  
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'shelter_opened': return 'text-green-600 bg-green-100';
      case 'shelter_closed': return 'text-red-600 bg-red-100';
      case 'earthquake': return 'text-orange-600 bg-orange-100';
      case 'instruction': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };
  
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'shelter_opened': return '✓';
      case 'shelter_closed': return '✗';
      case 'earthquake': return '⚠️';
      case 'instruction': return 'ℹ️';
      default: return '🔔';
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log({ notifType, title, message, region, target });
    // Reset form
    setTitle('');
    setMessage('');
  };
  
  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('notification_management')}</h1>
        <p className="text-gray-600">{t('notification_desc')}</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-blue-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-blue-600 mb-2">{t('total_sent')}</div>
          <div className="text-3xl font-bold text-blue-700">{totalSent}</div>
        </div>
        <div className="bg-green-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-green-600 mb-2">{t('today')}</div>
          <div className="text-3xl font-bold text-green-700">{sentToday}</div>
        </div>
        <div className="bg-purple-50 rounded-xl shadow-lg p-6">
          <div className="text-sm text-purple-600 mb-2">{t('recipients')}</div>
          <div className="text-3xl font-bold text-purple-700">~{recipients}</div>
        </div>
      </div>
      
      {/* Send Form */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center gap-3 mb-6">
          <Send className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">{t('send_notification')}</h2>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Type Selection */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              {t('notification_type')}:
            </label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setNotifType('shelter_opened')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  notifType === 'shelter_opened'
                    ? 'border-green-500 bg-green-50 text-green-700'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold">{t('shelter_opened')}</div>
              </button>
              <button
                type="button"
                onClick={() => setNotifType('shelter_closed')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  notifType === 'shelter_closed'
                    ? 'border-red-500 bg-red-50 text-red-700'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold">{t('shelter_closed')}</div>
              </button>
              <button
                type="button"
                onClick={() => setNotifType('earthquake')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  notifType === 'earthquake'
                    ? 'border-orange-500 bg-orange-50 text-orange-700'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold">{t('earthquake')}</div>
              </button>
              <button
                type="button"
                onClick={() => setNotifType('instruction')}
                className={`p-4 rounded-xl border-2 transition-all ${
                  notifType === 'instruction'
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="font-semibold">{t('instruction')}</div>
              </button>
            </div>
          </div>
          
          {/* Title */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('title')}:
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              placeholder="Enter title"
              required
            />
          </div>
          
          {/* Message */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('message')}:
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors resize-none"
              placeholder="Enter message"
              required
            />
          </div>
          
          {/* Region & Target */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t('region')}:
              </label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              >
                <option value="all">All</option>
                <option value="kadikoy">Kadıköy</option>
                <option value="besiktas">Beşiktaş</option>
                <option value="moda">Moda</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t('target')}:
              </label>
              <select
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
              >
                <option value="all">All</option>
                <option value="families">{t('families')}</option>
                <option value="individuals">{t('individuals')}</option>
              </select>
            </div>
          </div>
          
          {/* Buttons */}
          <div className="flex items-center gap-3">
            <button
              type="submit"
              className="px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-colors flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              {t('send')}
            </button>
            <button
              type="button"
              onClick={() => {
                setTitle('');
                setMessage('');
              }}
              className="px-6 py-3 bg-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
            >
              {t('cancel')}
            </button>
          </div>
        </form>
      </div>
      
      {/* Recent Notifications */}
      <div>
        <h2 className="text-xl font-bold text-gray-900 mb-4">{t('recent_notifications')}:</h2>
        <div className="space-y-4">
          {notifications.map((notif) => (
            <div 
              key={notif.id} 
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${getTypeColor(notif.type)}`}>
                  {getTypeIcon(notif.type)}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-bold text-gray-900">{notif.title}</h3>
                    <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                      {t('sent')}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-700 mb-4 bg-gray-50 rounded-lg p-3">
                    &quot;{notif.message}&quot;
                  </p>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>{notif.region}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4" />
                      <span>{notif.target}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{notif.time}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
