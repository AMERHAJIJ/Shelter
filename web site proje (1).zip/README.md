
  # web site proje

  This is a code bundle for web site proje. The original project is available at https://www.figma.com/design/YQVFuK6LUzMs40UR6leVuu/web-site-proje.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  