
  # Shelter Smart App Design son version

  This is a code bundle for Shelter Smart App Design son version. The original project is available at https://www.figma.com/design/0ugxOMGGydqiE8dCSoweIo/Shelter-Smart-App-Design-son-version.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  