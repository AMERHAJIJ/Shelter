import { useState } from 'react';
import { Users, Plus, User, Baby, CheckCircle, Clock, MapPin, Phone, AlertCircle } from 'lucide-react';
import { UserData } from '../App';

interface FamilyMember {
  name: string;
  relation: string;
  age: number;
  status: 'arrived' | 'not-arrived';
  currentShelter: string;
  phone: string;
}

export default function FamilyScreen({ 
  onNavigate, 
  userData,
  onUpdateUser,
  language 
}: { 
  onNavigate: (screen: string) => void;
  userData: UserData;
  onUpdateUser: (updates: Partial<UserData>) => void;
  language: 'tr' | 'en' | 'ar';
}) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMember, setNewMember] = useState({ name: '', relation: '', age: '', phone: '' });

  const text = {
    tr: {
      title: 'Aile Yönetimi',
      subtitle: 'Aile üyelerinizi takip edin',
      totalMembers: 'Toplam Aile Üyeleri',
      arrived: 'Ulaştı',
      notArrived: 'Ulaşmadı',
      familyMembers: 'Aile Üyeleri',
      addMember: 'Üye Ekle',
      currentShelter: 'Mevcut Barınak',
      noShelter: 'Barınakta Değil',
      head: 'Aile Reisi',
      spouse: 'Eş',
      son: 'Oğul',
      daughter: 'Kız',
      years: 'yaş',
      addNewMember: 'Yeni Üye Ekle',
      fullName: 'Ad Soyad',
      fullNamePlaceholder: 'Adını girin',
      relation: 'Yakınlık',
      relationPlaceholder: 'Örn: Oğul, Kız',
      age: 'Yaş',
      agePlaceholder: 'Yaşı girin',
      phoneNumber: 'Telefon (Opsiyonel)',
      phonePlaceholder: 'Telefon numarası',
      add: 'Ekle',
      cancel: 'İptal',
      updateNote: 'QR kod taraması ile otomatik güncellenir'
    },
    en: {
      title: 'Family Management',
      subtitle: 'Track your family members',
      totalMembers: 'Total Family Members',
      arrived: 'Arrived',
      notArrived: 'Not Arrived',
      familyMembers: 'Family Members',
      addMember: 'Add Member',
      currentShelter: 'Current Shelter',
      noShelter: 'Not in Shelter',
      head: 'Family Head',
      spouse: 'Spouse',
      son: 'Son',
      daughter: 'Daughter',
      years: 'years',
      addNewMember: 'Add New Member',
      fullName: 'Full Name',
      fullNamePlaceholder: 'Enter name',
      relation: 'Relation',
      relationPlaceholder: 'E.g: Son, Daughter',
      age: 'Age',
      agePlaceholder: 'Enter age',
      phoneNumber: 'Phone (Optional)',
      phonePlaceholder: 'Phone number',
      add: 'Add',
      cancel: 'Cancel',
      updateNote: 'Auto-updated via QR code scan'
    },
    ar: {
      title: 'إدارة العائلة',
      subtitle: 'تتبع أفراد عائلتك',
      totalMembers: 'إجمالي أفراد العائلة',
      arrived: 'وصل',
      notArrived: 'لم يصل',
      familyMembers: 'أفراد العائلة',
      addMember: 'إضافة فرد',
      currentShelter: 'المأوى الحالي',
      noShelter: 'ليس في المأوى',
      head: 'رب العائلة',
      spouse: 'الزوج/الزوجة',
      son: 'ابن',
      daughter: 'ابنة',
      years: 'سنة',
      addNewMember: 'إضافة عضو جديد',
      fullName: 'الاسم الكامل',
      fullNamePlaceholder: 'أدخل الاسم',
      relation: 'القرابة',
      relationPlaceholder: 'مثال: ابن، ابنة',
      age: 'العمر',
      agePlaceholder: 'أدخل العمر',
      phoneNumber: 'الهاتف (اختياري)',
      phonePlaceholder: 'رقم الهاتف',
      add: 'إضافة',
      cancel: 'إلغاء',
      updateNote: 'يتم التحديث تلقائياً عبر مسح رمز QR'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([
    {
      name: userData.fullName,
      relation: t.head,
      age: 42,
      status: 'arrived',
      currentShelter: userData.assignedShelter,
      phone: `${userData.countryCode} ${userData.phoneNumber}`
    },
    {
      name: language === 'tr' ? 'Ayşe Yılmaz' : 'Sarah Johnson',
      relation: t.spouse,
      age: 38,
      status: 'arrived',
      currentShelter: userData.assignedShelter,
      phone: '+90 555 234 5678'
    },
    {
      name: language === 'tr' ? 'Mehmet Yılmaz' : 'Michael Johnson',
      relation: t.son,
      age: 12,
      status: 'arrived',
      currentShelter: userData.assignedShelter,
      phone: '-'
    },
    {
      name: language === 'tr' ? 'Zeynep Yılmaz' : 'Emily Johnson',
      relation: t.daughter,
      age: 8,
      status: 'not-arrived',
      currentShelter: t.noShelter,
      phone: '-'
    }
  ]);

  const arrivedCount = familyMembers.filter(m => m.status === 'arrived').length;
  const notArrivedCount = familyMembers.filter(m => m.status === 'not-arrived').length;

  const handleAddMember = () => {
    if (newMember.name && newMember.relation && newMember.age) {
      const member: FamilyMember = {
        name: newMember.name,
        relation: newMember.relation,
        age: parseInt(newMember.age),
        status: 'not-arrived',
        currentShelter: t.noShelter,
        phone: newMember.phone || '-'
      };
      setFamilyMembers([...familyMembers, member]);
      onUpdateUser({ familyMembers: familyMembers.length + 1 });
      setNewMember({ name: '', relation: '', age: '', phone: '' });
      setShowAddModal(false);
    }
  };

  return (
    <div className="h-full bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-purple-600 px-6 pt-14 pb-6">
        <h1 className="text-white text-2xl font-bold mb-2">{t.title}</h1>
        <p className="text-purple-100 text-sm">{t.subtitle}</p>
      </div>

      {/* Summary Card */}
      <div className="px-6 py-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">{t.totalMembers}</p>
              <p className="text-3xl font-bold text-gray-900">{familyMembers.length}</p>
            </div>
            <div className="flex gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-1">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <p className="text-xs text-gray-600">{t.arrived}</p>
                <p className="text-sm font-bold text-gray-900">{arrivedCount}</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-1">
                  <Clock className="w-6 h-6 text-orange-600" />
                </div>
                <p className="text-xs text-gray-600">{t.notArrived}</p>
                <p className="text-sm font-bold text-gray-900">{notArrivedCount}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Family Members List */}
      <div className="px-6 pb-6 space-y-3">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-bold text-gray-900">{t.familyMembers}</h2>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1 text-purple-600 font-semibold text-sm"
          >
            <Plus className="w-4 h-4" />
            {t.addMember}
          </button>
        </div>

        {familyMembers.map((member, index) => (
          <div key={index} className="bg-white rounded-2xl p-4 shadow-sm">
            <div className="flex items-start gap-3">
              {/* Avatar */}
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                {member.age < 18 ? (
                  <Baby className="w-6 h-6 text-purple-600" />
                ) : (
                  <User className="w-6 h-6 text-purple-600" />
                )}
              </div>

              {/* Info */}
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-bold text-gray-900">{member.name}</h3>
                    <p className="text-sm text-gray-600">{member.relation} • {member.age} {t.years}</p>
                  </div>
                  <div className={`px-2 py-1 rounded-full flex items-center gap-1 ${
                    member.status === 'arrived' 
                      ? 'bg-green-100' 
                      : 'bg-orange-100'
                  }`}>
                    {member.status === 'arrived' ? (
                      <CheckCircle className="w-3 h-3 text-green-600" />
                    ) : (
                      <Clock className="w-3 h-3 text-orange-600" />
                    )}
                    <span className={`text-xs font-medium ${
                      member.status === 'arrived' 
                        ? 'text-green-700' 
                        : 'text-orange-700'
                    }`}>
                      {member.status === 'arrived' ? t.arrived : t.notArrived}
                    </span>
                  </div>
                </div>

                {/* Details */}
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>{member.currentShelter}</span>
                  </div>
                  {member.phone !== '-' && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{member.phone}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Auto-update Notice */}
        <div className="bg-blue-50 border-l-4 border-blue-500 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
          <p className="text-sm text-blue-800">{t.updateNote}</p>
        </div>
      </div>

      {/* Add Member Modal */}
      {showAddModal && (
        <div className="absolute inset-0 bg-black/50 flex items-end">
          <div className="bg-white w-full rounded-t-3xl p-6 animate-slide-up">
            <h3 className="text-xl font-bold text-gray-900 mb-4">{t.addNewMember}</h3>
            
            <div className="space-y-4 mb-6">
              <input
                type="text"
                placeholder={t.fullNamePlaceholder}
                value={newMember.name}
                onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <input
                type="text"
                placeholder={t.relationPlaceholder}
                value={newMember.relation}
                onChange={(e) => setNewMember({ ...newMember, relation: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <input
                type="number"
                placeholder={t.agePlaceholder}
                value={newMember.age}
                onChange={(e) => setNewMember({ ...newMember, age: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <input
                type="tel"
                placeholder={t.phonePlaceholder}
                value={newMember.phone}
                onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            <div className="space-y-3">
              <button 
                onClick={handleAddMember}
                className="w-full bg-purple-500 text-white py-4 rounded-xl font-semibold hover:bg-purple-600 transition-colors"
              >
                {t.add}
              </button>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-full bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}