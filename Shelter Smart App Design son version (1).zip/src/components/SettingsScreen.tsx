import { ArrowLeft, Globe, Bell, Shield, User, Moon, Wifi, HelpCircle, LogOut } from 'lucide-react';
import { useState } from 'react';

interface SettingsScreenProps {
  onBack: () => void;
  language: 'tr' | 'en' | 'ar';
  onLanguageChange: (lang: 'tr' | 'en' | 'ar') => void;
  userData: {
    fullName: string;
    phoneNumber: string;
  };
  onLogout: () => void;
}

export default function SettingsScreen({ onBack, language, onLanguageChange, userData, onLogout }: SettingsScreenProps) {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [offlineMode, setOfflineMode] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  const content = {
    tr: {
      title: 'Ayarlar',
      subtitle: 'Uygulama ayarlarını yönetin',
      account: 'Hesap Bilgileri',
      name: 'Ad Soyad',
      phone: 'Telefon',
      language: 'Dil Ayarları',
      languageDesc: 'Uygulamanın dilini değiştirin',
      turkish: 'Türkçe',
      english: 'English',
      arabic: 'Arabic',
      notifications: 'Bildirimler',
      notificationsDesc: 'Acil durum bildirimlerini al',
      emergencyAlerts: 'Acil Durum Uyarıları',
      darkMode: 'Karanlık Mod',
      darkModeDesc: 'Göz konforunu artırın',
      offline: 'Çevrimdışı Mod',
      offlineDesc: 'İnternet olmadan kullan',
      privacy: 'Gizlilik ve Güvenlik',
      privacyPolicy: 'Gizlilik Politikası',
      termsOfService: 'Kullanım Şartları',
      dataProtection: 'Veri Koruma',
      support: 'Yardım ve Destek',
      helpCenter: 'Yardım Merkezi',
      contactSupport: 'Destek Ekibi',
      faq: 'Sık Sorulan Sorular',
      about: 'Hakkında',
      version: 'Sürüm',
      logout: 'Çıkış Yap',
      logoutConfirm: 'Çıkmak istediğinize emin misiniz?',
      cancel: 'İptal',
      confirm: 'Evet, Çıkış Yap'
    },
    en: {
      title: 'Settings',
      subtitle: 'Manage your app preferences',
      account: 'Account Information',
      name: 'Full Name',
      phone: 'Phone Number',
      language: 'Language Settings',
      languageDesc: 'Change the app language',
      turkish: 'Türkçe',
      english: 'English',
      arabic: 'Arabic',
      notifications: 'Notifications',
      notificationsDesc: 'Receive emergency alerts',
      emergencyAlerts: 'Emergency Alerts',
      darkMode: 'Dark Mode',
      darkModeDesc: 'Reduce eye strain',
      offline: 'Offline Mode',
      offlineDesc: 'Use without internet',
      privacy: 'Privacy & Security',
      privacyPolicy: 'Privacy Policy',
      termsOfService: 'Terms of Service',
      dataProtection: 'Data Protection',
      support: 'Help & Support',
      helpCenter: 'Help Center',
      contactSupport: 'Contact Support',
      faq: 'Frequently Asked Questions',
      about: 'About',
      version: 'Version',
      logout: 'Logout',
      logoutConfirm: 'Are you sure you want to logout?',
      cancel: 'Cancel',
      confirm: 'Yes, Logout'
    },
    ar: {
      title: 'الإعدادات',
      subtitle: 'إدارة تفضيلات التطبيق',
      account: 'معلومات الحساب',
      name: 'الاسم الكامل',
      phone: 'رقم الهاتف',
      language: 'إعدادات اللغة',
      languageDesc: 'تغيير لغة التطبيق',
      turkish: 'التركية',
      english: 'الإنجليزية',
      arabic: 'العربية',
      notifications: 'الإشعارات',
      notificationsDesc: 'تلقي إشعارات الطوارئ',
      emergencyAlerts: 'تنبيهات الطوارئ',
      darkMode: 'الوضع الداكن',
      darkModeDesc: 'تحسين راحة العين',
      offline: 'الوضع غير المتصل بالإنترنت',
      offlineDesc: 'استخدام التطبيق بدون اتصال بالإنترنت',
      privacy: 'خصوصية وحماية البيانات',
      privacyPolicy: 'سياسة الخصوصية',
      termsOfService: 'شروط الخدمة',
      dataProtection: 'حماية البيانات',
      support: 'المساعدة والدعم',
      helpCenter: 'مركز المساعدة',
      contactSupport: 'اتصال الدعم',
      faq: 'أسئلة شائعة',
      about: 'عن التطبيق',
      version: 'الإصدار',
      logout: 'تسجيل الخروج',
      logoutConfirm: 'هل أنت متأكد من أنك تريد تسجيل الخروج؟',
      cancel: 'إلغاء',
      confirm: 'نعم، تسجيل الخروج'
    }
  };

  const t = content[language];

  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  return (
    <div className="flex flex-col h-full bg-neutral-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-emergency-blue to-emergency-blue-dark text-white px-6 pt-12 pb-6">
        <button
          onClick={onBack}
          className="mb-4 p-2 -ml-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-2xl font-bold mb-1">{t.title}</h1>
        <p className="text-blue-100 text-sm">{t.subtitle}</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {/* Account Section */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-emergency-blue/10 rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-emergency-blue" />
            </div>
            <h2 className="font-bold text-lg">{t.account}</h2>
          </div>
          <div className="space-y-3">
            <div>
              <p className="text-xs text-neutral-500 mb-1">{t.name}</p>
              <p className="font-medium">{userData.fullName}</p>
            </div>
            <div className="border-t border-neutral-100 pt-3">
              <p className="text-xs text-neutral-500 mb-1">{t.phone}</p>
              <p className="font-medium">{userData.phoneNumber}</p>
            </div>
          </div>
        </div>

        {/* Language Settings */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-safe-green/10 rounded-full flex items-center justify-center">
              <Globe className="w-5 h-5 text-safe-green" />
            </div>
            <div className="flex-1">
              <h2 className="font-bold text-base">{t.language}</h2>
              <p className="text-xs text-neutral-500">{t.languageDesc}</p>
            </div>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => onLanguageChange('tr')}
              className={`flex-1 py-3 px-4 rounded-xl border-2 transition-all ${
                language === 'tr'
                  ? 'border-emergency-blue bg-emergency-blue text-white'
                  : 'border-neutral-200 bg-white text-neutral-600 hover:border-emergency-blue/50'
              }`}
            >
              <span className="font-medium">{t.turkish}</span>
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`flex-1 py-3 px-4 rounded-xl border-2 transition-all ${
                language === 'en'
                  ? 'border-emergency-blue bg-emergency-blue text-white'
                  : 'border-neutral-200 bg-white text-neutral-600 hover:border-emergency-blue/50'
              }`}
            >
              <span className="font-medium">{t.english}</span>
            </button>
            <button
              onClick={() => onLanguageChange('ar')}
              className={`flex-1 py-3 px-4 rounded-xl border-2 transition-all ${
                language === 'ar'
                  ? 'border-emergency-blue bg-emergency-blue text-white'
                  : 'border-neutral-200 bg-white text-neutral-600 hover:border-emergency-blue/50'
              }`}
            >
              <span className="font-medium">{t.arabic}</span>
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-warning-orange/10 rounded-full flex items-center justify-center">
              <Bell className="w-5 h-5 text-warning-orange" />
            </div>
            <div className="flex-1">
              <h2 className="font-bold text-base">{t.notifications}</h2>
              <p className="text-xs text-neutral-500">{t.notificationsDesc}</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notificationsEnabled}
                onChange={(e) => setNotificationsEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emergency-blue rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emergency-blue"></div>
            </label>
          </div>
        </div>

        {/* App Settings */}
        <div className="bg-white rounded-2xl p-5 shadow-sm space-y-4">
          {/* Dark Mode */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-neutral-700/10 rounded-full flex items-center justify-center">
                <Moon className="w-5 h-5 text-neutral-700" />
              </div>
              <div>
                <h3 className="font-medium">{t.darkMode}</h3>
                <p className="text-xs text-neutral-500">{t.darkModeDesc}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={darkMode}
                onChange={(e) => setDarkMode(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emergency-blue rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-700"></div>
            </label>
          </div>

          <div className="border-t border-neutral-100"></div>

          {/* Offline Mode */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emergency-blue/10 rounded-full flex items-center justify-center">
                <Wifi className="w-5 h-5 text-emergency-blue" />
              </div>
              <div>
                <h3 className="font-medium">{t.offline}</h3>
                <p className="text-xs text-neutral-500">{t.offlineDesc}</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={offlineMode}
                onChange={(e) => setOfflineMode(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emergency-blue rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emergency-blue"></div>
            </label>
          </div>
        </div>

        {/* Privacy & Security */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-safe-green/10 rounded-full flex items-center justify-center">
              <Shield className="w-5 h-5 text-safe-green" />
            </div>
            <h2 className="font-bold text-base">{t.privacy}</h2>
          </div>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between py-3 hover:bg-neutral-50 rounded-lg px-2 transition-colors">
              <span className="text-sm">{t.privacyPolicy}</span>
              <ArrowLeft className="w-4 h-4 rotate-180 text-neutral-400" />
            </button>
            <button className="w-full flex items-center justify-between py-3 hover:bg-neutral-50 rounded-lg px-2 transition-colors">
              <span className="text-sm">{t.termsOfService}</span>
              <ArrowLeft className="w-4 h-4 rotate-180 text-neutral-400" />
            </button>
            <button className="w-full flex items-center justify-between py-3 hover:bg-neutral-50 rounded-lg px-2 transition-colors">
              <span className="text-sm">{t.dataProtection}</span>
              <ArrowLeft className="w-4 h-4 rotate-180 text-neutral-400" />
            </button>
          </div>
        </div>

        {/* Help & Support */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-warning-orange/10 rounded-full flex items-center justify-center">
              <HelpCircle className="w-5 h-5 text-warning-orange" />
            </div>
            <h2 className="font-bold text-base">{t.support}</h2>
          </div>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between py-3 hover:bg-neutral-50 rounded-lg px-2 transition-colors">
              <span className="text-sm">{t.helpCenter}</span>
              <ArrowLeft className="w-4 h-4 rotate-180 text-neutral-400" />
            </button>
            <button className="w-full flex items-center justify-between py-3 hover:bg-neutral-50 rounded-lg px-2 transition-colors">
              <span className="text-sm">{t.contactSupport}</span>
              <ArrowLeft className="w-4 h-4 rotate-180 text-neutral-400" />
            </button>
            <button className="w-full flex items-center justify-between py-3 hover:bg-neutral-50 rounded-lg px-2 transition-colors">
              <span className="text-sm">{t.faq}</span>
              <ArrowLeft className="w-4 h-4 rotate-180 text-neutral-400" />
            </button>
          </div>
        </div>

        {/* About */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <div className="text-center">
            <p className="text-sm text-neutral-500 mb-1">{t.about}</p>
            <p className="text-lg font-bold text-emergency-blue">Shelter Smart</p>
            <p className="text-xs text-neutral-400 mt-2">{t.version} 1.0.0</p>
          </div>
        </div>

        {/* Logout Button */}
        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full bg-white border-2 border-danger-red text-danger-red py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-danger-red hover:text-white transition-all shadow-sm"
        >
          <LogOut className="w-5 h-5" />
          {t.logout}
        </button>

        <div className="h-4"></div>
      </div>

      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 px-6">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm animate-in fade-in slide-in-from-bottom-4">
            <div className="w-12 h-12 bg-danger-red/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <LogOut className="w-6 h-6 text-danger-red" />
            </div>
            <h3 className="text-xl font-bold text-center mb-2">{t.logout}</h3>
            <p className="text-neutral-600 text-center mb-6">{t.logoutConfirm}</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-3 px-4 border-2 border-neutral-200 rounded-xl font-medium hover:bg-neutral-50 transition-colors"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => {
                  setShowLogoutConfirm(false);
                  onLogout();
                }}
                className="flex-1 py-3 px-4 bg-danger-red text-white rounded-xl font-medium hover:bg-danger-red/90 transition-colors"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}