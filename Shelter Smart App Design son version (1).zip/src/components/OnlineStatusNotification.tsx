import { useEffect, useState, useRef } from 'react';
import { Wifi, WifiOff, CheckCircle, RefreshCw } from 'lucide-react';

interface OnlineStatusNotificationProps {
  language: 'tr' | 'en' | 'ar';
}

export default function OnlineStatusNotification({ language }: OnlineStatusNotificationProps) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showNotification, setShowNotification] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncComplete, setSyncComplete] = useState(false);
  const previousOnlineState = useRef(navigator.onLine);

  const content = {
    tr: {
      online: 'Çevrimiçi',
      offline: 'Çevrimdışı',
      onlineMessage: 'İnternet bağlantısı yeniden kuruldu',
      offlineMessage: 'İnternet bağlantısı kesildi. Çevrimdışı moddasınız.',
      syncing: 'Senkronize ediliyor...',
      syncComplete: 'Senkronizasyon tamamlandı',
      syncCompleteDesc: 'Tüm veriler güncellendi',
      dataQueued: 'Bekleyen veriler senkronize ediliyor',
      offlineDesc: 'Çevrimdışı moddasınız'
    },
    en: {
      online: 'Online',
      offline: 'Offline',
      onlineMessage: 'Internet connection restored',
      offlineMessage: 'No internet connection. You are in offline mode.',
      syncing: 'Syncing...',
      syncComplete: 'Sync Complete',
      syncCompleteDesc: 'All data updated',
      dataQueued: 'Syncing queued data',
      offlineDesc: 'You are in offline mode'
    },
    ar: {
      online: 'متصل',
      offline: 'غير متصل',
      onlineMessage: 'تم استعادة الاتصال بالإنترنت',
      offlineMessage: 'لا يوجد اتصال بالإنترنت. أنت في وضع عدم الاتصال.',
      syncing: 'جاري المزامنة...',
      syncComplete: 'اكتملت المزامنة',
      syncCompleteDesc: 'تم تحديث جميع البيانات',
      dataQueued: 'مزامنة البيانات المعلقة',
      offlineDesc: 'أنت في وضع عدم الاتصال'
    }
  };

  const t = content[language];
  const isRTL = language === 'ar';

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (!previousOnlineState.current) {
        // Was offline, now online - trigger sync
        setShowNotification(true);
        setIsSyncing(true);
        setSyncComplete(false);

        // Simulate sync process
        setTimeout(() => {
          setIsSyncing(false);
          setSyncComplete(true);
          
          // Hide complete message after 3 seconds
          setTimeout(() => {
            setShowNotification(false);
            setSyncComplete(false);
          }, 3000);
        }, 2000);
      }
      previousOnlineState.current = true;
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowNotification(true);
      previousOnlineState.current = false;
      
      // Hide offline message after 5 seconds
      setTimeout(() => {
        setShowNotification(false);
      }, 5000);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!showNotification) return null;

  return (
    <div 
      className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 px-4 w-full max-w-[360px] animate-in slide-in-from-top-4 fade-in"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <div
        className={`rounded-2xl shadow-2xl p-4 backdrop-blur-sm transition-all ${
          isOnline
            ? isSyncing
              ? 'bg-blue-500/95 text-white'
              : syncComplete
              ? 'bg-green-500/95 text-white'
              : 'bg-blue-600/95 text-white'
            : 'bg-gray-800/95 text-white'
        }`}
      >
        <div className="flex items-center gap-3">
          {/* Icon */}
          <div
            className={`w-10 h-10 rounded-full flex items-center justify-center ${
              isOnline
                ? isSyncing
                  ? 'bg-white/20'
                  : syncComplete
                  ? 'bg-white/20'
                  : 'bg-white/20'
                : 'bg-white/20'
            }`}
          >
            {isOnline ? (
              isSyncing ? (
                <RefreshCw className="w-5 h-5 animate-spin" />
              ) : syncComplete ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                <Wifi className="w-5 h-5" />
              )
            ) : (
              <WifiOff className="w-5 h-5" />
            )}
          </div>

          {/* Content */}
          <div className="flex-1">
            <h3 className="font-bold text-sm">
              {isOnline
                ? isSyncing
                  ? t.syncing
                  : syncComplete
                  ? t.syncComplete
                  : t.online
                : t.offline}
            </h3>
            <p className="text-xs opacity-90 mt-0.5">
              {isOnline
                ? syncComplete
                  ? t.syncCompleteDesc
                  : isSyncing
                  ? t.dataQueued
                  : t.syncCompleteDesc
                : t.offlineDesc}
            </p>
          </div>

          {/* Progress indicator for syncing */}
          {isSyncing && (
            <div className="w-6 h-6">
              <svg className="animate-spin" viewBox="0 0 24 24" fill="none">
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
            </div>
          )}
        </div>

        {/* Progress bar for syncing */}
        {isSyncing && (
          <div className="mt-3 h-1 bg-white/20 rounded-full overflow-hidden">
            <div className="h-full bg-white rounded-full animate-pulse w-3/4"></div>
          </div>
        )}
      </div>
    </div>
  );
}
