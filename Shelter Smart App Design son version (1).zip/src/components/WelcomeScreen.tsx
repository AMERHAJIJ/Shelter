import { Shield, Globe } from 'lucide-react';

interface WelcomeScreenProps {
  onNavigateToLogin: () => void;
  onNavigateToRegister: () => void;
  onContinueAsGuest: () => void;
  language: 'tr' | 'en' | 'ar';
  onLanguageChange: (lang: 'tr' | 'en' | 'ar') => void;
}

export default function WelcomeScreen({
  onNavigateToLogin,
  onNavigateToRegister,
  onContinueAsGuest,
  language,
  onLanguageChange
}: WelcomeScreenProps) {
  const content = {
    tr: {
      appName: 'Shelter Smart',
      tagline: 'Güvenliğiniz Önceliğimiz',
      description: 'Afet ve acil durumlarda size ve ailenize yardımcı olmak için tasarlandı',
      login: 'Giriş Yap',
      register: 'Hesap Oluştur',
      guest: 'Misafir Olarak Devam Et',
      features: [
        '🗺️ Gerçek zamanlı barınak haritası',
        '👨‍👩‍👧 Aile takip sistemi',
        '🆘 Anında SOS yardım',
        '📱 Dijital akıllı kart'
      ]
    },
    en: {
      appName: 'Shelter Smart',
      tagline: 'Your Safety is Our Priority',
      description: 'Designed to help you and your family during disasters and emergencies',
      login: 'Login',
      register: 'Create Account',
      guest: 'Continue as Guest',
      features: [
        '🗺️ Real-time shelter map',
        '👨‍👩‍👧 Family tracking system',
        '🆘 Instant SOS help',
        '📱 Digital smart card'
      ]
    },
    ar: {
      appName: 'شيلتر سمارت',
      tagline: 'سلامتك أولويتنا',
      description: 'مصمم لمساعدتك أنت وعائلتك خلال الكوارث وحالات الطوارئ',
      login: 'تسجيل الدخول',
      register: 'إنشاء حساب',
      guest: 'متابعة كضيف',
      features: [
        '🗺️ خريطة الملاجئ الحية',
        '👨‍👩‍👧 نظام تتبع العائلة',
        '🆘 مساعدة SOS فورية',
        '📱 البطاقة الذكية الرقمية'
      ]
    }
  };

  const t = content[language];
  const isRTL = language === 'ar';

  return (
    <div className="h-full bg-gradient-to-br from-emergency-blue via-emergency-blue-dark to-safe-green flex flex-col" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Language Selector */}
      <div className="absolute top-6 right-6 z-10">
        <div className="flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full p-1">
          <button
            onClick={() => onLanguageChange('tr')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              language === 'tr'
                ? 'bg-white text-emergency-blue shadow-sm'
                : 'text-white hover:bg-white/10'
            }`}
          >
            TR
          </button>
          <button
            onClick={() => onLanguageChange('en')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              language === 'en'
                ? 'bg-white text-emergency-blue shadow-sm'
                : 'text-white hover:bg-white/10'
            }`}
          >
            EN
          </button>
          <button
            onClick={() => onLanguageChange('ar')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              language === 'ar'
                ? 'bg-white text-emergency-blue shadow-sm'
                : 'text-white hover:bg-white/10'
            }`}
          >
            AR
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col justify-center px-8 pb-12">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-24 h-24 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
            <Shield className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-3">{t.appName}</h1>
          <p className="text-blue-100 text-lg font-medium mb-4">{t.tagline}</p>
          <p className="text-blue-50/80 text-sm max-w-xs mx-auto leading-relaxed">
            {t.description}
          </p>
        </div>

        {/* Features */}
        <div className="space-y-3 mb-8">
          {t.features.map((feature, index) => (
            <div
              key={index}
              className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-white text-sm flex items-center gap-3 animate-in slide-in-from-bottom-4"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <span>{feature}</span>
            </div>
          ))}
        </div>

        {/* Buttons */}
        <div className="space-y-4">
          <button
            onClick={onNavigateToLogin}
            className="w-full bg-white hover:bg-blue-50 text-emergency-blue py-4 rounded-2xl font-bold text-lg shadow-xl transition-all transform active:scale-95"
          >
            {t.login}
          </button>

          <button
            onClick={onNavigateToRegister}
            className="w-full bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white py-4 rounded-2xl font-bold text-lg border-2 border-white/30 transition-all transform active:scale-95"
          >
            {t.register}
          </button>

          <button
            onClick={onContinueAsGuest}
            className="w-full text-white/80 hover:text-white py-3 font-medium text-sm transition-colors"
          >
            {t.guest} →
          </button>
        </div>
      </div>

      {/* Bottom decoration */}
      <div className="h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent"></div>
    </div>
  );
}
