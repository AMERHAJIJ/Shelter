import { useState } from 'react';
import { Shield, ArrowRight, Globe, Eye, EyeOff } from 'lucide-react';

export default function RegistrationScreen({ 
  onComplete,
  language,
  onLanguageChange 
}: { 
  onComplete: (data: any) => void;
  language: 'tr' | 'en' | 'ar';
  onLanguageChange: (lang: 'tr' | 'en' | 'ar') => void;
}) {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    countryCode: '+90',
    password: '',
    homeAddress: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete({
      fullName: formData.fullName,
      phoneNumber: formData.phoneNumber,
      countryCode: formData.countryCode,
      password: formData.password,
      homeAddress: formData.homeAddress
    });
  };

  const text = {
    tr: {
      appName: 'Shelter Smart',
      tagline: 'Güvenliğiniz bizim önceliğimiz',
      createAccount: 'Hesap Oluştur',
      fullName: 'Ad Soyad',
      fullNamePlaceholder: 'Adınızı ve soyadınızı girin',
      phone: 'Telefon Numarası',
      phonePlaceholder: '555 123 4567',
      password: 'Şifre',
      passwordPlaceholder: 'Şifrenizi girin (min 6 karakter)',
      homeAddress: 'Ev Adresi',
      homeAddressPlaceholder: 'Ev adresinizi girin',
      submit: 'Hesap Oluştur',
      guestMode: 'Misafir Olarak Devam Et',
      features: [
        '✓ Gerçek zamanlı barınak takibi',
        '✓ Aile güvenlik sistemi',
        '✓ Anında SOS yardım'
      ]
    },
    en: {
      appName: 'Shelter Smart',
      tagline: 'Your safety is our priority',
      createAccount: 'Create Account',
      fullName: 'Full Name',
      fullNamePlaceholder: 'Enter your full name',
      phone: 'Phone Number',
      phonePlaceholder: '555 123 4567',
      password: 'Password',
      passwordPlaceholder: 'Enter password (min 6 characters)',
      homeAddress: 'Home Address',
      homeAddressPlaceholder: 'Enter your home address',
      submit: 'Create Account',
      guestMode: 'Continue as Guest',
      features: [
        '✓ Real-time shelter tracking',
        '✓ Family safety system',
        '✓ Instant SOS help'
      ]
    },
    ar: {
      appName: 'شيلتر سمارت',
      tagline: 'سلامتك أولويتنا',
      createAccount: 'إنشاء حساب',
      fullName: 'الاسم الكامل',
      fullNamePlaceholder: 'أدخل اسمك الكامل',
      phone: 'رقم الهاتف',
      phonePlaceholder: '555 123 4567',
      password: 'كلمة المرور',
      passwordPlaceholder: 'أدخل كلمة المرور (6 أحرف على الأقل)',
      homeAddress: 'عنوان المنزل',
      homeAddressPlaceholder: 'أدخل عنوان منزلك',
      submit: 'إنشاء حساب',
      guestMode: 'متابعة كضيف',
      features: [
        '✓ تتبع الملاجئ في الوقت الفعلي',
        '✓ نظام سلامة العائلة',
        '✓ مساعدة SOS فورية'
      ]
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  return (
    <div className="h-full bg-gradient-to-b from-blue-50 to-white flex flex-col" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Language Selector */}
      <div className={`absolute top-12 z-10 ${isRTL ? 'left-6' : 'right-6'}`}>
        <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-full shadow-md">
          <button
            onClick={() => onLanguageChange('tr')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              language === 'tr'
                ? 'bg-emergency-blue text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            TR
          </button>
          <button
            onClick={() => onLanguageChange('en')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              language === 'en'
                ? 'bg-emergency-blue text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            EN
          </button>
          <button
            onClick={() => onLanguageChange('ar')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              language === 'ar'
                ? 'bg-emergency-blue text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            AR
          </button>
        </div>
      </div>

      {/* Header */}
      <div className="pt-16 pb-6 px-6 text-center">
        <div className="w-20 h-20 bg-gradient-to-br from-emergency-blue to-safe-green rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-lg">
          <Shield className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">{t.appName}</h1>
        <p className="text-gray-600 text-sm">{t.tagline}</p>
      </div>

      {/* Features */}
      <div className="px-6 mb-4">
        <div className="space-y-2">
          {t.features.map((feature, index) => (
            <div key={index} className="text-sm text-neutral-600 flex items-center gap-2">
              <span>{feature}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Form */}
      <div className="flex-1 px-6 pb-8 overflow-y-auto">
        <div className="bg-white rounded-3xl shadow-xl p-6 border border-neutral-100">
          <h2 className="text-xl font-bold text-gray-900 mb-6 text-center">
            {t.createAccount}
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Full Name */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">
                {t.fullName}
              </label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder={t.fullNamePlaceholder}
                required
                className="w-full px-4 py-3 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors"
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">
                {t.phone}
              </label>
              <div className="flex gap-2">
                <select
                  value={formData.countryCode}
                  onChange={(e) => setFormData({ ...formData, countryCode: e.target.value })}
                  className="w-24 px-3 py-3 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors"
                >
                  <option value="+90">🇹🇷 +90</option>
                  <option value="+1">🇺🇸 +1</option>
                  <option value="+44">🇬🇧 +44</option>
                  <option value="+966">🇸🇦 +966</option>
                  <option value="+971">🇦🇪 +971</option>
                </select>
                <input
                  type="tel"
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  placeholder={t.phonePlaceholder}
                  required
                  className="flex-1 px-4 py-3 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">
                {t.password}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder={t.passwordPlaceholder}
                  required
                  minLength={6}
                  className={`w-full px-4 py-3 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors ${isRTL ? 'pl-12' : 'pr-12'}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute top-1/2 transform -translate-y-1/2 p-2 ${isRTL ? 'left-2' : 'right-2'}`}
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5 text-neutral-400" />
                  ) : (
                    <Eye className="w-5 h-5 text-neutral-400" />
                  )}
                </button>
              </div>
            </div>

            {/* Home Address */}
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">
                {t.homeAddress}
              </label>
              <input
                type="text"
                value={formData.homeAddress}
                onChange={(e) => setFormData({ ...formData, homeAddress: e.target.value })}
                placeholder={t.homeAddressPlaceholder}
                required
                className="w-full px-4 py-3 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-emergency-blue to-emergency-blue-dark hover:from-emergency-blue-dark hover:to-emergency-blue text-white py-4 rounded-xl font-bold text-lg shadow-lg transition-all transform active:scale-95 flex items-center justify-center gap-2"
            >
              {t.submit}
              <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
            </button>

            {/* Guest Mode */}
            <button
              type="button"
              onClick={() => onComplete({})}
              className="w-full text-neutral-600 hover:text-neutral-900 py-3 font-medium text-sm transition-colors"
            >
              {t.guestMode} →
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
