import { useState } from 'react';
import { MapPin, Navigation, Users, CheckCircle, XCircle, AlertCircle, Filter, Search } from 'lucide-react';
import { UserData } from '../App';

interface Shelter {
  id: number;
  name: string;
  type: 'main' | 'small';
  distance: string;
  capacity: number;
  currentOccupancy: number;
  status: 'open' | 'full' | 'closed';
  address: string;
  lat: number;
  lng: number;
}

export default function SheltersMapScreen({ 
  onNavigate, 
  userData,
  language 
}: { 
  onNavigate: (screen: string) => void;
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
}) {
  const [selectedShelter, setSelectedShelter] = useState<Shelter | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'main' | 'small'>('all');

  const text = {
    tr: {
      title: 'Barınak Haritası',
      search: 'Barınak ara...',
      allShelters: 'Tümü',
      mainShelters: 'Ana Barınaklar',
      smallShelters: 'Küçük Barınaklar',
      distance: 'Mesafe',
      capacity: 'Kapasite',
      open: 'Açık',
      full: 'Dolu',
      closed: 'Kapalı',
      getDirections: 'Yol Tarifi Al',
      viewInternal: 'İç Harita',
      nearYou: 'Size yakın',
      available: 'Müsait'
    },
    en: {
      title: 'Shelters Map',
      search: 'Search shelter...',
      allShelters: 'All',
      mainShelters: 'Main Shelters',
      smallShelters: 'Small Shelters',
      distance: 'Distance',
      capacity: 'Capacity',
      open: 'Open',
      full: 'Full',
      closed: 'Closed',
      getDirections: 'Get Directions',
      viewInternal: 'Internal Map',
      nearYou: 'Near you',
      available: 'Available'
    },
    ar: {
      title: 'خريطة المآوي',
      search: 'ابحث عن مأوى...',
      allShelters: 'الكل',
      mainShelters: 'المآوي الرئيسية',
      smallShelters: 'المآوي الصغيرة',
      distance: 'المسافة',
      capacity: 'السعة',
      open: 'مفتوح',
      full: 'ممتلئ',
      closed: 'مغلق',
      getDirections: 'احصل على الاتجاهات',
      viewInternal: 'الخريطة الداخلية',
      nearYou: 'بالقرب منك',
      available: 'متاح'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const shelters: Shelter[] = [
    {
      id: 1,
      name: 'Merkez Kadıköy Barınağı',
      type: 'main',
      distance: '2.3 km',
      capacity: 500,
      currentOccupancy: 324,
      status: 'open',
      address: 'Kadıköy Merkez, İstanbul',
      lat: 40.99,
      lng: 29.03
    },
    {
      id: 2,
      name: 'Moda Spor Salonu',
      type: 'small',
      distance: '3.1 km',
      capacity: 200,
      currentOccupancy: 180,
      status: 'open',
      address: 'Moda, Kadıköy',
      lat: 40.98,
      lng: 29.02
    },
    {
      id: 3,
      name: 'Fenerbahçe Okulu',
      type: 'small',
      distance: '4.5 km',
      capacity: 150,
      currentOccupancy: 150,
      status: 'full',
      address: 'Fenerbahçe, İstanbul',
      lat: 40.97,
      lng: 29.04
    },
    {
      id: 4,
      name: 'Üsküdar Ana Barınak',
      type: 'main',
      distance: '5.2 km',
      capacity: 600,
      currentOccupancy: 420,
      status: 'open',
      address: 'Üsküdar Merkez, İstanbul',
      lat: 41.02,
      lng: 29.01
    },
    {
      id: 5,
      name: 'Bostancı Kültür Merkezi',
      type: 'small',
      distance: '6.8 km',
      capacity: 180,
      currentOccupancy: 0,
      status: 'closed',
      address: 'Bostancı, Kadıköy',
      lat: 40.96,
      lng: 29.05
    }
  ];

  const filteredShelters = shelters.filter(shelter => {
    if (filterType === 'all') return true;
    return shelter.type === filterType;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open': return 'text-green-600';
      case 'full': return 'text-red-600';
      case 'closed': return 'text-gray-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'open': return 'bg-green-100';
      case 'full': return 'bg-red-100';
      case 'closed': return 'bg-gray-100';
      default: return 'bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'open': return t.open;
      case 'full': return t.full;
      case 'closed': return t.closed;
      default: return status;
    }
  };

  return (
    <div className="h-full bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-6 pt-14 pb-6">
        <h1 className="text-white text-2xl font-bold mb-4">{t.title}</h1>
        
        {/* Search Bar */}
        <div className="bg-white rounded-xl p-3 flex items-center gap-3">
          <Search className="w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder={t.search}
            className="flex-1 outline-none text-gray-900"
          />
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="px-6 py-4 flex gap-2 overflow-x-auto">
        <FilterButton
          label={t.allShelters}
          active={filterType === 'all'}
          onClick={() => setFilterType('all')}
          count={shelters.length}
        />
        <FilterButton
          label={t.mainShelters}
          active={filterType === 'main'}
          onClick={() => setFilterType('main')}
          count={shelters.filter(s => s.type === 'main').length}
        />
        <FilterButton
          label={t.smallShelters}
          active={filterType === 'small'}
          onClick={() => setFilterType('small')}
          count={shelters.filter(s => s.type === 'small').length}
        />
      </div>

      {/* Map Preview */}
      <div className="mx-6 mb-4 h-48 bg-gray-200 rounded-2xl relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <MapPin className="w-12 h-12 text-blue-500" />
        </div>
        {/* Map markers */}
        <div className="absolute top-1/4 left-1/3 w-8 h-8 bg-green-500 rounded-full border-4 border-white animate-pulse"></div>
        <div className="absolute top-1/2 right-1/3 w-8 h-8 bg-blue-500 rounded-full border-4 border-white animate-pulse"></div>
        <div className="absolute bottom-1/4 left-1/2 w-8 h-8 bg-red-500 rounded-full border-4 border-white"></div>
      </div>

      {/* Shelters List */}
      <div className="flex-1 px-6 pb-6 overflow-y-auto space-y-3">
        {filteredShelters.map((shelter) => (
          <div
            key={shelter.id}
            onClick={() => setSelectedShelter(shelter)}
            className="bg-white rounded-2xl p-4 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-gray-900">{shelter.name}</h3>
                  {shelter.type === 'main' && (
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-semibold rounded">
                      MAIN
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600">{shelter.address}</p>
              </div>
              <div className={`px-3 py-1 rounded-full ${getStatusBg(shelter.status)}`}>
                <span className={`text-xs font-semibold ${getStatusColor(shelter.status)}`}>
                  {getStatusText(shelter.status)}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4 mb-3">
              <div className="flex items-center gap-1 text-sm text-gray-600">
                <Navigation className="w-4 h-4" />
                <span>{shelter.distance}</span>
              </div>
              <div className="flex items-center gap-1 text-sm text-gray-600">
                <Users className="w-4 h-4" />
                <span>{shelter.currentOccupancy}/{shelter.capacity}</span>
              </div>
            </div>

            {/* Capacity Bar */}
            <div className="mb-3">
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className={`h-full ${
                    shelter.status === 'full' ? 'bg-red-500' :
                    (shelter.currentOccupancy / shelter.capacity) > 0.8 ? 'bg-orange-500' :
                    'bg-green-500'
                  }`}
                  style={{ width: `${Math.min((shelter.currentOccupancy / shelter.capacity) * 100, 100)}%` }}
                ></div>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onNavigate('navigation');
              }}
              disabled={shelter.status === 'closed'}
              className={`w-full py-2 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-colors ${
                shelter.status === 'closed'
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-blue-500 text-white hover:bg-blue-600'
              }`}
            >
              <Navigation className="w-4 h-4" />
              {t.getDirections}
            </button>
          </div>
        ))}
      </div>

      {/* Shelter Details Modal */}
      {selectedShelter && (
        <div className="absolute inset-0 bg-black/50 flex items-end" onClick={() => setSelectedShelter(null)}>
          <div className="bg-white w-full rounded-t-3xl p-6 animate-slide-up" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-1">{selectedShelter.name}</h3>
                <p className="text-sm text-gray-600">{selectedShelter.address}</p>
              </div>
              <div className={`px-3 py-1 rounded-full ${getStatusBg(selectedShelter.status)}`}>
                <span className={`text-xs font-semibold ${getStatusColor(selectedShelter.status)}`}>
                  {getStatusText(selectedShelter.status)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-xs text-gray-500 mb-1">{t.distance}</p>
                <p className="text-lg font-bold text-gray-900">{selectedShelter.distance}</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-3">
                <p className="text-xs text-gray-500 mb-1">{t.capacity}</p>
                <p className="text-lg font-bold text-gray-900">{selectedShelter.currentOccupancy}/{selectedShelter.capacity}</p>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={() => {
                  setSelectedShelter(null);
                  onNavigate('navigation');
                }}
                disabled={selectedShelter.status === 'closed'}
                className={`w-full py-4 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors ${
                  selectedShelter.status === 'closed'
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                <Navigation className="w-5 h-5" />
                {t.getDirections}
              </button>
              {selectedShelter.type === 'main' && (
                <button
                  onClick={() => {
                    setSelectedShelter(null);
                    onNavigate('internalmap');
                  }}
                  className="w-full bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
                >
                  {t.viewInternal}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FilterButton({ 
  label, 
  active, 
  onClick, 
  count 
}: { 
  label: string; 
  active: boolean; 
  onClick: () => void;
  count: number;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-full font-semibold text-sm whitespace-nowrap transition-colors ${
        active
          ? 'bg-blue-500 text-white'
          : 'bg-white text-gray-700 hover:bg-gray-100'
      }`}
    >
      {label} ({count})
    </button>
  );
}