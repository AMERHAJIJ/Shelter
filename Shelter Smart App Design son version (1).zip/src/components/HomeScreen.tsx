import { Bell, MapPin, CreditCard, Users, Map, BookOpen, WifiOff, Navigation, AlertTriangle, CheckCircle, Globe, Settings } from 'lucide-react';
import { UserData } from '../App';

export default function HomeScreen({ 
  onNavigate, 
  userData,
  language,
  onLanguageChange 
}: { 
  onNavigate: (screen: string) => void; 
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
  onLanguageChange: (lang: 'tr' | 'en' | 'ar') => void;
}) {
  const text = {
    tr: {
      welcome: 'Hoş geldiniz',
      currentStatus: 'Mevcut Durum',
      insideShelter: 'Barınaktayım',
      outsideShelter: 'Barınak Dışındayım',
      smartCardSummary: 'Akıllı Kart Özeti',
      cardNumber: 'Kart No',
      familyMembers: 'Aile Üyeleri',
      viewCard: 'Kartı Görüntüle',
      nearestShelter: 'En Yakın Barınak',
      distance: 'Mesafe',
      capacity: 'Kapasite',
      open: 'Açık',
      full: 'Dolu',
      closed: 'Kapalı',
      getDirections: 'Yol Tarifi Al',
      alternative: 'Alternatif Barınak Öner',
      quickActions: 'Hızlı Erişim',
      sheltersMap: 'Barınak Haritası',
      navigation: 'Navigasyon',
      sos: 'SOS Yardım',
      family: 'Aile',
      safetyGuidance: 'Güvenlik Rehberi',
      offlineMode: 'Çevrimdışı Mod',
      emergencyAlert: 'Acil Durum Uyarısı',
      alertMessage: 'Resmi kanallardan güncellemeleri takip edin. Gerekirse tahliye için hazırlıklı olun.',
      offlineAccess: 'İnternetsiz önemli bilgilere erişin',
      members: 'üye'
    },
    en: {
      welcome: 'Welcome',
      currentStatus: 'Current Status',
      insideShelter: 'Inside Shelter',
      outsideShelter: 'Outside Shelter',
      smartCardSummary: 'Smart Card Summary',
      cardNumber: 'Card No',
      familyMembers: 'Family Members',
      viewCard: 'View Card',
      nearestShelter: 'Nearest Shelter',
      distance: 'Distance',
      capacity: 'Capacity',
      open: 'Open',
      full: 'Full',
      closed: 'Closed',
      getDirections: 'Get Directions',
      alternative: 'Suggest Alternative',
      quickActions: 'Quick Actions',
      sheltersMap: 'Shelters Map',
      navigation: 'Navigation',
      sos: 'SOS Help',
      family: 'Family',
      safetyGuidance: 'Safety Guidance',
      offlineMode: 'Offline Mode',
      emergencyAlert: 'Emergency Alert',
      alertMessage: 'Follow official updates. Be prepared for evacuation if needed.',
      offlineAccess: 'Access important info without internet',
      members: 'members'
    },
    ar: {
      welcome: 'مرحباً',
      currentStatus: 'الحالة الحالية',
      insideShelter: 'داخل المأوى',
      outsideShelter: 'خارج المأوى',
      smartCardSummary: 'ملخص البطاقة الذكية',
      cardNumber: 'رقم البطاقة',
      familyMembers: 'أفراد العائلة',
      viewCard: 'عرض البطاقة',
      nearestShelter: 'أقرب مأوى',
      distance: 'المسافة',
      capacity: 'السعة',
      open: 'مفتوح',
      full: 'ممتلئ',
      closed: 'مغلق',
      getDirections: 'الحصول على الاتجاهات',
      alternative: 'اقترح بديل',
      quickActions: 'إجراءات سريعة',
      sheltersMap: 'خريطة المأوى',
      navigation: 'الملاحة',
      sos: 'مساعدة SOS',
      family: 'العائلة',
      safetyGuidance: 'إرشادات السلامة',
      offlineMode: 'وضع عدم الاتصال',
      emergencyAlert: 'تنبيه طوارئ',
      alertMessage: 'تابع التحديثات الرسمية. كن مستعداً للإخلاء إذا لزم الأمر.',
      offlineAccess: 'الوصول إلى معلومات مهمة بدون إنترنت',
      members: 'أعضاء'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const getStatusText = () => {
    return userData.status === 'inside-shelter' ? t.insideShelter : t.outsideShelter;
  };

  const getStatusColor = () => {
    return userData.status === 'inside-shelter' ? 'bg-blue-100 text-blue-600' : 'bg-green-100 text-green-600';
  };

  const getCapacityStatus = () => {
    const percentage = (userData.nearestShelter.currentOccupancy / userData.nearestShelter.capacity) * 100;
    if (percentage >= 100) return { text: t.full, color: 'text-red-600' };
    if (percentage >= 80) return { text: `${Math.round(percentage)}%`, color: 'text-orange-600' };
    return { text: t.open, color: 'text-green-600' };
  };

  const capacityStatus = getCapacityStatus();

  return (
    <div className="h-full bg-gray-50" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-6 pt-14 pb-8 rounded-b-[32px]">
        <div className="flex items-center justify-between mb-6">
          <div>
            <p className="text-blue-100 text-sm mb-1">{t.welcome}</p>
            <h1 className="text-white text-2xl font-bold">{userData.fullName}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onLanguageChange(language === 'tr' ? 'en' : 'tr')}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <Globe className="w-5 h-5 text-white" />
            </button>
            <button 
              onClick={() => onNavigate('settings')}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <Settings className="w-5 h-5 text-white" />
            </button>
            <button className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors relative">
              <Bell className="w-5 h-5 text-white" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
          </div>
        </div>

        {/* User Status */}
        <div className="bg-white rounded-2xl p-4 flex items-center gap-3">
          <div className={`w-12 h-12 ${getStatusColor()} rounded-full flex items-center justify-center`}>
            <MapPin className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <p className="text-sm text-gray-600">{t.currentStatus}</p>
            <p className="font-semibold text-gray-900">{getStatusText()}</p>
          </div>
          <div className={`w-3 h-3 ${userData.status === 'inside-shelter' ? 'bg-blue-500' : 'bg-green-500'} rounded-full animate-pulse`}></div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4">
        {/* Smart Card Summary */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-bold text-gray-900">{t.smartCardSummary}</h2>
            <button
              onClick={() => onNavigate('smartcard')}
              className="text-blue-600 text-sm font-semibold hover:underline"
            >
              {t.viewCard}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-xs text-gray-500">{t.cardNumber}</p>
                <p className="text-sm font-semibold text-gray-900">{userData.userId}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-green-500" />
              <div>
                <p className="text-xs text-gray-500">{t.familyMembers}</p>
                <p className="text-sm font-semibold text-gray-900">{userData.familyMembers} {t.members}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Nearest Shelter */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="font-bold text-gray-900 mb-3">{t.nearestShelter}</h2>
          <div className="bg-blue-50 rounded-xl p-4 mb-3">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-bold text-gray-900">{userData.nearestShelter.name}</h3>
                <p className="text-sm text-gray-600">{userData.nearestShelter.distance} {t.distance.toLowerCase()}</p>
              </div>
              {userData.nearestShelter.status === 'full' && (
                <AlertTriangle className="w-5 h-5 text-red-600" />
              )}
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-blue-100">
              <div>
                <p className="text-xs text-gray-500">{t.capacity}</p>
                <p className={`text-sm font-semibold ${capacityStatus.color}`}>
                  {userData.nearestShelter.currentOccupancy}/{userData.nearestShelter.capacity}
                </p>
              </div>
              <div className={`px-3 py-1 rounded-full ${userData.nearestShelter.status === 'full' ? 'bg-red-100' : 'bg-green-100'}`}>
                <span className={`text-xs font-semibold ${capacityStatus.color}`}>
                  {capacityStatus.text}
                </span>
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <button
              onClick={() => onNavigate('navigation')}
              className="w-full bg-blue-500 text-white py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-blue-600 transition-colors"
            >
              <Navigation className="w-5 h-5" />
              {t.getDirections}
            </button>
            {userData.nearestShelter.status === 'full' && (
              <button className="w-full bg-orange-100 text-orange-700 py-3 rounded-xl font-semibold hover:bg-orange-200 transition-colors">
                {t.alternative}
              </button>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="font-bold text-gray-900 mb-3">{t.quickActions}</h2>
          <div className="grid grid-cols-2 gap-3">
            <QuickActionButton
              icon={Map}
              label={t.sheltersMap}
              color="bg-blue-500"
              onClick={() => onNavigate('sheltersmap')}
            />
            <QuickActionButton
              icon={Navigation}
              label={t.navigation}
              color="bg-green-500"
              onClick={() => onNavigate('navigation')}
            />
            <QuickActionButton
              icon={AlertTriangle}
              label={t.sos}
              color="bg-red-500"
              onClick={() => onNavigate('sos')}
            />
            <QuickActionButton
              icon={Users}
              label={t.family}
              color="bg-purple-500"
              onClick={() => onNavigate('family')}
            />
          </div>
        </div>

        {/* Emergency Alert */}
        <div className="bg-orange-50 border-l-4 border-orange-500 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0">
              <Bell className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="font-semibold text-orange-900 mb-1">{t.emergencyAlert}</p>
              <p className="text-sm text-orange-800">{t.alertMessage}</p>
            </div>
          </div>
        </div>

        {/* Additional Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => onNavigate('safety')}
            className="bg-white rounded-2xl p-4 flex flex-col items-center gap-2 hover:shadow-lg transition-shadow"
          >
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-purple-600" />
            </div>
            <span className="text-sm font-medium text-gray-900 text-center">{t.safetyGuidance}</span>
          </button>
          <button
            onClick={() => onNavigate('offline')}
            className="bg-gray-800 rounded-2xl p-4 flex flex-col items-center gap-2 hover:shadow-lg transition-shadow"
          >
            <div className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center">
              <WifiOff className="w-6 h-6 text-white" />
            </div>
            <span className="text-sm font-medium text-white text-center">{t.offlineMode}</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function QuickActionButton({ 
  icon: Icon, 
  label, 
  color, 
  onClick 
}: { 
  icon: any; 
  label: string; 
  color: string; 
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="bg-white rounded-2xl p-4 flex flex-col items-center gap-3 hover:shadow-lg transition-shadow"
    >
      <div className={`w-12 h-12 ${color} rounded-full flex items-center justify-center`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <span className="text-sm font-medium text-gray-900 text-center">{label}</span>
    </button>
  );
}