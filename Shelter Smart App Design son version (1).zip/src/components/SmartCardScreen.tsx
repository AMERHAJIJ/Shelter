import { QrCode, User, Hash, Home, Users, Baby, PawPrint, Download, MapPin } from 'lucide-react';
import { UserData } from '../App';

export default function SmartCardScreen({ 
  userData,
  language 
}: { 
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
}) {
  const text = {
    tr: {
      title: 'Akıllı Kart',
      subtitle: 'Dijital kimlik kartınız',
      userId: 'Kullanıcı ID',
      assignedShelter: 'Atanan Barınak',
      room: 'Oda',
      familyMembers: 'Aile Üyeleri',
      fullName: 'Ad Soyad',
      phoneNumber: 'Telefon',
      homeAddress: 'Ev Adresi',
      status: 'Durum',
      scanInfo: 'Bu QR kodu barınak personeline gösterin',
      emergencyContact: 'Acil Durum İletişim',
      member: 'üye',
      children: 'Çocuklar',
      pets: 'Evcil Hayvanlar',
      yes: 'Evet',
      no: 'Hayır',
      inside: 'Barınakta',
      outside: 'Barınak Dışında',
      download: 'İndir',
      helpText: 'QR kodu kaydedin veya barınak personeline gösterin'
    },
    en: {
      title: 'Smart Card',
      subtitle: 'Your digital ID card',
      userId: 'User ID',
      assignedShelter: 'Assigned Shelter',
      room: 'Room',
      familyMembers: 'Family Members',
      fullName: 'Full Name',
      phoneNumber: 'Phone',
      homeAddress: 'Home Address',
      status: 'Status',
      scanInfo: 'Show this QR code to shelter staff',
      emergencyContact: 'Emergency Contact',
      member: 'member',
      children: 'Children',
      pets: 'Pets',
      yes: 'Yes',
      no: 'No',
      inside: 'Inside Shelter',
      outside: 'Outside Shelter',
      download: 'Download',
      helpText: 'Save QR code or show to shelter staff'
    },
    ar: {
      title: 'البطاقة الذكية',
      subtitle: 'بطاقة الهوية الرقمية',
      userId: 'معرف المستخدم',
      assignedShelter: 'المأوى المخصص',
      room: 'الغرفة',
      familyMembers: 'أفراد العائلة',
      fullName: 'الاسم الكامل',
      phoneNumber: 'الهاتف',
      homeAddress: 'عنوان المنزل',
      status: 'الحالة',
      scanInfo: 'أظهر رمز QR هذا لموظفي المأوى',
      emergencyContact: 'جهة الاتصال الطارئة',
      member: 'عضو',
      children: 'الأطفال',
      pets: 'الحيوانات الأليفة',
      yes: 'نعم',
      no: 'لا',
      inside: 'داخل المأوى',
      outside: 'خارج المأوى',
      download: 'تحميل',
      helpText: 'احفظ رمز QR أو أظهره لموظفي المأوى'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  return (
    <div className="h-full bg-gradient-to-b from-blue-500 to-blue-600 px-6 pt-14 pb-6">
      <div className="mb-6">
        <h1 className="text-white text-2xl font-bold mb-2">{t.title}</h1>
        <p className="text-blue-100 text-sm">{t.subtitle}</p>
      </div>

      {/* Main Card */}
      <div className="bg-white rounded-3xl p-6 mb-6 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="w-7 h-7 text-blue-600" />
            </div>
            <div>
              <p className="font-bold text-gray-900 text-lg">{userData.fullName}</p>
              <p className="text-sm text-gray-500">{userData.homeAddress}</p>
            </div>
          </div>
        </div>

        {/* QR Code */}
        <div className="bg-gray-50 rounded-2xl p-6 flex items-center justify-center mb-6">
          <div className="w-48 h-48 bg-white rounded-xl flex items-center justify-center border-2 border-gray-200">
            <QrCode className="w-40 h-40 text-gray-900" />
          </div>
        </div>

        {/* Card Details */}
        <div className="space-y-3">
          <DetailRow icon={Hash} label={t.userId} value={userData.userId} />
          <DetailRow icon={MapPin} label={t.assignedShelter} value={userData.assignedShelter} />
          <DetailRow icon={Home} label={t.room} value={userData.shelterRoom} />
          <DetailRow icon={Users} label={t.familyMembers} value={`${userData.familyMembers} ${t.member}`} />
          <DetailRow 
            icon={Baby} 
            label={t.children} 
            value={userData.hasChildren ? `${t.yes} (${userData.childrenCount})` : t.no} 
          />
          <DetailRow icon={PawPrint} label={t.pets} value={userData.hasPets ? t.yes : t.no} />
          <div className="pt-3 border-t border-gray-100">
            <DetailRow 
              icon={User} 
              label={t.status} 
              value={userData.status === 'inside-shelter' ? t.inside : t.outside}
              highlight={userData.status === 'inside-shelter'}
            />
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <button className="w-full bg-white text-blue-600 py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:bg-blue-50 transition-colors">
          <Download className="w-5 h-5" />
          {t.download}
        </button>
        
        <div className="bg-white/20 backdrop-blur rounded-2xl p-4 text-center">
          <p className="text-white text-sm">
            {t.helpText}
          </p>
        </div>
      </div>
    </div>
  );
}

function DetailRow({ 
  icon: Icon, 
  label, 
  value,
  highlight = false 
}: { 
  icon: any; 
  label: string; 
  value: string;
  highlight?: boolean;
}) {
  return (
    <div className="flex items-center gap-3 py-2">
      <div className={`w-10 h-10 ${highlight ? 'bg-blue-100' : 'bg-gray-100'} rounded-lg flex items-center justify-center`}>
        <Icon className={`w-5 h-5 ${highlight ? 'text-blue-600' : 'text-gray-600'}`} />
      </div>
      <div className="flex-1">
        <p className="text-sm text-gray-500">{label}</p>
        <p className={`font-semibold ${highlight ? 'text-blue-600' : 'text-gray-900'}`}>{value}</p>
      </div>
    </div>
  );
}