import { useEffect, useState } from 'react';
import { AlertCircle, CheckCircle, Clock, MapPin, Phone, X, Users, Send } from 'lucide-react';

interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  phoneNumber?: string;
  lastCheckIn?: Date;
  status: 'safe' | 'pending' | 'no-response' | 'unknown';
  location?: string;
}

interface FamilySafetyCheckSystemProps {
  language: 'tr' | 'en' | 'ar';
  familyMembers: FamilyMember[];
  onUpdateMemberStatus: (memberId: string, status: 'safe' | 'no-response') => void;
  emergencyActive: boolean;
}

export default function FamilySafetyCheckSystem({ 
  language, 
  familyMembers, 
  onUpdateMemberStatus,
  emergencyActive 
}: FamilySafetyCheckSystemProps) {
  const [showCheckNotification, setShowCheckNotification] = useState(false);
  const [userResponded, setUserResponded] = useState(false);
  const [checkInTime, setCheckInTime] = useState<Date | null>(null);
  const [showFamilyStatus, setShowFamilyStatus] = useState(false);

  const content = {
    tr: {
      emergencyCheck: 'Acil Durum Kontrol',
      areYouSafe: 'Güvende misiniz?',
      confirmSafety: 'Evet, Güvendeyim',
      needHelp: 'Yardıma İhtiyacım Var',
      dismiss: 'Kapat',
      safetyConfirmed: 'Güvenlik Onaylandı',
      thankYou: 'Teşekkürler! Aileniz bilgilendirildi.',
      familyStatus: 'Aile Durumu',
      checkingFamily: 'Aile üyeleriniz kontrol ediliyor...',
      lastChecked: 'Son kontrol',
      safe: 'Güvende',
      pending: 'Bekliyor',
      noResponse: 'Yanıt Yok',
      unknown: 'Bilinmiyor',
      callNow: 'Şimdi Ara',
      viewLocation: 'Konumu Gör',
      sendReminder: 'Hatırlatma Gönder',
      allSafe: 'Tüm aile üyeleri güvende',
      somePending: 'kişi henüz yanıt vermedi',
      autoCheckInfo: 'Her 30 dakikada bir otomatik kontrol',
      notifyAuthorities: 'Yetkililere Bildir',
      minutes: 'dakika önce',
      hours: 'saat önce',
      justNow: 'Az önce'
    },
    en: {
      emergencyCheck: 'Emergency Check',
      areYouSafe: 'Are you safe?',
      confirmSafety: 'Yes, I\'m Safe',
      needHelp: 'I Need Help',
      dismiss: 'Dismiss',
      safetyConfirmed: 'Safety Confirmed',
      thankYou: 'Thank you! Your family has been notified.',
      familyStatus: 'Family Status',
      checkingFamily: 'Checking your family members...',
      lastChecked: 'Last checked',
      safe: 'Safe',
      pending: 'Pending',
      noResponse: 'No Response',
      unknown: 'Unknown',
      callNow: 'Call Now',
      viewLocation: 'View Location',
      sendReminder: 'Send Reminder',
      allSafe: 'All family members are safe',
      somePending: 'members haven\'t responded yet',
      autoCheckInfo: 'Auto-check every 30 minutes',
      notifyAuthorities: 'Notify Authorities',
      minutes: 'min ago',
      hours: 'hrs ago',
      justNow: 'Just now'
    },
    ar: {
      emergencyCheck: 'فحص الطوارئ',
      areYouSafe: 'هل أنت بأمان؟',
      confirmSafety: 'نعم، أنا بأمان',
      needHelp: 'أحتاج مساعدة',
      dismiss: 'إغلاق',
      safetyConfirmed: 'تم تأكيد السلامة',
      thankYou: 'شكراً! تم إبلاغ عائلتك.',
      familyStatus: 'حالة العائلة',
      checkingFamily: 'جاري التحقق من أفراد عائلتك...',
      lastChecked: 'آخر فحص',
      safe: 'بأمان',
      pending: 'في الانتظار',
      noResponse: 'لا يوجد رد',
      unknown: 'غير معروف',
      callNow: 'اتصل الآن',
      viewLocation: 'عرض الموقع',
      sendReminder: 'إرسال تذكير',
      allSafe: 'جميع أفراد العائلة بأمان',
      somePending: 'لم يردوا بعد',
      autoCheckInfo: 'فحص تلقائي كل 30 دقيقة',
      notifyAuthorities: 'إبلاغ السلطات',
      minutes: 'دقيقة',
      hours: 'ساعة',
      justNow: 'الآن'
    }
  };

  const t = content[language];
  const isRTL = language === 'ar';

  // Simulate emergency check notification
  useEffect(() => {
    if (emergencyActive && !userResponded) {
      setShowCheckNotification(true);
      
      // Auto-check every 30 minutes
      const interval = setInterval(() => {
        if (!userResponded) {
          setShowCheckNotification(true);
        }
      }, 30 * 60 * 1000); // 30 minutes

      return () => clearInterval(interval);
    }
  }, [emergencyActive, userResponded]);

  const handleConfirmSafety = () => {
    setUserResponded(true);
    setCheckInTime(new Date());
    setShowCheckNotification(false);
    
    // Show confirmation
    setTimeout(() => {
      setShowFamilyStatus(true);
    }, 500);

    // Auto-hide after 3 seconds
    setTimeout(() => {
      setShowFamilyStatus(false);
    }, 5000);
  };

  const handleNeedHelp = () => {
    setShowCheckNotification(false);
    // This would trigger SOS
    window.location.hash = '#sos';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'safe':
        return 'bg-safe-green text-white';
      case 'pending':
        return 'bg-warning-orange text-white';
      case 'no-response':
        return 'bg-danger-red text-white';
      default:
        return 'bg-neutral-400 text-white';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe':
        return <CheckCircle className="w-5 h-5" />;
      case 'pending':
        return <Clock className="w-5 h-5" />;
      case 'no-response':
        return <AlertCircle className="w-5 h-5" />;
      default:
        return <AlertCircle className="w-5 h-5" />;
    }
  };

  const getTimeAgo = (date?: Date) => {
    if (!date) return t.unknown;
    
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    
    if (diffMins < 1) return t.justNow;
    if (diffMins < 60) return `${diffMins} ${t.minutes}`;
    return `${diffHours} ${t.hours}`;
  };

  const pendingCount = familyMembers.filter(m => m.status === 'pending' || m.status === 'no-response').length;
  const safeCount = familyMembers.filter(m => m.status === 'safe').length;

  return (
    <>
      {/* Emergency Safety Check Notification */}
      {showCheckNotification && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 px-4 animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 w-full max-w-sm animate-in slide-in-from-bottom-4" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-neutral-900">{t.emergencyCheck}</h3>
              <button
                onClick={() => setShowCheckNotification(false)}
                className="p-1 hover:bg-neutral-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-neutral-400" />
              </button>
            </div>

            <div className="w-16 h-16 bg-warning-orange/10 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <AlertCircle className="w-8 h-8 text-warning-orange" />
            </div>

            <p className="text-center text-lg font-medium mb-6 text-neutral-700">
              {t.areYouSafe}
            </p>

            <div className="space-y-3">
              <button
                onClick={handleConfirmSafety}
                className="w-full bg-safe-green hover:bg-safe-green/90 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all transform active:scale-95"
              >
                <CheckCircle className="w-5 h-5" />
                {t.confirmSafety}
              </button>

              <button
                onClick={handleNeedHelp}
                className="w-full bg-danger-red hover:bg-danger-red/90 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all transform active:scale-95"
              >
                <AlertCircle className="w-5 h-5" />
                {t.needHelp}
              </button>
            </div>

            <p className="text-xs text-neutral-500 text-center mt-4">
              {t.autoCheckInfo}
            </p>
          </div>
        </div>
      )}

      {/* Safety Confirmed Toast */}
      {userResponded && showFamilyStatus && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 px-4 w-full max-w-[360px] animate-in slide-in-from-top-4 fade-in">
          <div className="bg-safe-green rounded-2xl shadow-2xl p-4 text-white" dir={isRTL ? 'rtl' : 'ltr'}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm">{t.safetyConfirmed}</h3>
                <p className="text-xs opacity-90 mt-0.5">{t.thankYou}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Family Status Summary (can be shown separately) */}
      {emergencyActive && (
        <div className="bg-white rounded-2xl p-5 shadow-sm" dir={isRTL ? 'rtl' : 'ltr'}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emergency-blue/10 rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-emergency-blue" />
              </div>
              <div>
                <h3 className="font-bold text-base">{t.familyStatus}</h3>
                <p className="text-xs text-neutral-500">
                  {checkInTime ? `${t.lastChecked}: ${getTimeAgo(checkInTime)}` : t.checkingFamily}
                </p>
              </div>
            </div>
          </div>

          {/* Status Summary */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="bg-safe-green/10 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-safe-green">{safeCount}</div>
              <div className="text-xs text-neutral-600 mt-1">{t.safe}</div>
            </div>
            <div className="bg-warning-orange/10 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-warning-orange">{pendingCount}</div>
              <div className="text-xs text-neutral-600 mt-1">{t.pending}</div>
            </div>
            <div className="bg-emergency-blue/10 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-emergency-blue">{familyMembers.length}</div>
              <div className="text-xs text-neutral-600 mt-1">Total</div>
            </div>
          </div>

          {/* Family Members List */}
          <div className="space-y-3">
            {familyMembers.map((member) => (
              <div
                key={member.id}
                className="border border-neutral-200 rounded-xl p-3 hover:bg-neutral-50 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium text-sm">{member.name}</h4>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${getStatusColor(member.status)} flex items-center gap-1`}>
                        {getStatusIcon(member.status)}
                        {t[member.status as keyof typeof t] || member.status}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-500">{member.relation}</p>
                    {member.location && (
                      <div className="flex items-center gap-1 mt-2 text-xs text-neutral-600">
                        <MapPin className="w-3 h-3" />
                        {member.location}
                      </div>
                    )}
                    {member.lastCheckIn && (
                      <p className="text-xs text-neutral-400 mt-1">
                        {getTimeAgo(member.lastCheckIn)}
                      </p>
                    )}
                  </div>

                  {/* Quick Actions */}
                  <div className="flex flex-col gap-2">
                    {member.phoneNumber && member.status === 'no-response' && (
                      <button className="p-2 bg-emergency-blue/10 hover:bg-emergency-blue/20 rounded-lg transition-colors">
                        <Phone className="w-4 h-4 text-emergency-blue" />
                      </button>
                    )}
                    {member.status === 'pending' && (
                      <button className="p-2 bg-warning-orange/10 hover:bg-warning-orange/20 rounded-lg transition-colors">
                        <Send className="w-4 h-4 text-warning-orange" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Alert for non-responders */}
          {pendingCount > 0 && (
            <div className="mt-4 bg-warning-orange/10 border border-warning-orange/20 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-warning-orange flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-neutral-900 mb-1">
                    {pendingCount} {t.somePending}
                  </p>
                  <button className="text-xs text-warning-orange font-medium hover:underline">
                    {t.notifyAuthorities} →
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
}
