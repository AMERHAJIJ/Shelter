import { BookOpen, AlertTriangle, Package, Baby, Home, CheckCircle } from 'lucide-react';

export default function SafetyGuidanceScreen({ 
  onBack,
  language 
}: { 
  onBack: () => void;
  language: 'tr' | 'en' | 'ar';
}) {
  const text = {
    tr: {
      title: 'Güvenlik Rehberi',
      subtitle: 'Deprem güvenliği bilgileri',
      beforeQuake: 'Deprem Öncesi',
      duringQuake: 'Deprem Sırasında',
      afterQuake: 'Deprem Sonrası',
      emergencyKit: 'Acil Durum Çantası',
      dropCoverHold: 'ÇÖK - SIĞIN - TUTUN',
      stayCalm: 'Sakin kalın',
      findShelter: 'Güvenli yer bulun',
      awayFromWindows: 'Camlardan uzak durun',
      checkInjuries: 'Yaralanmaları kontrol edin',
      evacuate: 'Binayı terk edin',
      aftershocks: 'Artçı sarsıntılara dikkat'
    },
    en: {
      title: 'Safety Guidance',
      subtitle: 'Earthquake safety information',
      beforeQuake: 'Before Earthquake',
      duringQuake: 'During Earthquake',
      afterQuake: 'After Earthquake',
      emergencyKit: 'Emergency Kit',
      dropCoverHold: 'DROP - COVER - HOLD',
      stayCalm: 'Stay calm',
      findShelter: 'Find safe shelter',
      awayFromWindows: 'Stay away from windows',
      checkInjuries: 'Check for injuries',
      evacuate: 'Evacuate building',
      aftershocks: 'Watch for aftershocks'
    },
    ar: {
      title: 'إرشادات السلامة',
      subtitle: 'معلومات سلامة الزلازل',
      beforeQuake: 'قبل الزلزال',
      duringQuake: 'أثناء الزلزال',
      afterQuake: 'بعد الزلزال',
      emergencyKit: 'حقيبة الطوارئ',
      dropCoverHold: 'انخفض - احتمِ - تمسك',
      stayCalm: 'ابق هادئاً',
      findShelter: 'ابحث عن مكان آمن',
      awayFromWindows: 'ابتعد عن النوافذ',
      checkInjuries: 'تحقق من الإصابات',
      evacuate: 'أخل المبنى',
      aftershocks: 'انتبه للهزات الارتدادية'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const beforeSteps = [
    t.stayCalm,
    t.findShelter,
    t.awayFromWindows,
    t.checkInjuries,
    t.evacuate
  ];

  const duringSteps = [
    t.dropCoverHold
  ];

  const afterSteps = [
    t.aftershocks
  ];

  return (
    <div className="h-full bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-purple-600 px-6 pt-14 pb-6">
        <button onClick={onBack} className="text-white mb-4">← {t.title}</button>
        <p className="text-purple-100 text-sm">{t.subtitle}</p>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4 overflow-y-auto pb-24">
        {/* Offline Notice */}
        <div className="bg-green-50 border-l-4 border-green-500 rounded-xl p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
          <p className="text-sm text-green-800 font-medium">{t.offlineAvailable}</p>
        </div>

        {/* Before Earthquake */}
        <SectionCard
          icon={AlertTriangle}
          title={t.beforeQuake}
          color="bg-red-500"
          items={beforeSteps}
        />

        {/* During Earthquake */}
        <SectionCard
          icon={AlertTriangle}
          title={t.duringQuake}
          color="bg-red-500"
          items={duringSteps}
        />

        {/* After Earthquake */}
        <SectionCard
          icon={Home}
          title={t.afterQuake}
          color="bg-orange-500"
          items={afterSteps}
        />
      </div>
    </div>
  );
}

function SectionCard({ 
  icon: Icon, 
  title, 
  color, 
  items 
}: { 
  icon: any; 
  title: string; 
  color: string; 
  items: string[];
}) {
  return (
    <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
      <div className={`${color} px-4 py-3 flex items-center gap-3`}>
        <Icon className="w-6 h-6 text-white" />
        <h3 className="font-bold text-white">{title}</h3>
      </div>
      <div className="p-4">
        <div className="space-y-3">
          {items.map((item, index) => (
            <div key={index} className="flex items-start gap-3">
              <div className={`w-6 h-6 ${color} rounded-full flex items-center justify-center flex-shrink-0`}>
                <span className="text-xs font-bold text-white">{index + 1}</span>
              </div>
              <p className="text-sm text-gray-700 pt-0.5">{item}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}