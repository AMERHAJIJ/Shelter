import { MapPin, Users, Baby, Heart, Utensils, Church, DoorOpen, AlertCircle } from 'lucide-react';
import { UserData } from '../App';

export default function InternalMapScreen({ 
  onBack, 
  userData,
  language 
}: { 
  onBack: () => void;
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
}) {
  const text = {
    tr: {
      title: 'İç Harita',
      subtitle: 'Barınak iç haritası',
      yourRoom: 'Odanız',
      facilities: 'Tesisler',
      restrooms: 'Tuvaletler',
      medicalAid: 'Sağlık',
      diningArea: 'Yemek Alanı',
      mainEntrance: 'Ana Giriş',
      emergencyExit: 'Acil Çıkış',
      infoDesk: 'Danışma'
    },
    en: {
      title: 'Internal Map',
      subtitle: 'Shelter floor plan',
      yourRoom: 'Your Room',
      facilities: 'Facilities',
      restrooms: 'Restrooms',
      medicalAid: 'Medical',
      diningArea: 'Dining',
      mainEntrance: 'Main Entrance',
      emergencyExit: 'Emergency Exit',
      infoDesk: 'Info Desk'
    },
    ar: {
      title: 'الخريطة الداخلية',
      subtitle: 'مخطط المأوى',
      yourRoom: 'غرفتك',
      facilities: 'المرافق',
      restrooms: 'دورات المياه',
      medicalAid: 'طبي',
      diningArea: 'تناول الطعام',
      mainEntrance: 'المدخل الرئيسي',
      emergencyExit: 'مخرج الطوارئ',
      infoDesk: 'مكتب المعلومات'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const areas = [
    { icon: Users, label: t.facilities, color: 'bg-blue-500' },
    { icon: Baby, label: t.facilities, color: 'bg-pink-500' },
    { icon: Heart, label: t.facilities, color: 'bg-purple-500' },
    { icon: Utensils, label: t.diningArea, color: 'bg-green-500' },
    { icon: MapPin, label: t.restrooms, color: 'bg-cyan-500' },
    { icon: Heart, label: t.medicalAid, color: 'bg-red-500' },
    { icon: Church, label: t.facilities, color: 'bg-orange-500' },
    { icon: DoorOpen, label: t.emergencyExit, color: 'bg-gray-700' }
  ];

  return (
    <div className="h-full bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-6 pt-14 pb-6">
        <button onClick={onBack} className="text-white mb-4">← {t.title}</button>
        <p className="text-blue-100 text-sm">{t.subtitle}</p>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4">
        {/* Your Location Card */}
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-2xl p-4 shadow-lg">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm text-blue-100">{t.yourRoom}</p>
              <p className="text-xl font-bold">{userData.shelterRoom}</p>
            </div>
          </div>
          <p className="text-sm text-blue-100">{t.facilities}: {t.facilities}</p>
        </div>

        {/* Offline Notice */}
        <div className="bg-green-50 border-l-4 border-green-500 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
          <p className="text-sm text-green-800 font-medium">{t.offline}</p>
        </div>

        {/* Simplified 2D Map */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-4">{t.legend}</h3>
          
          {/* Map Grid */}
          <div className="bg-gray-100 rounded-xl p-4 mb-4 min-h-[300px] relative">
            {/* Floor layout simulation */}
            <div className="grid grid-cols-3 gap-2 h-full">
              {/* Row 1 */}
              <div className="bg-blue-500/20 border-2 border-blue-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <Users className="w-6 h-6 text-blue-600 mb-1" />
                <span className="text-xs text-blue-900 font-semibold text-center">{t.facilities}</span>
                {/* User's location marker */}
                <div className="mt-2 w-3 h-3 bg-blue-600 rounded-full animate-pulse"></div>
              </div>
              <div className="bg-pink-500/20 border-2 border-pink-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <Baby className="w-6 h-6 text-pink-600 mb-1" />
                <span className="text-xs text-pink-900 font-semibold text-center">{t.facilities}</span>
              </div>
              <div className="bg-purple-500/20 border-2 border-purple-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <Heart className="w-6 h-6 text-purple-600 mb-1" />
                <span className="text-xs text-purple-900 font-semibold text-center">{t.facilities}</span>
              </div>
              
              {/* Row 2 */}
              <div className="bg-green-500/20 border-2 border-green-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <Utensils className="w-6 h-6 text-green-600 mb-1" />
                <span className="text-xs text-green-900 font-semibold text-center">{t.diningArea}</span>
              </div>
              <div className="bg-cyan-500/20 border-2 border-cyan-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <MapPin className="w-6 h-6 text-cyan-600 mb-1" />
                <span className="text-xs text-cyan-900 font-semibold text-center">{t.restrooms}</span>
              </div>
              <div className="bg-red-500/20 border-2 border-red-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <Heart className="w-6 h-6 text-red-600 mb-1" />
                <span className="text-xs text-red-900 font-semibold text-center">{t.medicalAid}</span>
              </div>
              
              {/* Row 3 */}
              <div className="bg-orange-500/20 border-2 border-orange-500 rounded-lg p-2 flex flex-col items-center justify-center">
                <Church className="w-6 h-6 text-orange-600 mb-1" />
                <span className="text-xs text-orange-900 font-semibold text-center">{t.facilities}</span>
              </div>
              <div className="bg-gray-700/20 border-2 border-gray-700 rounded-lg p-2 flex flex-col items-center justify-center">
                <DoorOpen className="w-6 h-6 text-gray-700 mb-1" />
                <span className="text-xs text-gray-900 font-semibold text-center">{t.emergencyExit}</span>
              </div>
              <div className="bg-gray-700/20 border-2 border-gray-700 rounded-lg p-2 flex flex-col items-center justify-center">
                <DoorOpen className="w-6 h-6 text-gray-700 mb-1" />
                <span className="text-xs text-gray-900 font-semibold text-center">{t.emergencyExit}</span>
              </div>
            </div>
          </div>

          {/* Legend List */}
          <div className="grid grid-cols-2 gap-2">
            {areas.map((area, index) => (
              <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                <div className={`w-8 h-8 ${area.color} rounded-lg flex items-center justify-center`}>
                  <area.icon className="w-4 h-4 text-white" />
                </div>
                <span className="text-xs font-medium text-gray-700">{area.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}