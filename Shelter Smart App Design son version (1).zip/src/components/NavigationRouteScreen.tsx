import { useState, useEffect } from 'react';
import { Navigation, MapPin, Clock, AlertCircle, Phone, ChevronRight } from 'lucide-react';
import { UserData } from '../App';

export default function NavigationRouteScreen({ 
  onBack, 
  userData,
  language 
}: { 
  onBack: () => void;
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
}) {
  const [eta, setEta] = useState(18);
  const [isRerouting, setIsRerouting] = useState(false);

  const text = {
    tr: {
      title: 'Navigasyon',
      destination: 'Varış Noktası',
      currentLocation: 'Mevcut Konumunuz',
      eta: 'Tahmini Varış',
      minutes: 'dakika',
      distance: 'Mesafe',
      capacity: 'Kapasite',
      status: 'Durum',
      available: 'Müsait',
      full: 'Dolu',
      rerouting: 'Yeniden yönlendiriliyor...',
      shelterFull: 'Barınak dolu - Alternatif öneriliyor',
      alternative: 'Alternatif Barınak',
      accept: 'Kabul Et',
      decline: 'Reddet',
      emergency: 'Acil Durum',
      call: 'Ara 112',
      directions: 'Yönlendirmeler',
      turnRight: 'Sağa dönün',
      goStraight: 'Düz gidin',
      turnLeft: 'Sola dönün',
      arrive: 'Varış noktasına ulaştınız'
    },
    en: {
      title: 'Navigation',
      destination: 'Destination',
      currentLocation: 'Your Location',
      eta: 'ETA',
      minutes: 'min',
      distance: 'Distance',
      capacity: 'Capacity',
      status: 'Status',
      available: 'Available',
      full: 'Full',
      rerouting: 'Rerouting...',
      shelterFull: 'Shelter full - Suggesting alternative',
      alternative: 'Alternative Shelter',
      accept: 'Accept',
      decline: 'Decline',
      emergency: 'Emergency',
      call: 'Call 112',
      directions: 'Directions',
      turnRight: 'Turn right',
      goStraight: 'Go straight',
      turnLeft: 'Turn left',
      arrive: 'You have arrived'
    },
    ar: {
      title: 'الملاحة',
      destination: 'الوجهة',
      currentLocation: 'موقعك الحالي',
      eta: 'الوقت المقدر',
      minutes: 'دقيقة',
      distance: 'المسافة',
      capacity: 'السعة',
      status: 'الحالة',
      available: 'متاح',
      full: 'ممتلئ',
      rerouting: 'إعادة التوجيه...',
      shelterFull: 'المأوى ممتلئ - اقتراح بديل',
      alternative: 'مأوى بديل',
      accept: 'قبول',
      decline: 'رفض',
      emergency: 'طوارئ',
      call: 'اتصل 112',
      directions: 'الاتجاهات',
      turnRight: 'انعطف يميناً',
      goStraight: 'استمر مباشرة',
      turnLeft: 'انعطف يساراً',
      arrive: 'لقد وصلت'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  // Simulate ETA countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setEta(prev => Math.max(0, prev - 1));
    }, 60000); // Update every minute
    return () => clearInterval(interval);
  }, []);

  // Simulate shelter becoming full
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsRerouting(true);
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const directions = [
    { instruction: t.goStraight, distance: '500 m' },
    { instruction: t.turnRight, distance: '200 m' },
    { instruction: t.goStraight, distance: '1.2 km' },
    { instruction: t.turnLeft, distance: '400 m' },
    { instruction: t.arrive, distance: '' }
  ];

  return (
    <div className="h-full bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-6 pt-14 pb-6">
        <button onClick={onBack} className="text-white mb-4 flex items-center gap-2">
          ← {t.title}
        </button>
      </div>

      {/* Map Area */}
      <div className="relative h-64 bg-gray-200">
        <div className="absolute inset-0 flex items-center justify-center">
          <Navigation className="w-16 h-16 text-blue-500" />
        </div>
        {/* Current location marker */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <div className="w-4 h-4 bg-blue-600 rounded-full border-4 border-white animate-pulse"></div>
        </div>
        {/* Destination marker */}
        <div className="absolute top-8 left-1/2 transform -translate-x-1/2">
          <MapPin className="w-8 h-8 text-red-600" />
        </div>
        {/* Route line visualization */}
        <div className="absolute top-1/4 left-1/2 w-1 h-1/2 bg-blue-500 opacity-50"></div>
      </div>

      {/* ETA Card */}
      <div className="mx-6 -mt-6 bg-white rounded-2xl shadow-lg p-4 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">{t.eta}</p>
              <p className="text-2xl font-bold text-gray-900">{eta} {t.minutes}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">{t.distance}</p>
            <p className="text-lg font-bold text-gray-900">{userData.nearestShelter.distance}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-4 overflow-y-auto space-y-4">
        {/* Destination Info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-3">{t.destination}</h3>
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="font-semibold text-gray-900">{userData.nearestShelter.name}</p>
              <p className="text-sm text-gray-600">{userData.homeAddress}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-gray-100">
            <div>
              <p className="text-xs text-gray-500">{t.capacity}</p>
              <p className="text-sm font-semibold text-gray-900">
                {userData.nearestShelter.currentOccupancy}/{userData.nearestShelter.capacity}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500">{t.status}</p>
              <p className="text-sm font-semibold text-green-600">{t.available}</p>
            </div>
          </div>
        </div>

        {/* Rerouting Alert */}
        {isRerouting && (
          <div className="bg-orange-50 border-l-4 border-orange-500 rounded-xl p-4 animate-slide-down">
            <div className="flex items-start gap-3 mb-3">
              <AlertCircle className="w-6 h-6 text-orange-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-orange-900 mb-1">{t.rerouting}</p>
                <p className="text-sm text-orange-800">{t.shelterFull}</p>
              </div>
            </div>
            <div className="bg-white rounded-xl p-3">
              <p className="text-sm font-semibold text-gray-900 mb-1">{t.alternative}</p>
              <p className="text-sm text-gray-600">Üsküdar Ana Barınak - 5.2 km</p>
              <div className="flex gap-2 mt-3">
                <button className="flex-1 bg-orange-500 text-white py-2 rounded-lg font-semibold hover:bg-orange-600 transition-colors">
                  {t.accept}
                </button>
                <button 
                  onClick={() => setIsRerouting(false)}
                  className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg font-semibold hover:bg-gray-200 transition-colors"
                >
                  {t.decline}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Emergency Button */}
        <button className="w-full bg-red-500 text-white rounded-2xl p-4 flex items-center justify-center gap-3 hover:bg-red-600 transition-colors">
          <Phone className="w-6 h-6" />
          <div className="text-left">
            <p className="font-bold">{t.emergency}</p>
            <p className="text-sm text-red-100">{t.call}</p>
          </div>
        </button>

        {/* Step by Step Directions */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-3">{t.directions}</h3>
          <div className="space-y-3">
            {directions.map((step, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-blue-600">{index + 1}</span>
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{step.instruction}</p>
                  {step.distance && (
                    <p className="text-sm text-gray-500">{step.distance}</p>
                  )}
                </div>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}