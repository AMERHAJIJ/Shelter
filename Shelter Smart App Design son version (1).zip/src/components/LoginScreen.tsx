import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff, Phone, Lock, AlertCircle } from 'lucide-react';
import { UserData } from '../App';

interface LoginScreenProps {
  onBack: () => void;
  onLogin: (userData: Partial<UserData>) => void;
  onForgotPassword: () => void;
  language: 'tr' | 'en' | 'ar';
}

export default function LoginScreen({ onBack, onLogin, onForgotPassword, language }: LoginScreenProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [countryCode, setCountryCode] = useState('+90');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const content = {
    tr: {
      title: 'Giriş Yap',
      subtitle: 'Hesabınıza giriş yapın',
      phoneLabel: 'Telefon Numarası',
      phonePlaceholder: '555 123 4567',
      passwordLabel: 'Şifre',
      passwordPlaceholder: 'Şifrenizi girin',
      loginButton: 'Giriş Yap',
      forgotPassword: 'Şifremi Unuttum?',
      noAccount: 'Hesabınız yok mu?',
      register: 'Kayıt Ol',
      errorInvalid: 'Geçersiz telefon numarası veya şifre',
      errorEmpty: 'Lütfen tüm alanları doldurun'
    },
    en: {
      title: 'Login',
      subtitle: 'Sign in to your account',
      phoneLabel: 'Phone Number',
      phonePlaceholder: '555 123 4567',
      passwordLabel: 'Password',
      passwordPlaceholder: 'Enter your password',
      loginButton: 'Login',
      forgotPassword: 'Forgot Password?',
      noAccount: 'Don\'t have an account?',
      register: 'Register',
      errorInvalid: 'Invalid phone number or password',
      errorEmpty: 'Please fill in all fields'
    },
    ar: {
      title: 'تسجيل الدخول',
      subtitle: 'سجل دخول إلى حسابك',
      phoneLabel: 'رقم الهاتف',
      phonePlaceholder: '555 123 4567',
      passwordLabel: 'كلمة المرور',
      passwordPlaceholder: 'أدخل كلمة المرور',
      loginButton: 'تسجيل الدخول',
      forgotPassword: 'نسيت كلمة المرور؟',
      noAccount: 'ليس لديك حساب؟',
      register: 'إنشاء حساب',
      errorInvalid: 'رقم الهاتف أو كلمة المرور غير صحيحة',
      errorEmpty: 'الرجاء ملء جميع الحقول'
    }
  };

  const t = content[language];
  const isRTL = language === 'ar';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!phoneNumber || !password) {
      setError(t.errorEmpty);
      return;
    }

    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      // Demo: Accept any phone with password "123456"
      if (password === '123456' || password === 'demo') {
        onLogin({
          fullName: 'Ahmet Yılmaz',
          phoneNumber: phoneNumber,
          countryCode: countryCode,
          userId: 'SS-2024-' + Math.floor(Math.random() * 1000000),
        });
      } else {
        setError(t.errorInvalid);
        setIsLoading(false);
      }
    }, 1000);
  };

  return (
    <div className="h-full bg-gradient-to-br from-emergency-blue-light to-white flex flex-col" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <button
          onClick={onBack}
          className="mb-6 p-2 -ml-2 hover:bg-white/50 rounded-lg transition-colors"
        >
          <ArrowLeft className={`w-6 h-6 text-neutral-700 ${isRTL ? 'rotate-180' : ''}`} />
        </button>
        <h1 className="text-3xl font-bold text-neutral-900 mb-2">{t.title}</h1>
        <p className="text-neutral-600">{t.subtitle}</p>
      </div>

      {/* Form */}
      <div className="flex-1 bg-white rounded-t-[32px] px-6 py-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Error Message */}
          {error && (
            <div className="bg-danger-red/10 border border-danger-red/20 rounded-xl p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-danger-red flex-shrink-0 mt-0.5" />
              <p className="text-sm text-danger-red">{error}</p>
            </div>
          )}

          {/* Phone Number */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">
              {t.phoneLabel}
            </label>
            <div className="flex gap-2">
              <select
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="w-24 px-3 py-4 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors"
              >
                <option value="+90">🇹🇷 +90</option>
                <option value="+1">🇺🇸 +1</option>
                <option value="+44">🇬🇧 +44</option>
                <option value="+966">🇸🇦 +966</option>
                <option value="+971">🇦🇪 +971</option>
              </select>
              <div className="flex-1 relative">
                <Phone className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 text-neutral-400 ${isRTL ? 'right-4' : 'left-4'}`} />
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder={t.phonePlaceholder}
                  className={`w-full ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'} py-4 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors`}
                />
              </div>
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-2">
              {t.passwordLabel}
            </label>
            <div className="relative">
              <Lock className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 text-neutral-400 ${isRTL ? 'right-4' : 'left-4'}`} />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                className={`w-full ${isRTL ? 'pr-12 pl-12' : 'pl-12 pr-12'} py-4 border-2 border-neutral-200 rounded-xl focus:border-emergency-blue focus:outline-none transition-colors`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className={`absolute top-1/2 transform -translate-y-1/2 p-2 ${isRTL ? 'left-2' : 'right-2'}`}
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5 text-neutral-400" />
                ) : (
                  <Eye className="w-5 h-5 text-neutral-400" />
                )}
              </button>
            </div>
          </div>

          {/* Forgot Password */}
          <button
            type="button"
            onClick={onForgotPassword}
            className="text-sm text-emergency-blue hover:underline font-medium"
          >
            {t.forgotPassword}
          </button>

          {/* Login Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-emergency-blue hover:bg-emergency-blue-dark text-white py-4 rounded-xl font-bold text-lg shadow-lg transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>{t.loginButton}...</span>
              </>
            ) : (
              t.loginButton
            )}
          </button>

          {/* Demo Info */}
          <div className="bg-neutral-100 rounded-xl p-4 text-center">
            <p className="text-xs text-neutral-600">
              Demo: Use any phone number with password <span className="font-bold">123456</span>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
