import { WifiOff, QrCode, MapPin, AlertCircle, Map, Phone, Info, CheckCircle } from 'lucide-react';
import { UserData } from '../App';

export default function OfflineModeScreen({ 
  onBack, 
  userData,
  language 
}: { 
  onBack: () => void; 
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
}) {
  const text = {
    tr: {
      title: 'Çevrimdışı Mod',
      subtitle: 'İnternet olmadan erişilebilir bilgiler',
      offlineMode: 'Çevrimdışı Mod Aktif',
      savedData: 'Kaydedilen Veriler',
      lastSync: 'Son Senkronizasyon',
      shelterInfo: 'Barınak Bilgileri',
      familyData: 'Aile Verileri',
      emergencyContacts: 'Acil İletişim',
      safetyGuides: 'Güvenlik Rehberleri',
      internalMaps: 'İç Haritalar',
      synced: 'Senkronize',
      notSynced: 'Senkronize Değil',
      syncNow: 'Şimdi Senkronize Et',
      dataSize: 'Veri Boyutu'
    },
    en: {
      title: 'Offline Mode',
      subtitle: 'Information available without internet',
      offlineMode: 'Offline Mode Active',
      savedData: 'Saved Data',
      lastSync: 'Last Sync',
      shelterInfo: 'Shelter Information',
      familyData: 'Family Data',
      emergencyContacts: 'Emergency Contacts',
      safetyGuides: 'Safety Guides',
      internalMaps: 'Internal Maps',
      synced: 'Synced',
      notSynced: 'Not Synced',
      syncNow: 'Sync Now',
      dataSize: 'Data Size'
    },
    ar: {
      title: 'وضع عدم الاتصال',
      subtitle: 'المعلومات المتاحة بدون إنترنت',
      offlineMode: 'وضع عدم الاتصال نشط',
      savedData: 'البيانات المحفوظة',
      lastSync: 'آخر مزامنة',
      shelterInfo: 'معلومات المأوى',
      familyData: 'بيانات العائلة',
      emergencyContacts: 'جهات اتصال الطوارئ',
      safetyGuides: 'أدلة السلامة',
      internalMaps: 'الخرائط الداخلية',
      synced: 'متزامن',
      notSynced: 'غير متزامن',
      syncNow: 'مزامنة الآن',
      dataSize: 'حجم البيانات'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  return (
    <div className="h-full bg-gray-900 text-white">
      {/* Header */}
      <div className="px-6 pt-14 pb-6 border-b border-gray-800">
        <button onClick={onBack} className="text-white mb-4">← {t.title}</button>
        <div className="flex items-center gap-3 mb-2">
          <WifiOff className="w-8 h-8 text-orange-500" />
          <h1 className="text-2xl font-bold">{t.title}</h1>
        </div>
        <p className="text-gray-400 text-sm">{t.subtitle}</p>
      </div>

      {/* Status Banner */}
      <div className="px-6 py-4">
        <div className="bg-orange-500/20 border border-orange-500 rounded-2xl p-4 flex items-center gap-3">
          <AlertCircle className="w-6 h-6 text-orange-500 flex-shrink-0" />
          <div>
            <p className="font-semibold text-orange-100 mb-1">{t.offlineMode}</p>
            <p className="text-sm text-orange-200">{t.savedData}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 pb-6 space-y-4 overflow-y-auto">
        {/* Smart Card */}
        <OfflineCard
          icon={QrCode}
          title={t.yourSmartCard}
          description={t.showAtEntry}
        >
          <div className="bg-white rounded-xl p-4 mt-3">
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-sm text-gray-600">{t.name}</p>
                <p className="font-bold text-gray-900">{userData.fullName}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.userId}</p>
                <p className="font-bold text-gray-900">{userData.userId}</p>
              </div>
            </div>
            <div className="w-full h-32 bg-gray-100 rounded-lg flex items-center justify-center">
              <QrCode className="w-24 h-24 text-gray-400" />
            </div>
            <div className="mt-3 text-center">
              <p className="text-sm text-gray-600">{t.room}: {userData.shelterRoom}</p>
            </div>
          </div>
        </OfflineCard>

        {/* Assigned Shelter */}
        <OfflineCard
          icon={MapPin}
          title={t.assignedShelter}
          description={t.yourAssigned}
        >
          <div className="bg-gray-800 rounded-xl p-4 mt-3">
            <h3 className="font-bold text-white mb-2">{userData.assignedShelter}</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-300">
                <MapPin className="w-4 h-4" />
                <span>{userData.homeAddress}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <Phone className="w-4 h-4" />
                <span>{t.emergency}: 112</span>
              </div>
            </div>
          </div>
        </OfflineCard>

        {/* Static Map */}
        <OfflineCard
          icon={Map}
          title={t.shelterMap}
          description={t.basicLayout}
        >
          <div className="bg-gray-800 rounded-xl p-4 mt-3">
            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="bg-blue-500/20 border border-blue-500 rounded-lg p-2 text-center">
                <p className="text-blue-400">{t.families}</p>
              </div>
              <div className="bg-red-500/20 border border-red-500 rounded-lg p-2 text-center">
                <p className="text-red-400">{t.health}</p>
              </div>
              <div className="bg-green-500/20 border border-green-500 rounded-lg p-2 text-center">
                <p className="text-green-400">{t.food}</p>
              </div>
              <div className="bg-cyan-500/20 border border-cyan-500 rounded-lg p-2 text-center">
                <p className="text-cyan-400">{t.bathrooms}</p>
              </div>
              <div className="bg-pink-500/20 border border-pink-500 rounded-lg p-2 text-center">
                <p className="text-pink-400">{t.children}</p>
              </div>
              <div className="bg-purple-500/20 border border-purple-500 rounded-lg p-2 text-center">
                <p className="text-purple-400">{t.pets}</p>
              </div>
            </div>
          </div>
        </OfflineCard>

        {/* Safety Instructions */}
        <OfflineCard
          icon={Info}
          title={t.safetyInstructions}
          description={t.emergencyProtocols}
        >
          <div className="mt-3 space-y-2">
            <SafetyInstruction number="1" text={t.instruction1} />
            <SafetyInstruction number="2" text={t.instruction2} />
            <SafetyInstruction number="3" text={t.instruction3} />
            <SafetyInstruction number="4" text={t.instruction4} />
          </div>
        </OfflineCard>

        {/* Emergency Contacts */}
        <div className="bg-red-500/20 border-2 border-red-500 rounded-2xl p-4">
          <h3 className="font-bold text-red-400 mb-3">{t.emergencyContacts}</h3>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">{t.emergencyServices}</span>
              <span className="font-bold text-white text-lg">112</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">{t.fire}</span>
              <span className="font-bold text-white text-lg">110</span>
            </div>
          </div>
        </div>

        {/* Local Storage Notice */}
        <div className="bg-green-500/20 border border-green-500 rounded-2xl p-4 flex items-center gap-3">
          <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
          <p className="text-sm text-green-300">{t.localStorage}</p>
        </div>

        {/* Reconnect Info */}
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-4 text-center">
          <WifiOff className="w-8 h-8 text-gray-600 mx-auto mb-2" />
          <p className="text-sm text-gray-400">
            {t.reconnectInfo}
          </p>
        </div>
      </div>
    </div>
  );
}

function OfflineCard({ 
  icon: Icon, 
  title, 
  description, 
  children 
}: { 
  icon: any; 
  title: string; 
  description: string; 
  children: React.ReactNode;
}) {
  return (
    <div className="bg-gray-800 rounded-2xl overflow-hidden border border-gray-700">
      <div className="bg-gray-700/50 px-4 py-3 flex items-center gap-3">
        <Icon className="w-5 h-5 text-gray-300" />
        <div>
          <h3 className="font-bold text-white">{title}</h3>
          <p className="text-xs text-gray-400">{description}</p>
        </div>
      </div>
      <div className="p-4">
        {children}
      </div>
    </div>
  );
}

function SafetyInstruction({ number, text }: { number: string; text: string }) {
  return (
    <div className="flex items-start gap-3 bg-gray-800 rounded-xl p-3">
      <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
        <span className="text-xs font-bold text-white">{number}</span>
      </div>
      <p className="text-sm text-gray-300 pt-0.5">{text}</p>
    </div>
  );
}