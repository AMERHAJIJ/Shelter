import { useState } from 'react';
import { AlertCircle, Phone, Ambulance, Car, Users, MapPin, Send, CheckCircle } from 'lucide-react';
import { UserData } from '../App';

export default function SOSScreen({ 
  onNavigate, 
  userData,
  language 
}: { 
  onNavigate: (screen: string) => void;
  userData: UserData;
  language: 'tr' | 'en' | 'ar';
}) {
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestType, setRequestType] = useState<'sos' | 'transport' | 'ambulance' | 'other'>('sos');
  const [requestSent, setRequestSent] = useState(false);

  const text = {
    tr: {
      title: 'Acil Yardım',
      subtitle: 'Anında yardım talep edin',
      sosButton: 'ACİL DURUM SOS',
      transport: 'Ulaşım Talebi',
      ambulance: 'Ambulans',
      helpOther: 'Başkası İçin Yardım',
      yourLocation: 'Konumunuz',
      requestHelp: 'Yardım Talep Et',
      requestType: 'Talep Türü',
      description: 'Açıklama',
      descriptionPlaceholder: 'Durumu açıklayın...',
      sendRequest: 'Talep Gönder',
      cancel: 'İptal',
      requestSuccess: 'Talebiniz Gönderildi',
      successMessage: 'Yardım ekiplerine bildirildi. En kısa sürede size ulaşacaklar.',
      close: 'Kapat',
      emergencyCall: 'Acil Arama',
      call112: 'Ara 112',
      emergencyContacts: 'Acil İletişim Numaraları',
      ambulanceService: 'Ambulans',
      fireService: 'İtfaiye',
      policeService: 'Polis',
      offlineNote: 'Çevrimdışı mod: Talepler internet bağlantısı gelince gönderilecek'
    },
    en: {
      title: 'Emergency Help',
      subtitle: 'Request immediate assistance',
      sosButton: 'EMERGENCY SOS',
      transport: 'Transport Request',
      ambulance: 'Ambulance',
      helpOther: 'Help Someone Else',
      yourLocation: 'Your Location',
      requestHelp: 'Request Help',
      requestType: 'Request Type',
      description: 'Description',
      descriptionPlaceholder: 'Describe the situation...',
      sendRequest: 'Send Request',
      cancel: 'Cancel',
      requestSuccess: 'Request Sent',
      successMessage: 'Help teams have been notified. They will reach you soon.',
      close: 'Close',
      emergencyCall: 'Emergency Call',
      call112: 'Call 112',
      emergencyContacts: 'Emergency Contact Numbers',
      ambulanceService: 'Ambulance',
      fireService: 'Fire',
      policeService: 'Police',
      offlineNote: 'Offline mode: Requests will be sent when internet connection is restored'
    },
    ar: {
      title: 'مساعدة طارئة',
      subtitle: 'اطلب المساعدة الفورية',
      sosButton: 'طوارئ SOS',
      transport: 'طلب نقل',
      ambulance: 'إسعاف',
      helpOther: 'مساعدة شخص آخر',
      yourLocation: 'موقعك',
      requestHelp: 'طلب مساعدة',
      requestType: 'نوع الطلب',
      description: 'الوصف',
      descriptionPlaceholder: 'صف الموقف...',
      sendRequest: 'إرسال الطلب',
      cancel: 'إلغاء',
      requestSuccess: 'تم إرسال طلبك',
      successMessage: 'تم إبلاغ فرق المساعدة. سيصلون إليك قريباً.',
      close: 'إغلاق',
      emergencyCall: 'مكالمة طوارئ',
      call112: 'اتصل 112',
      emergencyContacts: 'أرقام الطوارئ',
      ambulanceService: 'إسعاف',
      fireService: 'إطفاء',
      policeService: 'شرطة',
      offlineNote: 'وضع عدم الاتصال: سيتم إرسال الطلبات عند استعادة الاتصال بالإنترنت'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const handleRequestSubmit = () => {
    setRequestSent(true);
    setTimeout(() => {
      setRequestSent(false);
      setShowRequestModal(false);
    }, 3000);
  };

  return (
    <div className="h-full bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-red-500 to-red-600 px-6 pt-14 pb-8">
        <h1 className="text-white text-2xl font-bold mb-2">{t.title}</h1>
        <p className="text-red-100 text-sm">{t.subtitle}</p>
      </div>

      {/* Content */}
      <div className="px-6 py-6 space-y-4">
        {/* Main SOS Button */}
        <button
          onClick={() => {
            setRequestType('sos');
            setShowRequestModal(true);
          }}
          className="w-full bg-red-500 text-white rounded-3xl py-8 font-bold text-xl flex flex-col items-center justify-center gap-3 hover:bg-red-600 transition-colors shadow-lg animate-pulse"
        >
          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
            <AlertCircle className="w-12 h-12" />
          </div>
          {t.sosButton}
        </button>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <ActionButton
            icon={Car}
            label={t.transport}
            color="bg-blue-500"
            onClick={() => {
              setRequestType('transport');
              setShowRequestModal(true);
            }}
          />
          <ActionButton
            icon={Ambulance}
            label={t.ambulance}
            color="bg-orange-500"
            onClick={() => {
              setRequestType('ambulance');
              setShowRequestModal(true);
            }}
          />
        </div>

        <ActionButton
          icon={Users}
          label={t.helpOther}
          color="bg-purple-500"
          onClick={() => {
            setRequestType('other');
            setShowRequestModal(true);
          }}
          fullWidth
        />

        {/* Location Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <MapPin className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">{t.yourLocation}</p>
              <p className="font-semibold text-gray-900">{userData.currentLocation}</p>
            </div>
          </div>
          <div className="h-32 bg-gray-100 rounded-xl flex items-center justify-center">
            <MapPin className="w-8 h-8 text-gray-400" />
          </div>
        </div>

        {/* Emergency Call */}
        <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-4 text-white">
          <h3 className="font-bold mb-3">{t.emergencyCall}</h3>
          <a
            href="tel:112"
            className="w-full bg-white text-red-600 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-red-50 transition-colors"
          >
            <Phone className="w-5 h-5" />
            {t.call112}
          </a>
        </div>

        {/* Emergency Contacts */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-3">{t.emergencyContacts}</h3>
          <div className="space-y-2">
            <ContactRow service={t.ambulanceService} number="112" />
            <ContactRow service={t.fireService} number="110" />
            <ContactRow service={t.policeService} number="155" />
          </div>
        </div>

        {/* Offline Notice */}
        <div className="bg-orange-50 border-l-4 border-orange-500 rounded-xl p-4">
          <p className="text-sm text-orange-800">{t.offlineNote}</p>
        </div>
      </div>

      {/* Request Modal */}
      {showRequestModal && !requestSent && (
        <div className="absolute inset-0 bg-black/50 flex items-end">
          <div className="bg-white w-full rounded-t-3xl p-6 animate-slide-up">
            <h3 className="text-xl font-bold text-gray-900 mb-4">{t.requestHelp}</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t.requestType}
                </label>
                <select
                  value={requestType}
                  onChange={(e) => setRequestType(e.target.value as any)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="sos">{t.sosButton}</option>
                  <option value="transport">{t.transport}</option>
                  <option value="ambulance">{t.ambulance}</option>
                  <option value="other">{t.helpOther}</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {t.description}
                </label>
                <textarea
                  placeholder={t.descriptionPlaceholder}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div className="bg-gray-50 rounded-xl p-3 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-700">{userData.currentLocation}</span>
              </div>
            </div>

            <div className="space-y-3">
              <button
                onClick={handleRequestSubmit}
                className="w-full bg-red-500 text-white py-4 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-red-600 transition-colors"
              >
                <Send className="w-5 h-5" />
                {t.sendRequest}
              </button>
              <button
                onClick={() => setShowRequestModal(false)}
                className="w-full bg-gray-100 text-gray-700 py-4 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {requestSent && (
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="bg-white rounded-3xl p-8 mx-6 text-center animate-scale-up">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">{t.requestSuccess}</h3>
            <p className="text-gray-600 mb-6">{t.successMessage}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionButton({ 
  icon: Icon, 
  label, 
  color, 
  onClick,
  fullWidth = false 
}: { 
  icon: any; 
  label: string; 
  color: string; 
  onClick: () => void;
  fullWidth?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`${fullWidth ? 'w-full' : ''} bg-white rounded-2xl p-4 flex ${fullWidth ? 'flex-row' : 'flex-col'} items-center ${fullWidth ? 'justify-start' : 'justify-center'} gap-3 hover:shadow-lg transition-shadow`}
    >
      <div className={`w-12 h-12 ${color} rounded-full flex items-center justify-center`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <span className="text-sm font-semibold text-gray-900">{label}</span>
    </button>
  );
}

function ContactRow({ service, number }: { service: string; number: string }) {
  return (
    <a
      href={`tel:${number}`}
      className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0 hover:bg-gray-50 rounded-lg px-2 transition-colors"
    >
      <span className="text-sm text-gray-700">{service}</span>
      <div className="flex items-center gap-2">
        <span className="font-bold text-gray-900 text-lg">{number}</span>
        <Phone className="w-4 h-4 text-blue-600" />
      </div>
    </a>
  );
}