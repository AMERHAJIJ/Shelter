# 🌍 Arabic Language Integration - Bulk Updates Required

## Files That Need Arabic Support

The following files need to be updated to add Arabic language support. Each file needs:

1. Change type definition from `'tr' | 'en'` to `'tr' | 'en' | 'ar'`
2. Add Arabic translations to the `text` or `content` object
3. Add `const isRTL = language === 'ar';`
4. Add `dir={isRTL ? 'rtl' : 'ltr'}` to the main container div
5. Update icon positions for RTL (left/right swaps)

---

## Files List (10 files remaining):

### 1. `/components/SmartCardScreen.tsx`
- Line 9: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section to `text` object
- Add RTL support

### 2. `/components/SOSScreen.tsx`
- Line 12: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section to content
- Add RTL support

### 3. `/components/FamilyScreen.tsx`
- Line 23: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

### 4. `/components/SheltersMapScreen.tsx`
- Line 25: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

### 5. `/components/NavigationRouteScreen.tsx`
- Line 12: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

### 6. `/components/InternalMapScreen.tsx`
- Line 11: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

### 7. `/components/SafetyGuidanceScreen.tsx`
- Line 8: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

### 8. `/components/OfflineModeScreen.tsx`
- Line 11: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

### 9. `/components/SettingsScreen.tsx`
- Line 6-7: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Line 7: Change `onLanguageChange: (lang: 'tr' | 'en')` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add 3-way language switcher
- Add RTL support

### 10. `/components/OnlineStatusNotification.tsx`
- Line 5: Change `language: 'tr' | 'en'` to `'tr' | 'en' | 'ar'`
- Add `ar` section
- Add RTL support

---

## Arabic Translations Reference

Common translations to use across all files:

```typescript
ar: {
  // Common
  back: 'رجوع',
  save: 'حفظ',
  cancel: 'إلغاء',
  delete: 'حذف',
  edit: 'تعديل',
  add: 'إضافة',
  confirm: 'تأكيد',
  close: 'إغلاق',
  
  // Status
  open: 'مفتوح',
  closed: 'مغلق',
  full: 'ممتلئ',
  available: 'متاح',
  
  // Family
  family: 'العائلة',
  familyMembers: 'أفراد العائلة',
  addMember: 'إضافة فرد',
  
  // Emergency
  sos: 'طوارئ',
  emergency: 'حالة طوارئ',
  help: 'مساعدة',
  
  // Location
  location: 'الموقع',
  distance: 'المسافة',
  navigation: 'الملاحة',
  directions: 'الاتجاهات',
  
  // Shelter
  shelter: 'المأوى',
  shelters: 'المآوي',
  capacity: 'السعة',
  nearestShelter: 'أقرب مأوى'
}
```

---

## RTL Support Pattern

For each component, add after language constant:

```typescript
const t = text[language];
const isRTL = language === 'ar';
```

And in the main container:

```tsx
<div className="..." dir={isRTL ? 'rtl' : 'ltr'}>
```

For icons that need directional awareness:

```tsx
<ArrowLeft className={`... ${isRTL ? 'rotate-180' : ''}`} />
```

For positioning:

```tsx
className={`${isRTL ? 'right-4' : 'left-4'}`}
className={`${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'}`}
```

---

## Priority Order

**High Priority** (Core Features):
1. SOSScreen ⚠️
2. FamilyScreen 👨‍👩‍👧
3. SmartCardScreen 🎫
4. SheltersMapScreen 🗺️

**Medium Priority**:
5. NavigationRouteScreen 🧭
6. SettingsScreen ⚙️

**Low Priority** (Secondary Features):
7. InternalMapScreen
8. SafetyGuidanceScreen
9. OfflineModeScreen
10. OnlineStatusNotification

---

## Next Steps

Apply updates in the priority order listed above.
