import { useState } from 'react';
import { AlertCircle, Ambulance, Navigation, Phone, MapPin, Clock, CheckCircle, XCircle, Play } from 'lucide-react';

interface EmergencyRequest {
  id: number;
  type: 'sos' | 'ambulance' | 'transfer';
  name: string;
  location: string;
  coordinates: { lat: number; lng: number };
  timestamp: string;
  status: 'new' | 'in-progress' | 'completed';
  priority: 'high' | 'medium' | 'low';
  phone: string;
  notes?: string;
}

export default function EmergencyRequestsScreen({ language }: { language: 'tr' | 'en' | 'ar' }) {
  const [requests, setRequests] = useState<EmergencyRequest[]>([
    {
      id: 1,
      type: 'sos',
      name: 'Mehmet Yılmaz',
      location: 'Kadıköy, İstanbul',
      coordinates: { lat: 40.99, lng: 29.03 },
      timestamp: '2 min ago',
      status: 'new',
      priority: 'high',
      phone: '+90 555 123 4567',
      notes: 'Trapped in building, 3rd floor'
    },
    {
      id: 2,
      type: 'ambulance',
      name: 'Ayşe Demir',
      location: 'Beşiktaş, İstanbul',
      coordinates: { lat: 41.04, lng: 29.00 },
      timestamp: '5 min ago',
      status: 'in-progress',
      priority: 'high',
      phone: '+90 555 987 6543',
      notes: 'Injured leg, needs medical attention'
    },
    {
      id: 3,
      type: 'transfer',
      name: 'Ali Kaya',
      location: 'Şişli, İstanbul',
      coordinates: { lat: 41.06, lng: 28.99 },
      timestamp: '12 min ago',
      status: 'completed',
      priority: 'medium',
      phone: '+90 555 456 7890',
      notes: 'Family of 5, needs transportation to shelter'
    },
    {
      id: 4,
      type: 'sos',
      name: 'Fatma Öz',
      location: 'Üsküdar, İstanbul',
      coordinates: { lat: 41.02, lng: 29.07 },
      timestamp: '18 min ago',
      status: 'new',
      priority: 'high',
      phone: '+90 555 234 5678'
    }
  ]);

  const [filter, setFilter] = useState<'all' | 'sos' | 'ambulance' | 'transfer'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'new' | 'in-progress' | 'completed'>('all');

  const text = {
    tr: {
      title: 'Acil Durum Talepleri',
      subtitle: 'Tüm acil durum çağrılarını yönetin',
      all: 'Tümü',
      sos: 'SOS',
      ambulance: 'Ambulans',
      transfer: 'Nakil',
      new: 'Yeni',
      inProgress: 'İşlemde',
      completed: 'Tamamlandı',
      high: 'Yüksek',
      medium: 'Orta',
      low: 'Düşük',
      call: 'Ara',
      navigate: 'Navigasyon',
      markInProgress: 'İşleme Al',
      markCompleted: 'Tamamlandı Olarak İşaretle',
      priority: 'Öncelik',
      location: 'Konum',
      time: 'Zaman',
      status: 'Durum',
      actions: 'İşlemler',
      notes: 'Notlar'
    },
    en: {
      title: 'Emergency Requests',
      subtitle: 'Manage all emergency calls',
      all: 'All',
      sos: 'SOS',
      ambulance: 'Ambulance',
      transfer: 'Transfer',
      new: 'New',
      inProgress: 'In Progress',
      completed: 'Completed',
      high: 'High',
      medium: 'Medium',
      low: 'Low',
      call: 'Call',
      navigate: 'Navigate',
      markInProgress: 'Start Processing',
      markCompleted: 'Mark Completed',
      priority: 'Priority',
      location: 'Location',
      time: 'Time',
      status: 'Status',
      actions: 'Actions',
      notes: 'Notes'
    },
    ar: {
      title: 'طلبات الطوارئ',
      subtitle: 'إدارة جميع مكالمات الطوارئ',
      all: 'الكل',
      sos: 'SOS',
      ambulance: 'إسعاف',
      transfer: 'نقل',
      new: 'جديد',
      inProgress: 'قيد المعالجة',
      completed: 'مكتمل',
      high: 'عالي',
      medium: 'متوسط',
      low: 'منخفض',
      call: 'اتصال',
      navigate: 'الملاحة',
      markInProgress: 'بدء المعالجة',
      markCompleted: 'تعليم كمكتمل',
      priority: 'الأولوية',
      location: 'الموقع',
      time: 'الوقت',
      status: 'الحالة',
      actions: 'الإجراءات',
      notes: 'ملاحظات'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const filteredRequests = requests
    .filter(r => filter === 'all' || r.type === filter)
    .filter(r => statusFilter === 'all' || r.status === statusFilter);

  const stats = {
    total: requests.length,
    new: requests.filter(r => r.status === 'new').length,
    inProgress: requests.filter(r => r.status === 'in-progress').length,
    completed: requests.filter(r => r.status === 'completed').length,
    sos: requests.filter(r => r.type === 'sos').length,
    ambulance: requests.filter(r => r.type === 'ambulance').length,
    transfer: requests.filter(r => r.type === 'transfer').length
  };

  const updateStatus = (id: number, newStatus: 'new' | 'in-progress' | 'completed') => {
    setRequests(requests.map(r => r.id === id ? { ...r, status: newStatus } : r));
  };

  const typeIcons = {
    sos: AlertCircle,
    ambulance: Ambulance,
    transfer: Navigation
  };

  const typeColors = {
    sos: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-200', badge: 'bg-red-500' },
    ambulance: { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200', badge: 'bg-orange-500' },
    transfer: { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200', badge: 'bg-blue-500' }
  };

  const statusColors = {
    new: 'bg-red-100 text-red-700',
    'in-progress': 'bg-yellow-100 text-yellow-700',
    completed: 'bg-green-100 text-green-700'
  };

  const priorityColors = {
    high: 'bg-red-500',
    medium: 'bg-orange-500',
    low: 'bg-gray-500'
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3 mb-6">
          <StatBox label={t.all} value={stats.total} color="gray" />
          <StatBox label={t.new} value={stats.new} color="red" />
          <StatBox label={t.inProgress} value={stats.inProgress} color="yellow" />
          <StatBox label={t.completed} value={stats.completed} color="green" />
          <StatBox label={t.sos} value={stats.sos} color="red" />
          <StatBox label={t.ambulance} value={stats.ambulance} color="orange" />
          <StatBox label={t.transfer} value={stats.transfer} color="blue" />
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl p-4 mb-6 border border-gray-100">
          <div className="flex flex-wrap gap-3">
            <FilterButton label={t.all} active={filter === 'all'} onClick={() => setFilter('all')} />
            <FilterButton label={t.sos} active={filter === 'sos'} onClick={() => setFilter('sos')} color="red" />
            <FilterButton label={t.ambulance} active={filter === 'ambulance'} onClick={() => setFilter('ambulance')} color="orange" />
            <FilterButton label={t.transfer} active={filter === 'transfer'} onClick={() => setFilter('transfer')} color="blue" />
            <div className="w-px bg-gray-200" />
            <FilterButton label={t.new} active={statusFilter === 'new'} onClick={() => setStatusFilter('new')} />
            <FilterButton label={t.inProgress} active={statusFilter === 'in-progress'} onClick={() => setStatusFilter('in-progress')} />
            <FilterButton label={t.completed} active={statusFilter === 'completed'} onClick={() => setStatusFilter('completed')} />
          </div>
        </div>

        {/* Requests List */}
        <div className="space-y-4">
          {filteredRequests.map(request => {
            const Icon = typeIcons[request.type];
            const colors = typeColors[request.type];

            return (
              <div key={request.id} className={`bg-white rounded-2xl p-6 border-2 ${colors.border} hover:shadow-lg transition-shadow`}>
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div className={`${colors.bg} w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0`}>
                    <Icon className={`w-7 h-7 ${colors.text}`} />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    {/* Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-bold text-gray-900 mb-1">{request.name}</h3>
                        <div className="flex items-center gap-3 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            <span>{request.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            <span>{request.timestamp}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {/* Priority Badge */}
                        <div className={`${priorityColors[request.priority]} w-3 h-3 rounded-full`} title={request.priority} />
                        {/* Status Badge */}
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[request.status]}`}>
                          {t[request.status === 'in-progress' ? 'inProgress' : request.status]}
                        </span>
                      </div>
                    </div>

                    {/* Notes */}
                    {request.notes && (
                      <div className="bg-gray-50 rounded-lg p-3 mb-3">
                        <p className="text-sm text-gray-700">{request.notes}</p>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex flex-wrap gap-2">
                      <a
                        href={`tel:${request.phone}`}
                        className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-600 rounded-lg font-semibold hover:bg-green-100 transition-colors"
                      >
                        <Phone className="w-4 h-4" />
                        {t.call}
                      </a>
                      <button className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg font-semibold hover:bg-blue-100 transition-colors">
                        <MapPin className="w-4 h-4" />
                        {t.navigate}
                      </button>
                      {request.status === 'new' && (
                        <button
                          onClick={() => updateStatus(request.id, 'in-progress')}
                          className="flex items-center gap-2 px-4 py-2 bg-yellow-50 text-yellow-600 rounded-lg font-semibold hover:bg-yellow-100 transition-colors"
                        >
                          <Play className="w-4 h-4" />
                          {t.markInProgress}
                        </button>
                      )}
                      {request.status === 'in-progress' && (
                        <button
                          onClick={() => updateStatus(request.id, 'completed')}
                          className="flex items-center gap-2 px-4 py-2 bg-green-50 text-green-600 rounded-lg font-semibold hover:bg-green-100 transition-colors"
                        >
                          <CheckCircle className="w-4 h-4" />
                          {t.markCompleted}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, color }: { label: string; value: number; color: string }) {
  const colors = {
    gray: 'bg-gray-100 text-gray-700',
    red: 'bg-red-100 text-red-700',
    yellow: 'bg-yellow-100 text-yellow-700',
    green: 'bg-green-100 text-green-700',
    orange: 'bg-orange-100 text-orange-700',
    blue: 'bg-blue-100 text-blue-700'
  };

  return (
    <div className={`${colors[color]} rounded-xl p-4 text-center`}>
      <p className="text-2xl font-bold mb-1">{value}</p>
      <p className="text-xs font-semibold">{label}</p>
    </div>
  );
}

function FilterButton({ label, active, onClick, color = 'gray' }: any) {
  const colors = {
    gray: active ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200',
    red: active ? 'bg-red-600 text-white' : 'bg-red-50 text-red-600 hover:bg-red-100',
    orange: active ? 'bg-orange-600 text-white' : 'bg-orange-50 text-orange-600 hover:bg-orange-100',
    blue: active ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
  };

  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${colors[color]}`}
    >
      {label}
    </button>
  );
}
