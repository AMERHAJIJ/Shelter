import { useState } from 'react';
import { Building2, MapPin, Plus, Edit, Trash2, ToggleLeft, ToggleRight, Link } from 'lucide-react';

interface Shelter {
  id: number;
  name: string;
  location: string;
  type: 'main' | 'small';
  status: 'open' | 'closed';
  linkedTo?: number; // For small shelters linked to main
  capacity: number;
  current: number;
}

export default function ManageSheltersScreen({ language, onBack }: { language: 'tr' | 'en' | 'ar'; onBack: () => void }) {
  const [shelters, setShelters] = useState<Shelter[]>([
    { id: 1, name: 'Merkez Kadıköy Barınağı', location: 'Kadıköy, İstanbul', type: 'main', status: 'open', capacity: 500, current: 324 },
    { id: 2, name: 'Moda İlkokulu', location: 'Moda, Kadıköy', type: 'small', status: 'open', linkedTo: 1, capacity: 150, current: 98 },
    { id: 3, name: 'Beşiktaş Spor Salonu', location: 'Beşiktaş, İstanbul', type: 'main', status: 'open', capacity: 600, current: 600 },
    { id: 4, name: 'Şişli Kültür Merkezi', location: 'Şişli, İstanbul', type: 'small', status: 'open', linkedTo: 3, capacity: 200, current: 145 }
  ]);

  const [showAddModal, setShowAddModal] = useState(false);

  const text = {
    tr: {
      title: 'Barınak Yönetimi',
      addShelter: 'Yeni Barınak Ekle',
      shelterName: 'Barınak Adı',
      location: 'Konum',
      type: 'Tür',
      mainShelter: 'Ana Barınak',
      smallShelter: 'Küçük Barınak',
      status: 'Durum',
      open: 'Açık',
      closed: 'Kapalı',
      capacity: 'Kapasite',
      currentOccupancy: 'Mevcut Doluluk',
      linkedTo: 'Bağlı Olduğu Ana Barınak',
      actions: 'İşlemler',
      edit: 'Düzenle',
      delete: 'Sil',
      toggleStatus: 'Durumu Değiştir'
    },
    en: {
      title: 'Shelter Management',
      addShelter: 'Add New Shelter',
      shelterName: 'Shelter Name',
      location: 'Location',
      type: 'Type',
      mainShelter: 'Main Shelter',
      smallShelter: 'Small Shelter',
      status: 'Status',
      open: 'Open',
      closed: 'Closed',
      capacity: 'Capacity',
      currentOccupancy: 'Current Occupancy',
      linkedTo: 'Linked to Main Shelter',
      actions: 'Actions',
      edit: 'Edit',
      delete: 'Delete',
      toggleStatus: 'Toggle Status'
    },
    ar: {
      title: 'إدارة المآوي',
      addShelter: 'إضافة مأوى جديد',
      shelterName: 'اسم المأوى',
      location: 'الموقع',
      type: 'النوع',
      mainShelter: 'مأوى رئيسي',
      smallShelter: 'مأوى صغير',
      status: 'الحالة',
      open: 'مفتوح',
      closed: 'مغلق',
      capacity: 'السعة',
      currentOccupancy: 'الإشغال الحالي',
      linkedTo: 'مرتبط بالمأوى الرئيسي',
      actions: 'الإجراءات',
      edit: 'تعديل',
      delete: 'حذف',
      toggleStatus: 'تبديل الحالة'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const toggleShelterStatus = (id: number) => {
    setShelters(shelters.map(s => 
      s.id === id ? { ...s, status: s.status === 'open' ? 'closed' : 'open' } : s
    ));
  };

  const getLinkedShelterName = (linkedId?: number) => {
    if (!linkedId) return '-';
    const linked = shelters.find(s => s.id === linkedId);
    return linked ? linked.name : '-';
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
            <p className="text-gray-600 mt-1">Manage all shelters in the system</p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold flex items-center gap-2 hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            {t.addShelter}
          </button>
        </div>

        {/* Shelters Table */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.shelterName}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.location}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.type}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.status}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.capacity}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.linkedTo}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {shelters.map(shelter => {
                  const percentage = Math.round((shelter.current / shelter.capacity) * 100);
                  return (
                    <tr key={shelter.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            shelter.type === 'main' ? 'bg-blue-100' : 'bg-green-100'
                          }`}>
                            <Building2 className={`w-5 h-5 ${
                              shelter.type === 'main' ? 'text-blue-600' : 'text-green-600'
                            }`} />
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">{shelter.name}</p>
                            <p className="text-xs text-gray-500">ID: {shelter.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-gray-600">
                          <MapPin className="w-4 h-4" />
                          <span className="text-sm">{shelter.location}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                          shelter.type === 'main' 
                            ? 'bg-blue-50 text-blue-600' 
                            : 'bg-green-50 text-green-600'
                        }`}>
                          {shelter.type === 'main' ? t.mainShelter : t.smallShelter}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => toggleShelterStatus(shelter.id)}
                          className="flex items-center gap-2"
                        >
                          {shelter.status === 'open' ? (
                            <>
                              <ToggleRight className="w-6 h-6 text-green-600" />
                              <span className="text-sm font-semibold text-green-600">{t.open}</span>
                            </>
                          ) : (
                            <>
                              <ToggleLeft className="w-6 h-6 text-gray-400" />
                              <span className="text-sm font-semibold text-gray-500">{t.closed}</span>
                            </>
                          )}
                        </button>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-semibold text-gray-900">
                              {shelter.current} / {shelter.capacity}
                            </span>
                            <span className={`text-xs font-semibold ${
                              percentage >= 90 ? 'text-red-600' : percentage >= 70 ? 'text-orange-600' : 'text-green-600'
                            }`}>
                              {percentage}%
                            </span>
                          </div>
                          <div className="w-32 bg-gray-100 rounded-full h-2 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                percentage >= 90 ? 'bg-red-500' : percentage >= 70 ? 'bg-orange-500' : 'bg-green-500'
                              }`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {shelter.type === 'small' ? (
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Link className="w-4 h-4" />
                            <span>{getLinkedShelterName(shelter.linkedTo)}</span>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">-</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button className="p-2 hover:bg-blue-50 rounded-lg text-blue-600 transition-colors">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="p-2 hover:bg-red-50 rounded-lg text-red-600 transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">Total Shelters</p>
            <p className="text-2xl font-bold text-gray-900">{shelters.length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">Main Shelters</p>
            <p className="text-2xl font-bold text-blue-600">{shelters.filter(s => s.type === 'main').length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">Small Shelters</p>
            <p className="text-2xl font-bold text-green-600">{shelters.filter(s => s.type === 'small').length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 border border-gray-100">
            <p className="text-sm text-gray-600 mb-1">Open Shelters</p>
            <p className="text-2xl font-bold text-emerald-600">{shelters.filter(s => s.status === 'open').length}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
