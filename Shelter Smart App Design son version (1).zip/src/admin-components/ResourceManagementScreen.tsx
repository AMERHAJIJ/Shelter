import { useState } from 'react';
import { Droplet, Heart, Package, AlertTriangle, CheckCircle, TrendingDown, Plus } from 'lucide-react';

interface Resource {
  id: string;
  name: string;
  icon: any;
  color: string;
}

interface ShelterResource {
  shelter: string;
  resources: {
    [key: string]: {
      current: number;
      min: number;
      status: 'sufficient' | 'low' | 'depleted';
    };
  };
}

export default function ResourceManagementScreen({ language }: { language: 'tr' | 'en' | 'ar' }) {
  const resources: Resource[] = [
    { id: 'water', name: 'Water', icon: Droplet, color: 'blue' },
    { id: 'medicine', name: 'Medicine', icon: Heart, color: 'red' },
    { id: 'blankets', name: 'Blankets', icon: Package, color: 'purple' },
    { id: 'food', name: 'Food', icon: Package, color: 'green' }
  ];

  const [shelterResources, setShelterResources] = useState<ShelterResource[]>([
    {
      shelter: 'Merkez Kadıköy Barınağı',
      resources: {
        water: { current: 500, min: 200, status: 'sufficient' },
        medicine: { current: 50, min: 100, status: 'low' },
        blankets: { current: 10, min: 150, status: 'depleted' },
        food: { current: 300, min: 200, status: 'sufficient' }
      }
    },
    {
      shelter: 'Beşiktaş Spor Salonu',
      resources: {
        water: { current: 800, min: 300, status: 'sufficient' },
        medicine: { current: 150, min: 100, status: 'sufficient' },
        blankets: { current: 400, min: 200, status: 'sufficient' },
        food: { current: 150, min: 250, status: 'low' }
      }
    },
    {
      shelter: 'Şişli Kültür Merkezi',
      resources: {
        water: { current: 180, min: 200, status: 'low' },
        medicine: { current: 20, min: 80, status: 'depleted' },
        blankets: { current: 250, min: 150, status: 'sufficient' },
        food: { current: 200, min: 180, status: 'sufficient' }
      }
    }
  ]);

  const text = {
    tr: {
      title: 'Kaynak Yönetimi',
      subtitle: 'Barınaklardaki kaynakları takip edin',
      water: 'Su',
      medicine: 'İlaç',
      blankets: 'Battaniye',
      food: 'Yemek',
      sufficient: 'Yeterli',
      low: 'Az',
      depleted: 'Tükendi',
      current: 'Mevcut',
      minimum: 'Minimum',
      status: 'Durum',
      requestSupply: 'Tedarik Talep Et',
      criticalShelters: 'Kritik Barınaklar',
      totalResources: 'Toplam Kaynak'
    },
    en: {
      title: 'Resource Management',
      subtitle: 'Track resources in shelters',
      water: 'Water',
      medicine: 'Medicine',
      blankets: 'Blankets',
      food: 'Food',
      sufficient: 'Sufficient',
      low: 'Low',
      depleted: 'Depleted',
      current: 'Current',
      minimum: 'Minimum',
      status: 'Status',
      requestSupply: 'Request Supply',
      criticalShelters: 'Critical Shelters',
      totalResources: 'Total Resources'
    },
    ar: {
      title: 'إدارة الموارد',
      subtitle: 'تتبع الموارد في المآوي',
      water: 'ماء',
      medicine: 'أدوية',
      blankets: 'بطانيات',
      food: 'طعام',
      sufficient: 'كافي',
      low: 'قليل',
      depleted: 'منتهي',
      current: 'الحالي',
      minimum: 'الحد الأدنى',
      status: 'الحالة',
      requestSupply: 'طلب إمدادات',
      criticalShelters: 'المآوي الحرجة',
      totalResources: 'إجمالي الموارد'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const resourceNames = {
    water: t.water,
    medicine: t.medicine,
    blankets: t.blankets,
    food: t.food
  };

  const statusText = {
    sufficient: t.sufficient,
    low: t.low,
    depleted: t.depleted
  };

  const statusColors = {
    sufficient: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-200' },
    low: { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200' },
    depleted: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-200' }
  };

  const resourceColors = {
    blue: { bg: 'bg-blue-50', text: 'text-blue-600' },
    red: { bg: 'bg-red-50', text: 'text-red-600' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600' },
    green: { bg: 'bg-green-50', text: 'text-green-600' }
  };

  // Calculate critical stats
  const criticalCount = shelterResources.filter(sr =>
    Object.values(sr.resources).some(r => r.status === 'depleted' || r.status === 'low')
  ).length;

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalResources}</p>
                <p className="text-2xl font-bold text-gray-900">{resources.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.criticalShelters}</p>
                <p className="text-2xl font-bold text-orange-600">{criticalCount}</p>
              </div>
            </div>
          </div>

          {resources.slice(0, 2).map(resource => {
            const Icon = resource.icon;
            const colors = resourceColors[resource.color];
            return (
              <div key={resource.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center`}>
                    <Icon className={`w-6 h-6 ${colors.text}`} />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">{resourceNames[resource.id]}</p>
                    <p className={`text-2xl font-bold ${colors.text}`}>
                      {shelterResources.reduce((sum, sr) => sum + sr.resources[resource.id].current, 0)}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Shelters */}
        <div className="space-y-4">
          {shelterResources.map(sr => {
            const hasCritical = Object.values(sr.resources).some(r => r.status === 'depleted' || r.status === 'low');

            return (
              <div
                key={sr.shelter}
                className={`bg-white rounded-2xl border-2 ${
                  hasCritical ? 'border-orange-200' : 'border-gray-100'
                } overflow-hidden`}
              >
                {/* Header */}
                <div className={`p-6 border-b ${hasCritical ? 'bg-orange-50 border-orange-200' : 'bg-gray-50 border-gray-100'}`}>
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-gray-900">{sr.shelter}</h3>
                    {hasCritical && (
                      <div className="flex items-center gap-2 px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm font-semibold">
                        <AlertTriangle className="w-4 h-4" />
                        Needs Attention
                      </div>
                    )}
                  </div>
                </div>

                {/* Resources Grid */}
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {resources.map(resource => {
                      const data = sr.resources[resource.id];
                      const Icon = resource.icon;
                      const colors = resourceColors[resource.color];
                      const statusColor = statusColors[data.status];
                      const percentage = Math.round((data.current / data.min) * 100);

                      return (
                        <div
                          key={resource.id}
                          className={`p-4 rounded-xl border-2 ${statusColor.border} ${statusColor.bg}`}
                        >
                          <div className="flex items-center gap-3 mb-3">
                            <div className={`w-12 h-12 ${colors.bg} rounded-xl flex items-center justify-center`}>
                              <Icon className={`w-6 h-6 ${colors.text}`} />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-bold text-gray-900">{resourceNames[resource.id]}</h4>
                              <span className={`text-xs font-semibold ${statusColor.text}`}>
                                {statusText[data.status]}
                              </span>
                            </div>
                          </div>

                          <div className="space-y-2 mb-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-gray-600">{t.current}</span>
                              <span className="font-bold text-gray-900">{data.current}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-gray-600">{t.minimum}</span>
                              <span className="font-bold text-gray-900">{data.min}</span>
                            </div>
                          </div>

                          {/* Progress Bar */}
                          <div className="mb-3">
                            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  data.status === 'sufficient'
                                    ? 'bg-green-500'
                                    : data.status === 'low'
                                    ? 'bg-orange-500'
                                    : 'bg-red-500'
                                }`}
                                style={{ width: `${Math.min(percentage, 100)}%` }}
                              />
                            </div>
                          </div>

                          {/* Request Button */}
                          {data.status !== 'sufficient' && (
                            <button className={`w-full py-2 rounded-lg font-semibold text-sm ${statusColor.text} ${statusColor.bg} border-2 ${statusColor.border} hover:opacity-80 transition-opacity`}>
                              <Plus className="w-4 h-4 inline mr-1" />
                              {t.requestSupply}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
