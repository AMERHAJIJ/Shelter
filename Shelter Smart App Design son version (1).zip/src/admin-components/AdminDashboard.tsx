import { Users, Building2, AlertCircle, Activity, MapPin, TrendingUp, CheckCircle, XCircle } from 'lucide-react';

interface AdminDashboardProps {
  role: 'admin' | 'staff';
  username: string;
  language: 'tr' | 'en' | 'ar';
  onNavigate: (page: string) => void;
}

interface Shelter {
  id: number;
  name: string;
  type: 'main' | 'small';
  status: 'open' | 'closed' | 'full';
  capacity: number;
  current: number;
}

export default function AdminDashboard({ role, username, language, onNavigate }: AdminDashboardProps) {
  const text = {
    tr: {
      title: 'Kontrol Paneli',
      welcome: 'Hoş Geldiniz',
      admin: 'Merkezi Yönetici',
      staff: 'Barınak Personeli',
      overview: 'Genel Durum',
      totalPeople: 'Toplam Kişi',
      activeShelters: 'Aktif Barınak',
      emergencyRequests: 'Acil Durum Talepleri',
      capacityUsage: 'Kapasite Kullanımı',
      shelters: 'Barınaklar',
      open: 'Açık',
      closed: 'Kapalı',
      full: 'Dolu',
      viewDetails: 'Detayları Gör',
      manageShelters: 'Barınakları Yönet',
      manageCapacity: 'Kapasite Yönetimi',
      emergencyManagement: 'Acil Durum Yönetimi',
      qrLogs: 'Giriş/Çıkış Kayıtları',
      familyManagement: 'Aile Yönetimi',
      resourceManagement: 'Kaynak Yönetimi',
      notifications: 'Bildirimler',
      unregistered: 'Kayıtsız Kişiler',
      sosRequests: 'SOS Talepleri',
      ambulanceRequests: 'Ambulans Talepleri',
      transferRequests: 'Nakil Talepleri',
      active: 'Aktif',
      mainShelter: 'Ana Barınak',
      smallShelter: 'Küçük Barınak'
    },
    en: {
      title: 'Control Panel',
      welcome: 'Welcome',
      admin: 'Central Administrator',
      staff: 'Shelter Staff',
      overview: 'Overview',
      totalPeople: 'Total People',
      activeShelters: 'Active Shelters',
      emergencyRequests: 'Emergency Requests',
      capacityUsage: 'Capacity Usage',
      shelters: 'Shelters',
      open: 'Open',
      closed: 'Closed',
      full: 'Full',
      viewDetails: 'View Details',
      manageShelters: 'Manage Shelters',
      manageCapacity: 'Capacity Management',
      emergencyManagement: 'Emergency Management',
      qrLogs: 'Entry/Exit Logs',
      familyManagement: 'Family Management',
      resourceManagement: 'Resource Management',
      notifications: 'Notifications',
      unregistered: 'Unregistered People',
      sosRequests: 'SOS Requests',
      ambulanceRequests: 'Ambulance Requests',
      transferRequests: 'Transfer Requests',
      active: 'Active',
      mainShelter: 'Main Shelter',
      smallShelter: 'Small Shelter'
    },
    ar: {
      title: 'لوحة التحكم',
      welcome: 'مرحباً',
      admin: 'المدير المركزي',
      staff: 'موظف المأوى',
      overview: 'نظرة عامة',
      totalPeople: 'إجمالي الأشخاص',
      activeShelters: 'المآوي النشطة',
      emergencyRequests: 'طلبات الطوارئ',
      capacityUsage: 'استخدام السعة',
      shelters: 'المآوي',
      open: 'مفتوح',
      closed: 'مغلق',
      full: 'ممتلئ',
      viewDetails: 'عرض التفاصيل',
      manageShelters: 'إدارة المآوي',
      manageCapacity: 'إدارة السعة',
      emergencyManagement: 'إدارة الطوارئ',
      qrLogs: 'سجلات الدخول/الخروج',
      familyManagement: 'إدارة العائلات',
      resourceManagement: 'إدارة الموارد',
      notifications: 'الإشعارات',
      unregistered: 'الأشخاص غير المسجلين',
      sosRequests: 'طلبات SOS',
      ambulanceRequests: 'طلبات الإسعاف',
      transferRequests: 'طلبات النقل',
      active: 'نشط',
      mainShelter: 'مأوى رئيسي',
      smallShelter: 'مأوى صغير'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  // Mock data
  const stats = {
    totalPeople: 1847,
    activeShelters: 12,
    emergencyRequests: 23,
    capacityUsage: 68
  };

  const shelters: Shelter[] = [
    { id: 1, name: 'Merkez Kadıköy Barınağı', type: 'main', status: 'open', capacity: 500, current: 324 },
    { id: 2, name: 'Moda İlkokulu', type: 'small', status: 'open', capacity: 150, current: 98 },
    { id: 3, name: 'Beşiktaş Spor Salonu', type: 'main', status: 'full', capacity: 600, current: 600 },
    { id: 4, name: 'Şişli Kültür Merkezi', type: 'small', status: 'open', capacity: 200, current: 145 }
  ];

  const emergencyRequests = {
    sos: 8,
    ambulance: 12,
    transfer: 3
  };

  return (
    <div className="min-h-screen bg-gray-50" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{t.title}</h1>
            <p className="text-sm text-gray-500">
              {t.welcome}, {username} - <span className={role === 'admin' ? 'text-blue-600' : 'text-green-600'}>{role === 'admin' ? t.admin : t.staff}</span>
            </p>
          </div>
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${role === 'admin' ? 'bg-blue-100' : 'bg-green-100'}`}>
            <Users className={`w-6 h-6 ${role === 'admin' ? 'text-blue-600' : 'text-green-600'}`} />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {/* Stats Overview */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-gray-900 mb-4">{t.overview}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              icon={Users}
              label={t.totalPeople}
              value={stats.totalPeople.toLocaleString()}
              color="blue"
              trend="+12%"
            />
            <StatCard
              icon={Building2}
              label={t.activeShelters}
              value={stats.activeShelters.toString()}
              color="green"
              trend="Active"
            />
            <StatCard
              icon={AlertCircle}
              label={t.emergencyRequests}
              value={stats.emergencyRequests.toString()}
              color="red"
              trend="Urgent"
            />
            <StatCard
              icon={Activity}
              label={t.capacityUsage}
              value={`${stats.capacityUsage}%`}
              color="orange"
              trend="Normal"
            />
          </div>
        </div>

        {/* Emergency Requests Summary */}
        <div className="mb-8">
          <h2 className="text-lg font-bold text-gray-900 mb-4">{t.emergencyRequests}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <EmergencyCard
              type="SOS"
              count={emergencyRequests.sos}
              label={t.sosRequests}
              color="red"
              onClick={() => onNavigate('emergency')}
            />
            <EmergencyCard
              type="Ambulance"
              count={emergencyRequests.ambulance}
              label={t.ambulanceRequests}
              color="orange"
              onClick={() => onNavigate('emergency')}
            />
            <EmergencyCard
              type="Transfer"
              count={emergencyRequests.transfer}
              label={t.transferRequests}
              color="blue"
              onClick={() => onNavigate('emergency')}
            />
          </div>
        </div>

        {/* Shelters Status */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">{t.shelters}</h2>
            <button
              onClick={() => onNavigate('shelters')}
              className="text-sm text-blue-600 hover:text-blue-700 font-semibold"
            >
              {t.viewDetails} →
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {shelters.map(shelter => (
              <ShelterCard
                key={shelter.id}
                shelter={shelter}
                language={language}
                onClick={() => onNavigate('capacity')}
              />
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <QuickActionButton
              icon={Building2}
              label={t.manageShelters}
              onClick={() => onNavigate('shelters')}
              color="blue"
            />
            <QuickActionButton
              icon={Activity}
              label={t.manageCapacity}
              onClick={() => onNavigate('capacity')}
              color="green"
            />
            <QuickActionButton
              icon={AlertCircle}
              label={t.emergencyManagement}
              onClick={() => onNavigate('emergency')}
              color="red"
            />
            <QuickActionButton
              icon={Users}
              label={t.familyManagement}
              onClick={() => onNavigate('families')}
              color="purple"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color, trend }: any) {
  const colors = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    red: 'bg-red-50 text-red-600',
    orange: 'bg-orange-50 text-orange-600'
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${colors[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
        <span className="text-xs font-semibold text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
          {trend}
        </span>
      </div>
      <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
      <p className="text-sm text-gray-600">{label}</p>
    </div>
  );
}

function EmergencyCard({ type, count, label, color, onClick }: any) {
  const colors = {
    red: 'bg-red-500',
    orange: 'bg-orange-500',
    blue: 'bg-blue-500'
  };

  return (
    <button
      onClick={onClick}
      className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-left"
    >
      <div className="flex items-center justify-between mb-3">
        <AlertCircle className={`w-6 h-6 ${color === 'red' ? 'text-red-600' : color === 'orange' ? 'text-orange-600' : 'text-blue-600'}`} />
        <div className={`${colors[color]} text-white text-xs font-bold px-3 py-1 rounded-full`}>
          {count} Active
        </div>
      </div>
      <p className="text-2xl font-bold text-gray-900 mb-1">{count}</p>
      <p className="text-sm text-gray-600">{label}</p>
    </button>
  );
}

function ShelterCard({ shelter, language, onClick }: any) {
  const percentage = Math.round((shelter.current / shelter.capacity) * 100);
  const statusColors = {
    open: 'text-green-600 bg-green-50',
    full: 'text-red-600 bg-red-50',
    closed: 'text-gray-600 bg-gray-50'
  };

  const text = {
    tr: { open: 'Açık', closed: 'Kapalı', full: 'Dolu', main: 'Ana', small: 'Küçük' },
    en: { open: 'Open', closed: 'Closed', full: 'Full', main: 'Main', small: 'Small' },
    ar: { open: 'مفتوح', closed: 'مغلق', full: 'ممتلئ', main: 'رئيسي', small: 'صغير' }
  };

  const t = text[language];

  return (
    <button
      onClick={onClick}
      className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow text-left"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <h3 className="font-bold text-gray-900 mb-1">{shelter.name}</h3>
          <p className="text-xs text-gray-500">{shelter.type === 'main' ? t.main : t.small}</p>
        </div>
        <span className={`text-xs font-semibold px-3 py-1 rounded-full ${statusColors[shelter.status]}`}>
          {t[shelter.status]}
        </span>
      </div>
      
      <div className="mb-3">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-gray-600">Capacity</span>
          <span className="font-semibold text-gray-900">{shelter.current} / {shelter.capacity}</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${
              percentage >= 90 ? 'bg-red-500' : percentage >= 70 ? 'bg-orange-500' : 'bg-green-500'
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
      
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <MapPin className="w-4 h-4" />
        <span>{percentage}% Occupied</span>
      </div>
    </button>
  );
}

function QuickActionButton({ icon: Icon, label, onClick, color }: any) {
  const colors = {
    blue: 'bg-blue-50 text-blue-600 hover:bg-blue-100',
    green: 'bg-green-50 text-green-600 hover:bg-green-100',
    red: 'bg-red-50 text-red-600 hover:bg-red-100',
    purple: 'bg-purple-50 text-purple-600 hover:bg-purple-100'
  };

  return (
    <button
      onClick={onClick}
      className={`${colors[color]} rounded-2xl p-6 transition-colors text-center`}
    >
      <Icon className="w-8 h-8 mx-auto mb-3" />
      <p className="text-sm font-semibold">{label}</p>
    </button>
  );
}
