import { useState } from 'react';
import { Bell, Send, Users, MapPin, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

interface Notification {
  id: number;
  type: 'shelter_open' | 'shelter_close' | 'earthquake' | 'instruction';
  title: string;
  message: string;
  region: string;
  targetUsers: string;
  timestamp: string;
  sent: boolean;
}

export default function NotificationsScreen({ language }: { language: 'tr' | 'en' | 'ar' }) {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: 'shelter_open',
      title: 'Kadıköy Shelter Opened',
      message: 'Merkez Kadıköy Barınağı is now open and accepting people',
      region: 'Kadıköy',
      targetUsers: 'All',
      timestamp: '5 min ago',
      sent: true
    },
    {
      id: 2,
      type: 'earthquake',
      title: 'Earthquake Alert',
      message: 'Stay calm and follow safety procedures',
      region: 'All',
      targetUsers: 'All',
      timestamp: '1 hour ago',
      sent: true
    }
  ]);

  const [newNotification, setNewNotification] = useState({
    type: 'shelter_open' as const,
    title: '',
    message: '',
    region: 'All',
    targetUsers: 'All'
  });

  const text = {
    tr: {
      title: 'Bildirim Yönetimi',
      subtitle: 'Kullanıcılara bildirim gönderin',
      sendNew: 'Yeni Bildirim Gönder',
      type: 'Bildirim Türü',
      shelterOpen: 'Barınak Açıldı',
      shelterClose: 'Barınak Kapandı',
      earthquake: 'Deprem Uyarısı',
      instruction: 'Talimat',
      notificationTitle: 'Başlık',
      message: 'Mesaj',
      region: 'Bölge',
      targetUsers: 'Hedef Kullanıcılar',
      all: 'Tümü',
      families: 'Aileler',
      individuals: 'Bireyler',
      send: 'Gönder',
      cancel: 'İptal',
      recentNotifications: 'Son Bildirimler',
      sent: 'Gönderildi',
      scheduled: 'Zamanlandı',
      enterTitle: 'Başlık girin',
      enterMessage: 'Mesaj girin'
    },
    en: {
      title: 'Notification Management',
      subtitle: 'Send notifications to users',
      sendNew: 'Send New Notification',
      type: 'Notification Type',
      shelterOpen: 'Shelter Opened',
      shelterClose: 'Shelter Closed',
      earthquake: 'Earthquake Alert',
      instruction: 'Instruction',
      notificationTitle: 'Title',
      message: 'Message',
      region: 'Region',
      targetUsers: 'Target Users',
      all: 'All',
      families: 'Families',
      individuals: 'Individuals',
      send: 'Send',
      cancel: 'Cancel',
      recentNotifications: 'Recent Notifications',
      sent: 'Sent',
      scheduled: 'Scheduled',
      enterTitle: 'Enter title',
      enterMessage: 'Enter message'
    },
    ar: {
      title: 'إدارة الإشعارات',
      subtitle: 'إرسال إشعارات للمستخدمين',
      sendNew: 'إرسال إشعار جديد',
      type: 'نوع الإشعار',
      shelterOpen: 'فتح المأوى',
      shelterClose: 'إغلاق المأوى',
      earthquake: 'تنبيه زلزال',
      instruction: 'تعليمات',
      notificationTitle: 'العنوان',
      message: 'الرسالة',
      region: 'المنطقة',
      targetUsers: 'المستخدمون المستهدفون',
      all: 'الكل',
      families: 'العائلات',
      individuals: 'الأفراد',
      send: 'إرسال',
      cancel: 'إلغاء',
      recentNotifications: 'الإشعارات الأخيرة',
      sent: 'تم الإرسال',
      scheduled: 'مجدول',
      enterTitle: 'أدخل العنوان',
      enterMessage: 'أدخل الرسالة'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const notificationTypes = [
    { value: 'shelter_open', label: t.shelterOpen, color: 'green' },
    { value: 'shelter_close', label: t.shelterClose, color: 'red' },
    { value: 'earthquake', label: t.earthquake, color: 'orange' },
    { value: 'instruction', label: t.instruction, color: 'blue' }
  ];

  const regions = ['All', 'Kadıköy', 'Beşiktaş', 'Şişli', 'Üsküdar'];
  const userTypes = [
    { value: 'All', label: t.all },
    { value: 'Families', label: t.families },
    { value: 'Individuals', label: t.individuals }
  ];

  const handleSend = () => {
    if (newNotification.title && newNotification.message) {
      const notification: Notification = {
        id: notifications.length + 1,
        ...newNotification,
        timestamp: 'Just now',
        sent: true
      };
      setNotifications([notification, ...notifications]);
      setNewNotification({
        type: 'shelter_open',
        title: '',
        message: '',
        region: 'All',
        targetUsers: 'All'
      });
    }
  };

  const typeColors = {
    shelter_open: { bg: 'bg-green-50', text: 'text-green-600', icon: 'bg-green-500' },
    shelter_close: { bg: 'bg-red-50', text: 'text-red-600', icon: 'bg-red-500' },
    earthquake: { bg: 'bg-orange-50', text: 'text-orange-600', icon: 'bg-orange-500' },
    instruction: { bg: 'bg-blue-50', text: 'text-blue-600', icon: 'bg-blue-500' }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <Bell className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Sent</p>
                <p className="text-2xl font-bold text-blue-600">{notifications.filter(n => n.sent).length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Today</p>
                <p className="text-2xl font-bold text-green-600">{notifications.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Recipients</p>
                <p className="text-2xl font-bold text-purple-600">~2,500</p>
              </div>
            </div>
          </div>
        </div>

        {/* Send New Notification Form */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Send className="w-6 h-6" />
            {t.sendNew}
          </h2>

          <div className="space-y-4">
            {/* Type */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.type}
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {notificationTypes.map(type => (
                  <button
                    key={type.value}
                    onClick={() => setNewNotification({ ...newNotification, type: type.value as any })}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      newNotification.type === type.value
                        ? `border-${type.color}-500 bg-${type.color}-50`
                        : 'border-gray-200 bg-gray-50 hover:border-gray-300'
                    }`}
                  >
                    <p className="text-sm font-semibold text-gray-900">{type.label}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Title */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.notificationTitle}
              </label>
              <input
                type="text"
                value={newNotification.title}
                onChange={(e) => setNewNotification({ ...newNotification, title: e.target.value })}
                placeholder={t.enterTitle}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.message}
              </label>
              <textarea
                value={newNotification.message}
                onChange={(e) => setNewNotification({ ...newNotification, message: e.target.value })}
                placeholder={t.enterMessage}
                rows={4}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Region & Target */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t.region}
                </label>
                <select
                  value={newNotification.region}
                  onChange={(e) => setNewNotification({ ...newNotification, region: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                >
                  {regions.map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {t.targetUsers}
                </label>
                <select
                  value={newNotification.targetUsers}
                  onChange={(e) => setNewNotification({ ...newNotification, targetUsers: e.target.value })}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-blue-500"
                >
                  {userTypes.map(u => (
                    <option key={u.value} value={u.value}>{u.label}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <button
                onClick={handleSend}
                disabled={!newNotification.title || !newNotification.message}
                className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="w-5 h-5" />
                {t.send}
              </button>
              <button
                onClick={() => setNewNotification({
                  type: 'shelter_open',
                  title: '',
                  message: '',
                  region: 'All',
                  targetUsers: 'All'
                })}
                className="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>

        {/* Recent Notifications */}
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">{t.recentNotifications}</h2>
          </div>

          <div className="divide-y divide-gray-100">
            {notifications.map(notification => {
              const colors = typeColors[notification.type];
              return (
                <div key={notification.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 ${colors.bg} rounded-xl flex items-center justify-center flex-shrink-0`}>
                      <Bell className={`w-7 h-7 ${colors.text}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-bold text-gray-900 mb-1">{notification.title}</h3>
                          <p className="text-sm text-gray-600 mb-3">{notification.message}</p>
                          <div className="flex items-center gap-4 text-xs text-gray-500">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {notification.region}
                            </span>
                            <span className="flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              {notification.targetUsers}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {notification.timestamp}
                            </span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            notification.sent ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                          }`}>
                            {notification.sent ? t.sent : t.scheduled}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
