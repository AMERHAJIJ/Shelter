import { useState } from 'react';
import { QrCode, LogIn, LogOut, Clock, User, Building2, Users, Filter } from 'lucide-react';

interface QRLog {
  id: number;
  type: 'entry' | 'exit';
  userName: string;
  userId: string;
  shelter: string;
  section: string;
  peopleCount: number;
  timestamp: string;
  qrCode: string;
}

export default function QRLogsScreen({ language }: { language: 'tr' | 'en' | 'ar' }) {
  const [logs, setLogs] = useState<QRLog[]>([
    {
      id: 1,
      type: 'entry',
      userName: 'Mehmet Yılmaz',
      userId: 'USR-001',
      shelter: 'Merkez Kadıköy Barınağı',
      section: 'Families',
      peopleCount: 4,
      timestamp: '2 min ago',
      qrCode: 'QR-2024-001-ENTRY'
    },
    {
      id: 2,
      type: 'entry',
      userName: 'Ayşe Demir',
      userId: 'USR-002',
      shelter: 'Beşiktaş Spor Salonu',
      section: 'Individuals',
      peopleCount: 1,
      timestamp: '5 min ago',
      qrCode: 'QR-2024-002-ENTRY'
    },
    {
      id: 3,
      type: 'exit',
      userName: 'Ali Kaya',
      userId: 'USR-003',
      shelter: 'Merkez Kadıköy Barınağı',
      section: 'Families',
      peopleCount: 3,
      timestamp: '12 min ago',
      qrCode: 'QR-2024-003-EXIT'
    },
    {
      id: 4,
      type: 'entry',
      userName: 'Fatma Öz',
      userId: 'USR-004',
      shelter: 'Şişli Kültür Merkezi',
      section: 'Children',
      peopleCount: 2,
      timestamp: '18 min ago',
      qrCode: 'QR-2024-004-ENTRY'
    },
    {
      id: 5,
      type: 'exit',
      userName: 'Can Arslan',
      userId: 'USR-005',
      shelter: 'Beşiktaş Spor Salonu',
      section: 'Individuals',
      peopleCount: 1,
      timestamp: '25 min ago',
      qrCode: 'QR-2024-005-EXIT'
    }
  ]);

  const [filterType, setFilterType] = useState<'all' | 'entry' | 'exit'>('all');
  const [filterShelter, setFilterShelter] = useState('all');

  const text = {
    tr: {
      title: 'QR Giriş/Çıkış Kayıtları',
      subtitle: 'Tüm QR tarama kayıtlarını izleyin',
      all: 'Tümü',
      entry: 'Giriş',
      exit: 'Çıkış',
      userName: 'Kullanıcı',
      shelter: 'Barınak',
      section: 'Bölüm',
      people: 'Kişi Sayısı',
      time: 'Zaman',
      qrCode: 'QR Kodu',
      filter: 'Filtrele',
      totalEntries: 'Toplam Giriş',
      totalExits: 'Toplam Çıkış',
      netChange: 'Net Değişim',
      autoUpdate: 'Otomatik güncellenir'
    },
    en: {
      title: 'QR Entry/Exit Logs',
      subtitle: 'Track all QR scan records',
      all: 'All',
      entry: 'Entry',
      exit: 'Exit',
      userName: 'User',
      shelter: 'Shelter',
      section: 'Section',
      people: 'People Count',
      time: 'Time',
      qrCode: 'QR Code',
      filter: 'Filter',
      totalEntries: 'Total Entries',
      totalExits: 'Total Exits',
      netChange: 'Net Change',
      autoUpdate: 'Auto-updates'
    },
    ar: {
      title: 'سجلات QR للدخول/الخروج',
      subtitle: 'تتبع جميع سجلات مسح QR',
      all: 'الكل',
      entry: 'دخول',
      exit: 'خروج',
      userName: 'المستخدم',
      shelter: 'المأوى',
      section: 'القسم',
      people: 'عدد الأشخاص',
      time: 'الوقت',
      qrCode: 'رمز QR',
      filter: 'تصفية',
      totalEntries: 'إجمالي الدخول',
      totalExits: 'إجمالي الخروج',
      netChange: 'التغيير الصافي',
      autoUpdate: 'يتم التحديث تلقائياً'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const filteredLogs = logs
    .filter(log => filterType === 'all' || log.type === filterType)
    .filter(log => filterShelter === 'all' || log.shelter === filterShelter);

  const stats = {
    totalEntries: logs.filter(l => l.type === 'entry').reduce((sum, l) => sum + l.peopleCount, 0),
    totalExits: logs.filter(l => l.type === 'exit').reduce((sum, l) => sum + l.peopleCount, 0)
  };
  const netChange = stats.totalEntries - stats.totalExits;

  const shelters = Array.from(new Set(logs.map(l => l.shelter)));

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <QrCode className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Logs</p>
                <p className="text-2xl font-bold text-gray-900">{logs.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                <LogIn className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalEntries}</p>
                <p className="text-2xl font-bold text-green-600">{stats.totalEntries}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center">
                <LogOut className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalExits}</p>
                <p className="text-2xl font-bold text-red-600">{stats.totalExits}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.netChange}</p>
                <p className={`text-2xl font-bold ${netChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {netChange >= 0 ? '+' : ''}{netChange}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-2xl p-4 mb-6 border border-gray-100">
          <div className="flex items-center gap-3 mb-3">
            <Filter className="w-5 h-5 text-gray-600" />
            <h3 className="font-semibold text-gray-900">{t.filter}</h3>
          </div>
          <div className="flex flex-wrap gap-3">
            <FilterButton label={t.all} active={filterType === 'all'} onClick={() => setFilterType('all')} />
            <FilterButton label={t.entry} active={filterType === 'entry'} onClick={() => setFilterType('entry')} color="green" />
            <FilterButton label={t.exit} active={filterType === 'exit'} onClick={() => setFilterType('exit')} color="red" />
            <div className="w-px bg-gray-200" />
            <select
              value={filterShelter}
              onChange={(e) => setFilterShelter(e.target.value)}
              className="px-4 py-2 rounded-lg border-2 border-gray-200 font-semibold text-sm focus:outline-none focus:border-blue-500"
            >
              <option value="all">All Shelters</option>
              {shelters.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {/* Logs Table */}
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-100">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">Type</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.userName}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.shelter}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.section}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.people}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.time}</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700">{t.qrCode}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      {log.type === 'entry' ? (
                        <div className="flex items-center gap-2">
                          <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                            <LogIn className="w-5 h-5 text-green-600" />
                          </div>
                          <span className="font-semibold text-green-600">{t.entry}</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <div className="w-10 h-10 bg-red-50 rounded-lg flex items-center justify-center">
                            <LogOut className="w-5 h-5 text-red-600" />
                          </div>
                          <span className="font-semibold text-red-600">{t.exit}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{log.userName}</p>
                          <p className="text-xs text-gray-500">{log.userId}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-gray-700">
                        <Building2 className="w-4 h-4 text-gray-400" />
                        <span className="text-sm font-medium">{log.shelter}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-3 py-1 bg-purple-50 text-purple-600 rounded-full text-xs font-semibold">
                        {log.section}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-gray-400" />
                        <span className="font-bold text-gray-900">{log.peopleCount}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm">{log.timestamp}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <code className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-xs font-mono">
                        {log.qrCode}
                      </code>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <p className="text-center text-sm text-gray-500 mt-4">{t.autoUpdate}</p>
      </div>
    </div>
  );
}

function FilterButton({ label, active, onClick, color = 'gray' }: any) {
  const colors = {
    gray: active ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200',
    green: active ? 'bg-green-600 text-white' : 'bg-green-50 text-green-600 hover:bg-green-100',
    red: active ? 'bg-red-600 text-white' : 'bg-red-50 text-red-600 hover:bg-red-100'
  };

  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${colors[color]}`}
    >
      {label}
    </button>
  );
}
