import { useState } from 'react';
import { Users, Baby, Heart, UserX, TrendingUp, AlertTriangle } from 'lucide-react';

interface Section {
  id: string;
  name: string;
  icon: any;
  maxCapacity: number;
  current: number;
  color: string;
}

export default function ManageCapacityScreen({ language, shelterId }: { language: 'tr' | 'en' | 'ar'; shelterId: number }) {
  const [sections, setSections] = useState<Section[]>([
    { id: 'families', name: 'Families', icon: Users, maxCapacity: 200, current: 145, color: 'blue' },
    { id: 'individuals', name: 'Individuals', icon: Users, maxCapacity: 150, current: 89, color: 'green' },
    { id: 'children', name: 'Children', icon: Baby, maxCapacity: 100, current: 67, color: 'purple' },
    { id: 'special', name: 'Special Needs', icon: Heart, maxCapacity: 50, current: 23, color: 'pink' },
    { id: 'unregistered', name: 'Unregistered', icon: UserX, maxCapacity: 50, current: 12, color: 'gray' }
  ]);

  const text = {
    tr: {
      title: 'Kapasite Yönetimi',
      subtitle: 'Barınak bölümleri ve kapasiteler',
      totalCapacity: 'Toplam Kapasite',
      totalOccupied: 'Toplam Dolu',
      availableSpace: 'Müsait Alan',
      sections: 'Bölümler',
      families: 'Aileler',
      individuals: 'Bireyler',
      children: 'Çocuklar',
      specialNeeds: 'Özel İhtiyaç',
      unregistered: 'Kayıtsız',
      maxCapacity: 'Maksimum Kapasite',
      current: 'Mevcut',
      available: 'Müsait',
      updateCapacity: 'Kapasiteyi Güncelle',
      autoUpdate: 'QR tarama ile otomatik güncellenir',
      full: 'Dolu',
      nearFull: 'Dolmak Üzere',
      good: 'İyi'
    },
    en: {
      title: 'Capacity Management',
      subtitle: 'Shelter sections and capacities',
      totalCapacity: 'Total Capacity',
      totalOccupied: 'Total Occupied',
      availableSpace: 'Available Space',
      sections: 'Sections',
      families: 'Families',
      individuals: 'Individuals',
      children: 'Children',
      specialNeeds: 'Special Needs',
      unregistered: 'Unregistered',
      maxCapacity: 'Max Capacity',
      current: 'Current',
      available: 'Available',
      updateCapacity: 'Update Capacity',
      autoUpdate: 'Auto-updated via QR scan',
      full: 'Full',
      nearFull: 'Near Full',
      good: 'Good'
    },
    ar: {
      title: 'إدارة السعة',
      subtitle: 'أقسام المأوى والسعات',
      totalCapacity: 'السعة الإجمالية',
      totalOccupied: 'المشغول الإجمالي',
      availableSpace: 'المساحة المتاحة',
      sections: 'الأقسام',
      families: 'العائلات',
      individuals: 'الأفراد',
      children: 'الأطفال',
      specialNeeds: 'ذوي الاحتياجات الخاصة',
      unregistered: 'غير المسجلين',
      maxCapacity: 'السعة القصوى',
      current: 'الحالي',
      available: 'المتاح',
      updateCapacity: 'تحديث السعة',
      autoUpdate: 'يتم التحديث تلقائياً عبر مسح QR',
      full: 'ممتلئ',
      nearFull: 'شبه ممتلئ',
      good: 'جيد'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const totalCapacity = sections.reduce((sum, s) => sum + s.maxCapacity, 0);
  const totalOccupied = sections.reduce((sum, s) => sum + s.current, 0);
  const availableSpace = totalCapacity - totalOccupied;
  const overallPercentage = Math.round((totalOccupied / totalCapacity) * 100);

  const getStatusColor = (percentage: number) => {
    if (percentage >= 90) return 'red';
    if (percentage >= 75) return 'orange';
    return 'green';
  };

  const getStatusText = (percentage: number) => {
    if (percentage >= 90) return t.full;
    if (percentage >= 75) return t.nearFull;
    return t.good;
  };

  const colors = {
    blue: { bg: 'bg-blue-50', text: 'text-blue-600', bar: 'bg-blue-500' },
    green: { bg: 'bg-green-50', text: 'text-green-600', bar: 'bg-green-500' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600', bar: 'bg-purple-500' },
    pink: { bg: 'bg-pink-50', text: 'text-pink-600', bar: 'bg-pink-500' },
    gray: { bg: 'bg-gray-50', text: 'text-gray-600', bar: 'bg-gray-500' }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Overall Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalCapacity}</p>
                <p className="text-2xl font-bold text-gray-900">{totalCapacity}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalOccupied}</p>
                <p className="text-2xl font-bold text-gray-900">{totalOccupied}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.availableSpace}</p>
                <p className="text-2xl font-bold text-gray-900">{availableSpace}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                getStatusColor(overallPercentage) === 'red' ? 'bg-red-50' :
                getStatusColor(overallPercentage) === 'orange' ? 'bg-orange-50' : 'bg-green-50'
              }`}>
                <AlertTriangle className={`w-6 h-6 ${
                  getStatusColor(overallPercentage) === 'red' ? 'text-red-600' :
                  getStatusColor(overallPercentage) === 'orange' ? 'text-orange-600' : 'text-green-600'
                }`} />
              </div>
              <div>
                <p className="text-sm text-gray-600">Status</p>
                <p className={`text-xl font-bold ${
                  getStatusColor(overallPercentage) === 'red' ? 'text-red-600' :
                  getStatusColor(overallPercentage) === 'orange' ? 'text-orange-600' : 'text-green-600'
                }`}>
                  {getStatusText(overallPercentage)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Overall Progress */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-8">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-900">Overall Occupancy</h3>
            <span className="text-2xl font-bold text-gray-900">{overallPercentage}%</span>
          </div>
          <div className="w-full bg-gray-100 rounded-full h-4 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                overallPercentage >= 90 ? 'bg-red-500' :
                overallPercentage >= 75 ? 'bg-orange-500' : 'bg-green-500'
              }`}
              style={{ width: `${overallPercentage}%` }}
            />
          </div>
          <p className="text-xs text-gray-500 mt-2">{t.autoUpdate}</p>
        </div>

        {/* Sections */}
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">{t.sections}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sections.map(section => {
              const percentage = Math.round((section.current / section.maxCapacity) * 100);
              const color = colors[section.color];
              const Icon = section.icon;

              return (
                <div key={section.id} className="bg-white rounded-2xl p-6 border border-gray-100">
                  {/* Header */}
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-14 h-14 ${color.bg} rounded-xl flex items-center justify-center`}>
                      <Icon className={`w-7 h-7 ${color.text}`} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900">{section.name}</h3>
                      <p className="text-xs text-gray-500">{section.id}</p>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{t.current}</span>
                      <span className="font-bold text-gray-900">{section.current}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{t.maxCapacity}</span>
                      <span className="font-bold text-gray-900">{section.maxCapacity}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{t.available}</span>
                      <span className={`font-bold ${
                        section.maxCapacity - section.current === 0 ? 'text-red-600' : 'text-green-600'
                      }`}>
                        {section.maxCapacity - section.current}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-600">Occupancy</span>
                      <span className={`text-sm font-bold ${
                        percentage >= 90 ? 'text-red-600' :
                        percentage >= 75 ? 'text-orange-600' : color.text
                      }`}>
                        {percentage}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          percentage >= 90 ? 'bg-red-500' :
                          percentage >= 75 ? 'bg-orange-500' : color.bar
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>

                  {/* Update Button */}
                  <button className={`w-full py-2 rounded-xl font-semibold transition-colors ${color.bg} ${color.text} hover:opacity-80`}>
                    {t.updateCapacity}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
