import { useState } from 'react';
import { UserX, Plus, Users, Building2, Save } from 'lucide-react';

interface UnregisteredEntry {
  id: number;
  shelter: string;
  section: string;
  count: number;
  timestamp: string;
  notes?: string;
}

export default function UnregisteredScreen({ language }: { language: 'tr' | 'en' | 'ar' }) {
  const [entries, setEntries] = useState<UnregisteredEntry[]>([
    {
      id: 1,
      shelter: 'Merkez Kadıköy Barınağı',
      section: 'Unregistered',
      count: 12,
      timestamp: '15 min ago',
      notes: 'Family of 5 + 7 individuals arrived without registration'
    },
    {
      id: 2,
      shelter: 'Beşiktaş Spor Salonu',
      section: 'Unregistered',
      count: 8,
      timestamp: '45 min ago',
      notes: 'Emergency walk-ins'
    }
  ]);

  const [newEntry, setNewEntry] = useState({
    shelter: '',
    section: 'Unregistered',
    count: 0,
    notes: ''
  });

  const text = {
    tr: {
      title: 'Kayıtsız Kişi Yönetimi',
      subtitle: 'Kayıtsız gelen kişileri sisteme ekleyin',
      addNew: 'Yeni Kayıt Ekle',
      totalUnregistered: 'Toplam Kayıtsız',
      shelter: 'Barınak',
      section: 'Bölüm',
      count: 'Kişi Sayısı',
      notes: 'Notlar',
      timestamp: 'Zaman',
      selectShelter: 'Barınak Seçin',
      enterCount: 'Kişi sayısını girin',
      enterNotes: 'Notlar ekleyin (opsiyonel)',
      save: 'Kaydet',
      cancel: 'İptal',
      recentEntries: 'Son Kayıtlar',
      noEntries: 'Henüz kayıt yok'
    },
    en: {
      title: 'Unregistered People Management',
      subtitle: 'Add unregistered arrivals to the system',
      addNew: 'Add New Entry',
      totalUnregistered: 'Total Unregistered',
      shelter: 'Shelter',
      section: 'Section',
      count: 'People Count',
      notes: 'Notes',
      timestamp: 'Time',
      selectShelter: 'Select Shelter',
      enterCount: 'Enter people count',
      enterNotes: 'Add notes (optional)',
      save: 'Save',
      cancel: 'Cancel',
      recentEntries: 'Recent Entries',
      noEntries: 'No entries yet'
    },
    ar: {
      title: 'إدارة الأشخاص غير المسجلين',
      subtitle: 'إضافة الوافدين غير المسجلين إلى النظام',
      addNew: 'إضافة سجل جديد',
      totalUnregistered: 'إجمالي غير المسجلين',
      shelter: 'المأوى',
      section: 'القسم',
      count: 'عدد الأشخاص',
      notes: 'ملاحظات',
      timestamp: 'الوقت',
      selectShelter: 'اختر المأوى',
      enterCount: 'أدخل عدد الأشخاص',
      enterNotes: 'أضف ملاحظات (اختياري)',
      save: 'حفظ',
      cancel: 'إلغاء',
      recentEntries: 'السجلات الأخيرة',
      noEntries: 'لا توجد سجلات بعد'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const shelters = [
    'Merkez Kadıköy Barınağı',
    'Beşiktaş Spor Salonu',
    'Şişli Kültür Merkezi',
    'Moda İlkokulu'
  ];

  const totalUnregistered = entries.reduce((sum, e) => sum + e.count, 0);

  const handleSave = () => {
    if (newEntry.shelter && newEntry.count > 0) {
      const entry: UnregisteredEntry = {
        id: entries.length + 1,
        ...newEntry,
        timestamp: 'Just now'
      };
      setEntries([entry, ...entries]);
      setNewEntry({ shelter: '', section: 'Unregistered', count: 0, notes: '' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center">
                <UserX className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalUnregistered}</p>
                <p className="text-2xl font-bold text-purple-600">{totalUnregistered}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <Building2 className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Shelters</p>
                <p className="text-2xl font-bold text-blue-600">{new Set(entries.map(e => e.shelter)).size}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Entries</p>
                <p className="text-2xl font-bold text-green-600">{entries.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Add New Form */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Plus className="w-6 h-6" />
            {t.addNew}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Shelter */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.shelter}
              </label>
              <select
                value={newEntry.shelter}
                onChange={(e) => setNewEntry({ ...newEntry, shelter: e.target.value })}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500"
              >
                <option value="">{t.selectShelter}</option>
                {shelters.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            {/* Count */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.count}
              </label>
              <input
                type="number"
                min="1"
                value={newEntry.count || ''}
                onChange={(e) => setNewEntry({ ...newEntry, count: parseInt(e.target.value) || 0 })}
                placeholder={t.enterCount}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500"
              />
            </div>

            {/* Notes */}
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.notes}
              </label>
              <textarea
                value={newEntry.notes}
                onChange={(e) => setNewEntry({ ...newEntry, notes: e.target.value })}
                placeholder={t.enterNotes}
                rows={3}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3 mt-4">
            <button
              onClick={handleSave}
              disabled={!newEntry.shelter || newEntry.count === 0}
              className="flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Save className="w-5 h-5" />
              {t.save}
            </button>
            <button
              onClick={() => setNewEntry({ shelter: '', section: 'Unregistered', count: 0, notes: '' })}
              className="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition-colors"
            >
              {t.cancel}
            </button>
          </div>
        </div>

        {/* Recent Entries */}
        <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">{t.recentEntries}</h2>
          </div>

          {entries.length === 0 ? (
            <div className="p-12 text-center">
              <UserX className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">{t.noEntries}</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {entries.map(entry => (
                <div key={entry.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-purple-50 rounded-xl flex items-center justify-center flex-shrink-0">
                      <UserX className="w-7 h-7 text-purple-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-bold text-gray-900 mb-1">{entry.shelter}</h3>
                          <div className="flex items-center gap-3 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              {entry.count} {t.count}
                            </span>
                            <span>•</span>
                            <span>{entry.timestamp}</span>
                          </div>
                        </div>
                        <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-semibold">
                          {entry.section}
                        </span>
                      </div>
                      {entry.notes && (
                        <div className="bg-gray-50 rounded-lg p-3 mt-3">
                          <p className="text-sm text-gray-700">{entry.notes}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
