import { useState } from 'react';
import { Shield, Lock, User, AlertCircle } from 'lucide-react';

interface AdminLoginScreenProps {
  onLogin: (role: 'admin' | 'staff', username: string) => void;
  language: 'tr' | 'en' | 'ar';
}

export default function AdminLoginScreen({ onLogin, language }: AdminLoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'admin' | 'staff'>('admin');
  const [error, setError] = useState('');

  const text = {
    tr: {
      title: 'Yönetim Paneli',
      subtitle: 'Barınak Yönetim Sistemi',
      username: 'Kullanıcı Adı',
      usernamePlaceholder: 'admin veya staff',
      password: 'Şifre',
      passwordPlaceholder: 'Şifrenizi girin',
      roleLabel: 'Hesap Türü',
      adminRole: 'Merkezi Yönetim (Admin)',
      staffRole: 'Barınak Personeli (Staff)',
      loginButton: 'Giriş Yap',
      demoNote: 'Demo: admin/123456 veya staff/123456',
      errorMessage: 'Kullanıcı adı veya şifre hatalı'
    },
    en: {
      title: 'Admin Panel',
      subtitle: 'Shelter Management System',
      username: 'Username',
      usernamePlaceholder: 'admin or staff',
      password: 'Password',
      passwordPlaceholder: 'Enter your password',
      roleLabel: 'Account Type',
      adminRole: 'Central Management (Admin)',
      staffRole: 'Shelter Staff',
      loginButton: 'Login',
      demoNote: 'Demo: admin/123456 or staff/123456',
      errorMessage: 'Invalid username or password'
    },
    ar: {
      title: 'لوحة الإدارة',
      subtitle: 'نظام إدارة المآوي',
      username: 'اسم المستخدم',
      usernamePlaceholder: 'admin أو staff',
      password: 'كلمة المرور',
      passwordPlaceholder: 'أدخل كلمة المرور',
      roleLabel: 'نوع الحساب',
      adminRole: 'الإدارة المركزية (Admin)',
      staffRole: 'موظف مأوى (Staff)',
      loginButton: 'تسجيل الدخول',
      demoNote: 'تجريبي: admin/123456 أو staff/123456',
      errorMessage: 'اسم المستخدم أو كلمة المرور غير صحيحة'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Demo validation
    if ((username === 'admin' || username === 'staff') && password === '123456') {
      onLogin(role, username);
      setError('');
    } else {
      setError(t.errorMessage);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 flex items-center justify-center p-4" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-full mb-4 shadow-xl">
            <Shield className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-white text-3xl font-bold mb-2">{t.title}</h1>
          <p className="text-blue-100 text-sm">{t.subtitle}</p>
        </div>

        {/* Login Form */}
        <div className="bg-white rounded-3xl shadow-2xl p-8">
          <form onSubmit={handleLogin} className="space-y-6">
            {/* Role Selection */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                {t.roleLabel}
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setRole('admin')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    role === 'admin'
                      ? 'border-blue-600 bg-blue-50 text-blue-600'
                      : 'border-gray-200 bg-gray-50 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  <Shield className="w-6 h-6 mx-auto mb-2" />
                  <p className="text-xs font-semibold">Admin</p>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('staff')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    role === 'staff'
                      ? 'border-green-600 bg-green-50 text-green-600'
                      : 'border-gray-200 bg-gray-50 text-gray-600 hover:border-gray-300'
                  }`}
                >
                  <User className="w-6 h-6 mx-auto mb-2" />
                  <p className="text-xs font-semibold">Staff</p>
                </button>
              </div>
            </div>

            {/* Username */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.username}
              </label>
              <div className="relative">
                <User className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 ${isRTL ? 'right-4' : 'left-4'}`} />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={t.usernamePlaceholder}
                  className={`w-full border-2 border-gray-200 rounded-xl py-3 focus:outline-none focus:border-blue-500 transition-colors ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'}`}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {t.password}
              </label>
              <div className="relative">
                <Lock className={`absolute top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 ${isRTL ? 'right-4' : 'left-4'}`} />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.passwordPlaceholder}
                  className={`w-full border-2 border-gray-200 rounded-xl py-3 focus:outline-none focus:border-blue-500 transition-colors ${isRTL ? 'pr-12 pl-4' : 'pl-12 pr-4'}`}
                  required
                />
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {/* Login Button */}
            <button
              type="submit"
              className={`w-full py-4 rounded-xl font-bold text-white transition-all shadow-lg ${
                role === 'admin'
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-green-600 hover:bg-green-700'
              }`}
            >
              {t.loginButton}
            </button>

            {/* Demo Note */}
            <div className="text-center">
              <p className="text-xs text-gray-500">{t.demoNote}</p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
