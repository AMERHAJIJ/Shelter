import { useState } from 'react';
import { Users, MapPin, CheckCircle, XCircle, AlertTriangle, User } from 'lucide-react';

interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  arrived: boolean;
  shelter?: string;
}

interface Family {
  id: number;
  headName: string;
  members: FamilyMember[];
  totalMembers: number;
  arrivedCount: number;
  shelters: string[];
}

export default function FamilyManagementScreen({ language }: { language: 'tr' | 'en' | 'ar' }) {
  const [families] = useState<Family[]>([
    {
      id: 1,
      headName: 'Mehmet Yılmaz',
      totalMembers: 4,
      arrivedCount: 4,
      shelters: ['Merkez Kadıköy Barınağı'],
      members: [
        { id: 'M1', name: 'Mehmet Yılmaz', relation: 'Head', arrived: true, shelter: 'Merkez Kadıköy Barınağı' },
        { id: 'M2', name: 'Ayşe Yılmaz', relation: 'Spouse', arrived: true, shelter: 'Merkez Kadıköy Barınağı' },
        { id: 'M3', name: 'Ali Yılmaz', relation: 'Son', arrived: true, shelter: 'Merkez Kadıköy Barınağı' },
        { id: 'M4', name: 'Zeynep Yılmaz', relation: 'Daughter', arrived: true, shelter: 'Merkez Kadıköy Barınağı' }
      ]
    },
    {
      id: 2,
      headName: 'Can Demir',
      totalMembers: 5,
      arrivedCount: 3,
      shelters: ['Beşiktaş Spor Salonu', 'Unknown'],
      members: [
        { id: 'D1', name: 'Can Demir', relation: 'Head', arrived: true, shelter: 'Beşiktaş Spor Salonu' },
        { id: 'D2', name: 'Fatma Demir', relation: 'Spouse', arrived: true, shelter: 'Beşiktaş Spor Salonu' },
        { id: 'D3', name: 'Ahmet Demir', relation: 'Son', arrived: false },
        { id: 'D4', name: 'Elif Demir', relation: 'Daughter', arrived: true, shelter: 'Beşiktaş Spor Salonu' },
        { id: 'D5', name: 'Yusuf Demir', relation: 'Son', arrived: false }
      ]
    },
    {
      id: 3,
      headName: 'Ali Kaya',
      totalMembers: 3,
      arrivedCount: 2,
      shelters: ['Merkez Kadıköy Barınağı', 'Şişli Kültür Merkezi'],
      members: [
        { id: 'K1', name: 'Ali Kaya', relation: 'Head', arrived: true, shelter: 'Merkez Kadıköy Barınağı' },
        { id: 'K2', name: 'Zehra Kaya', relation: 'Spouse', arrived: true, shelter: 'Şişli Kültür Merkezi' },
        { id: 'K3', name: 'Cem Kaya', relation: 'Son', arrived: false }
      ]
    }
  ]);

  const text = {
    tr: {
      title: 'Aile Yönetimi',
      subtitle: 'Aileleri bir arada tutun',
      totalFamilies: 'Toplam Aile',
      allArrived: 'Hepsi Geldi',
      partialArrived: 'Kısmen Geldi',
      scattered: 'Dağınık',
      family: 'Aile',
      members: 'Üyeler',
      arrived: 'Geldi',
      notArrived: 'Gelmedi',
      location: 'Konum',
      status: 'Durum',
      allTogether: 'Hepsi Bir Arada',
      separated: 'Ayrılmış',
      incomplete: 'Eksik',
      viewDetails: 'Detayları Gör'
    },
    en: {
      title: 'Family Management',
      subtitle: 'Keep families together',
      totalFamilies: 'Total Families',
      allArrived: 'All Arrived',
      partialArrived: 'Partial Arrived',
      scattered: 'Scattered',
      family: 'Family',
      members: 'Members',
      arrived: 'Arrived',
      notArrived: 'Not Arrived',
      location: 'Location',
      status: 'Status',
      allTogether: 'All Together',
      separated: 'Separated',
      incomplete: 'Incomplete',
      viewDetails: 'View Details'
    },
    ar: {
      title: 'إدارة العائلات',
      subtitle: 'إبقاء العائلات معاً',
      totalFamilies: 'إجمالي العائلات',
      allArrived: 'وصل الجميع',
      partialArrived: 'وصل جزئياً',
      scattered: 'متفرقون',
      family: 'العائلة',
      members: 'الأفراد',
      arrived: 'وصل',
      notArrived: 'لم يصل',
      location: 'الموقع',
      status: 'الحالة',
      allTogether: 'معاً',
      separated: 'منفصلون',
      incomplete: 'ناقص',
      viewDetails: 'عرض التفاصيل'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const stats = {
    total: families.length,
    allArrived: families.filter(f => f.arrivedCount === f.totalMembers && f.shelters.length === 1).length,
    partialArrived: families.filter(f => f.arrivedCount < f.totalMembers).length,
    scattered: families.filter(f => f.shelters.length > 1).length
  };

  const getFamilyStatus = (family: Family) => {
    if (family.arrivedCount === family.totalMembers && family.shelters.length === 1) {
      return { label: t.allTogether, color: 'green' };
    }
    if (family.shelters.length > 1) {
      return { label: t.separated, color: 'orange' };
    }
    return { label: t.incomplete, color: 'red' };
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900">{t.title}</h1>
          <p className="text-gray-600 mt-1">{t.subtitle}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.totalFamilies}</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-50 rounded-xl flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.allArrived}</p>
                <p className="text-2xl font-bold text-green-600">{stats.allArrived}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center">
                <XCircle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.partialArrived}</p>
                <p className="text-2xl font-bold text-red-600">{stats.partialArrived}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 border border-gray-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-orange-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600">{t.scattered}</p>
                <p className="text-2xl font-bold text-orange-600">{stats.scattered}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Families List */}
        <div className="space-y-4">
          {families.map(family => {
            const status = getFamilyStatus(family);
            const statusColors = {
              green: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-200' },
              orange: { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-orange-200' },
              red: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-200' }
            };
            const colors = statusColors[status.color];

            return (
              <div key={family.id} className={`bg-white rounded-2xl border-2 ${colors.border} overflow-hidden`}>
                {/* Header */}
                <div className={`${colors.bg} p-6 border-b ${colors.border}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center shadow-sm">
                        <Users className={`w-8 h-8 ${colors.text}`} />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">{family.headName} {t.family}</h3>
                        <p className="text-sm text-gray-600 mt-1">
                          {family.arrivedCount} / {family.totalMembers} {t.members} {t.arrived}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`inline-block px-4 py-2 rounded-full text-sm font-bold ${colors.bg} ${colors.text} border-2 ${colors.border}`}>
                        {status.label}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Members */}
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {family.members.map(member => (
                      <div
                        key={member.id}
                        className={`p-4 rounded-xl border-2 ${
                          member.arrived ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-gray-50'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                            member.arrived ? 'bg-green-100' : 'bg-gray-200'
                          }`}>
                            {member.arrived ? (
                              <CheckCircle className="w-6 h-6 text-green-600" />
                            ) : (
                              <XCircle className="w-6 h-6 text-gray-500" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-gray-900 mb-1">{member.name}</h4>
                            <p className="text-xs text-gray-600 mb-2">{member.relation}</p>
                            {member.arrived && member.shelter ? (
                              <div className="flex items-center gap-1 text-xs text-green-700">
                                <MapPin className="w-3 h-3" />
                                <span className="truncate">{member.shelter}</span>
                              </div>
                            ) : (
                              <span className="text-xs text-red-600 font-semibold">{t.notArrived}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Shelter Summary */}
                  {family.shelters.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <h4 className="text-sm font-semibold text-gray-700 mb-2">{t.location}:</h4>
                      <div className="flex flex-wrap gap-2">
                        {family.shelters.map((shelter, idx) => (
                          <span
                            key={idx}
                            className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              shelter === 'Unknown'
                                ? 'bg-gray-100 text-gray-600'
                                : family.shelters.length > 1
                                ? 'bg-orange-100 text-orange-700'
                                : 'bg-green-100 text-green-700'
                            }`}
                          >
                            <MapPin className="w-3 h-3 inline mr-1" />
                            {shelter}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
