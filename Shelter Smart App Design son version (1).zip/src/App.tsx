import { useState } from 'react';
import { Home, Map, CreditCard, AlertCircle, Users } from 'lucide-react';
import HomeScreen from './components/HomeScreen';
import SheltersMapScreen from './components/SheltersMapScreen';
import SmartCardScreen from './components/SmartCardScreen';
import SOSScreen from './components/SOSScreen';
import FamilyScreen from './components/FamilyScreen';
import WelcomeScreen from './components/WelcomeScreen';
import LoginScreen from './components/LoginScreen';
import RegistrationScreen from './components/RegistrationScreen';
import NavigationRouteScreen from './components/NavigationRouteScreen';
import InternalMapScreen from './components/InternalMapScreen';
import SafetyGuidanceScreen from './components/SafetyGuidanceScreen';
import OfflineModeScreen from './components/OfflineModeScreen';
import SettingsScreen from './components/SettingsScreen';
import OnlineStatusNotification from './components/OnlineStatusNotification';

// User data interface
export interface UserData {
  fullName: string;
  userId: string;
  phoneNumber: string;
  countryCode: string;
  password: string;
  homeAddress: string;
  currentLocation: string;
  familyMembers: number;
  hasChildren: boolean;
  childrenCount: number;
  hasPets: boolean;
  status: 'inside-shelter' | 'outside-shelter';
  assignedShelter: string;
  shelterRoom: string;
  nearestShelter: {
    name: string;
    distance: string;
    capacity: number;
    currentOccupancy: number;
    status: 'open' | 'full' | 'closed';
  };
}

export default function App() {
  const [currentTab, setCurrentTab] = useState('home');
  const [currentScreen, setCurrentScreen] = useState('home');
  const [authScreen, setAuthScreen] = useState<'welcome' | 'login' | 'register' | null>('welcome');
  const [isRegistered, setIsRegistered] = useState(false);
  const [language, setLanguage] = useState<'tr' | 'en' | 'ar'>('tr');
  
  // Dynamic user data
  const [userData, setUserData] = useState<UserData>({
    fullName: 'Ahmet Yılmaz',
    userId: 'SS-2024-123456',
    phoneNumber: '555 123 4567',
    countryCode: '+90',
    password: '******',
    homeAddress: 'Kadıköy, İstanbul',
    currentLocation: 'Kadıköy Merkez',
    familyMembers: 4,
    hasChildren: true,
    childrenCount: 2,
    hasPets: false,
    status: 'outside-shelter',
    assignedShelter: 'Merkez Kadıköy Barınağı',
    shelterRoom: 'A-204',
    nearestShelter: {
      name: 'Merkez Kadıköy Barınağı',
      distance: '2.3 km',
      capacity: 500,
      currentOccupancy: 324,
      status: 'open'
    }
  });

  const navigateTo = (screen: string) => {
    setCurrentScreen(screen);
  };

  const handleRegistrationComplete = (registrationData: Partial<UserData>) => {
    setUserData({ ...userData, ...registrationData });
    setIsRegistered(true);
    setCurrentScreen('home');
    setCurrentTab('home');
  };

  const handleUpdateUser = (updates: Partial<UserData>) => {
    setUserData({ ...userData, ...updates });
  };

  const handleLanguageChange = (lang: 'tr' | 'en' | 'ar') => {
    setLanguage(lang);
  };

  if (!isRegistered) {
    return <RegistrationScreen onComplete={handleRegistrationComplete} language={language} onLanguageChange={handleLanguageChange} />;
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen onNavigate={navigateTo} userData={userData} language={language} onLanguageChange={handleLanguageChange} />;
      case 'sheltersmap':
        return <SheltersMapScreen onNavigate={navigateTo} userData={userData} language={language} />;
      case 'smartcard':
        return <SmartCardScreen userData={userData} language={language} />;
      case 'sos':
        return <SOSScreen onNavigate={navigateTo} userData={userData} language={language} />;
      case 'family':
        return <FamilyScreen onNavigate={navigateTo} userData={userData} onUpdateUser={handleUpdateUser} language={language} />;
      case 'navigation':
        return <NavigationRouteScreen onBack={() => setCurrentScreen('sheltersmap')} userData={userData} language={language} />;
      case 'internalmap':
        return <InternalMapScreen onBack={() => setCurrentScreen('home')} userData={userData} language={language} />;
      case 'safety':
        return <SafetyGuidanceScreen onBack={() => setCurrentScreen('home')} language={language} />;
      case 'offline':
        return <OfflineModeScreen onBack={() => setCurrentScreen('home')} userData={userData} language={language} />;
      case 'settings':
        return <SettingsScreen 
          onBack={() => setCurrentScreen('home')} 
          userData={userData} 
          language={language} 
          onLanguageChange={handleLanguageChange}
          onLogout={() => {
            setIsRegistered(false);
            setCurrentScreen('home');
            setCurrentTab('home');
          }}
        />;
      default:
        return <HomeScreen onNavigate={navigateTo} userData={userData} language={language} onLanguageChange={handleLanguageChange} />;
    }
  };

  const handleTabChange = (tab: string) => {
    setCurrentTab(tab);
    setCurrentScreen(tab);
  };

  const labels = {
    tr: {
      home: 'Ana Sayfa',
      sheltersmap: 'Barınak Haritası',
      smartcard: 'Akıllı Kart',
      sos: 'SOS',
      family: 'Aile'
    },
    en: {
      home: 'Home',
      sheltersmap: 'Shelters Map',
      smartcard: 'Smart Card',
      sos: 'SOS',
      family: 'Family'
    },
    ar: {
      home: 'الصفحة الرئيسية',
      sheltersmap: 'خريطة المأوى',
      smartcard: 'بطاقة ذكية',
      sos: 'طوارئ',
      family: 'عائلة'
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      {/* Online Status Notification */}
      <OnlineStatusNotification language={language} />
      
      {/* Mobile Container */}
      <div className="w-full max-w-[390px] h-[844px] bg-white rounded-[40px] shadow-2xl overflow-hidden flex flex-col relative">
        {/* Screen Content */}
        <div className="flex-1 overflow-y-auto">
          {renderScreen()}
        </div>

        {/* Bottom Navigation */}
        <nav className="bg-white border-t border-gray-200 px-2 py-2 safe-area-bottom">
          <div className="flex items-center justify-around">
            <NavButton
              icon={<Home className="w-6 h-6" />}
              label={labels[language].home}
              active={currentTab === 'home'}
              onClick={() => handleTabChange('home')}
            />
            <NavButton
              icon={<Map className="w-6 h-6" />}
              label={labels[language].sheltersmap}
              active={currentTab === 'sheltersmap'}
              onClick={() => handleTabChange('sheltersmap')}
            />
            <NavButton
              icon={<CreditCard className="w-6 h-6" />}
              label={labels[language].smartcard}
              active={currentTab === 'smartcard'}
              onClick={() => handleTabChange('smartcard')}
            />
            <NavButton
              icon={<AlertCircle className="w-6 h-6" />}
              label={labels[language].sos}
              active={currentTab === 'sos'}
              onClick={() => handleTabChange('sos')}
              isEmergency
            />
            <NavButton
              icon={<Users className="w-6 h-6" />}
              label={labels[language].family}
              active={currentTab === 'family'}
              onClick={() => handleTabChange('family')}
            />
          </div>
        </nav>
      </div>
    </div>
  );
}

function NavButton({ 
  icon, 
  label, 
  active, 
  onClick, 
  isEmergency = false 
}: { 
  icon: React.ReactNode; 
  label: string; 
  active: boolean; 
  onClick: () => void;
  isEmergency?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center justify-center py-2 px-3 rounded-lg transition-all ${
        active
          ? isEmergency
            ? 'text-red-600'
            : 'text-blue-600'
          : 'text-gray-400'
      }`}
    >
      {icon}
      <span className="text-[10px] mt-1 font-medium">{label}</span>
    </button>
  );
}