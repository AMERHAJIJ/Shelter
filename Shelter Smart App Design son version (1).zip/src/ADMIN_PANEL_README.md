# 🖥️ Shelter Smart - Admin Panel (Web)

## 📋 Overview

This is the **Admin Panel** for the Shelter Smart system - a complete web-based management dashboard for **administrators and staff** to manage shelters during emergencies.

---

## 🚨 **IMPORTANT: Files Separation**

### ✅ **Admin Panel Files (NEW - Safe to modify)**
```
/admin-components/          ← All admin UI components
/AdminApp.tsx              ← Admin app entry point
/ADMIN_PANEL_README.md     ← This file
```

### 🔒 **Mobile App Files (DO NOT TOUCH)**
```
/components/               ← Mobile app components
/App.tsx                   ← Mobile app entry point
/utils/                    ← Mobile app utilities
```

**The mobile app and admin panel are COMPLETELY SEPARATE!**

---

## 📱 vs 🖥️ Comparison

| Feature | Mobile App | Admin Panel |
|---------|-----------|-------------|
| **Users** | Citizens | Admin/Staff |
| **Purpose** | Find shelter, get help | Manage shelters, respond to emergencies |
| **Auth** | Phone + Password | Username + Password + Role |
| **Main Features** | QR Card, SOS, Family | Dashboard, Capacity, Emergency Management |
| **Location** | `/App.tsx`, `/components/` | `/AdminApp.tsx`, `/admin-components/` |

---

## 🎯 Admin Panel Features

### ✅ **Completed Screens:**

#### 1️⃣ **Admin Login Screen** ✅
- Username/Password authentication
- Role selection (Admin vs Staff)
- Demo credentials: `admin/123456` or `staff/123456`
- 3 language support (TR/EN/AR)

#### 2️⃣ **Dashboard** ✅
- **Overview Stats:**
  - Total people in shelters
  - Active shelters count
  - Emergency requests (SOS, Ambulance, Transfer)
  - Capacity usage percentage
- **Shelters Status:**
  - Real-time capacity monitoring
  - Open/Closed/Full status
  - Quick access to details
- **Emergency Requests Summary:**
  - SOS requests count
  - Ambulance requests
  - Transfer requests
- **Quick Actions:**
  - Manage Shelters
  - Manage Capacity
  - Emergency Management
  - Family Management

#### 3️⃣ **Manage Shelters Screen** ✅
- **View all shelters** in table format
- **Add new shelter** functionality
- **Edit/Delete** shelters
- **Toggle shelter status** (Open/Closed)
- **Link small shelters** to main shelters
- **Real-time capacity** display with visual progress bars
- **Filter by type** (Main/Small)
- **Summary statistics**

---

### 🚧 **Remaining Screens (To Be Built):**

#### 4️⃣ **Manage Capacity Screen**
- Divide shelter into sections (Families, Individuals, Children, Special Needs, Unregistered)
- Set max capacity per section
- Real-time counter (increases on entry, decreases on exit via QR)
- Auto-suggest alternative shelters when full

#### 5️⃣ **Emergency Requests Screen**
- List of all emergency requests (SOS, Ambulance, Transfer)
- Map view of request locations
- Request status (New, In Progress, Completed)
- Priority assignment
- Response team coordination

#### 6️⃣ **QR Logs Screen**
- Entry/Exit logs from QR scans
- Timestamp, Shelter, Section, Person count
- Auto-update capacity counters
- Search and filter functionality

#### 7️⃣ **Family Management Screen**
- View registered families
- Track who arrived and who hasn't
- Show which shelter family members are in
- Prevent family separation

#### 8️⃣ **Unregistered Management Screen**
- Manually enter unregistered people count
- Assign to specific section
- Update capacity accordingly
- Handle emergency walk-ins

#### 9️⃣ **Resource Management Screen**
- Track resources per shelter (Water, Medicine, Blankets)
- Resource status (Sufficient, Low, Depleted)
- Request new resources
- Logistics support

#### 🔟 **Send Notifications Screen**
- Send push notifications to mobile app users
- Notification types: Shelter opening/closing, Earthquake alert, Instructions
- Target by: Region, User type
- Scheduled notifications

---

## 🎨 Design System

### Colors:
- **Admin Role**: Blue (`bg-blue-600`)
- **Staff Role**: Green (`bg-green-600`)
- **Emergency/Alert**: Red (`bg-red-600`)
- **Warning**: Orange (`bg-orange-500`)
- **Success**: Green (`bg-green-500`)

### Components:
- **StatCard**: Dashboard statistics with icons
- **ShelterCard**: Shelter info with capacity bar
- **EmergencyCard**: Emergency request summary
- **QuickActionButton**: Quick navigation buttons

---

## 🌍 Language Support

All admin screens support **3 languages**:
- 🇹🇷 Turkish (Default)
- 🇬🇧 English
- 🇸🇦 Arabic (with RTL support)

---

## 🔐 Authentication

### Demo Accounts:
```
Admin Account:
  Username: admin
  Password: 123456
  Access: Full system access

Staff Account:
  Username: staff
  Password: 123456
  Access: Limited to assigned shelter
```

### Production:
- Integrate with backend API
- JWT token authentication
- Role-based access control (RBAC)
- Password hashing (bcrypt)

---

## 📊 Data Flow

### Mobile App → Admin Panel:
1. User scans QR → Entry/Exit logged
2. User sends SOS → Appears in Emergency Requests
3. User registers family → Visible in Family Management

### Admin Panel → Mobile App:
1. Admin opens/closes shelter → Mobile app updates shelter list
2. Admin sends notification → Mobile app receives push
3. Admin updates capacity → Mobile app suggests alternatives

---

## 🚀 How to Use

### For Development:

#### **Option 1: Switch Entry Point**
In your build config, change entry point:
- Mobile App: `/App.tsx`
- Admin Panel: `/AdminApp.tsx`

#### **Option 2: Different Routes**
```typescript
// In main routing file
if (window.location.pathname.startsWith('/admin')) {
  render(<AdminApp />)
} else {
  render(<App />)
}
```

### For Production:

#### **Option 1: Separate Deployments**
- Mobile: `app.sheltersmart.com` → `/App.tsx`
- Admin: `admin.sheltersmart.com` → `/AdminApp.tsx`

#### **Option 2: Subdomain Routing**
- Users: `sheltersmart.com` → Mobile App
- Admins: `sheltersmart.com/admin` → Admin Panel

---

## 📦 File Structure

```
/
├── App.tsx                          ← Mobile App (DO NOT TOUCH)
├── AdminApp.tsx                     ← Admin Panel Entry Point ✅
├── components/                      ← Mobile App Components (DO NOT TOUCH)
│   ├── HomeScreen.tsx
│   ├── SOSScreen.tsx
│   ├── FamilyScreen.tsx
│   └── ... (15 mobile screens)
├── admin-components/                ← Admin Panel Components ✅
│   ├── AdminLoginScreen.tsx         ✅ Complete
│   ├── AdminDashboard.tsx           ✅ Complete
│   ├── ManageSheltersScreen.tsx     ✅ Complete
│   ├── ManageCapacityScreen.tsx     🚧 To build
│   ├── EmergencyRequestsScreen.tsx  🚧 To build
│   ├── QRLogsScreen.tsx             🚧 To build
│   ├── FamilyManagementScreen.tsx   🚧 To build
│   ├── UnregisteredScreen.tsx       🚧 To build
│   ├── ResourceManagementScreen.tsx 🚧 To build
│   └── NotificationsScreen.tsx      🚧 To build
├── utils/                           ← Shared utilities
└── ADMIN_PANEL_README.md            ← This file
```

---

## ✅ Progress Tracker

### Overall: **3/11 Screens (27%)** 🚧

| Screen | Status | Priority | Notes |
|--------|--------|----------|-------|
| Login | ✅ Complete | HIGH | Working with demo auth |
| Dashboard | ✅ Complete | HIGH | Stats, overview, quick actions |
| Manage Shelters | ✅ Complete | HIGH | CRUD, status toggle |
| Manage Capacity | 🚧 To Build | HIGH | Core feature |
| Emergency Requests | 🚧 To Build | HIGH | Critical for response |
| QR Logs | 🚧 To Build | MEDIUM | Tracking |
| Family Management | 🚧 To Build | MEDIUM | Family reunification |
| Unregistered | 🚧 To Build | LOW | Edge cases |
| Resources | 🚧 To Build | MEDIUM | Logistics |
| Notifications | 🚧 To Build | MEDIUM | Communication |
| Settings | 🚧 To Build | LOW | Admin preferences |

---

## 🎯 Next Steps

1. **Build Capacity Management** ← Most important
2. **Build Emergency Requests** ← Critical for operations
3. **Build QR Logs** ← Auto-update capacity
4. **Build Family Management** ← Keep families together
5. **Build Notifications** ← Communication with users
6. **Build Resources** ← Logistics support
7. **Build Unregistered** ← Handle walk-ins
8. **Backend Integration** ← Connect to real API
9. **Testing** ← Full system testing
10. **Deployment** ← Go live!

---

## 🔒 Security Notes

- ✅ Separate authentication from mobile app
- ✅ Role-based access (Admin vs Staff)
- 🚧 Need to add: API authentication
- 🚧 Need to add: Session management
- 🚧 Need to add: Audit logs
- 🚧 Need to add: Data encryption

---

## 📞 Support

For questions or issues:
1. Check this README
2. Review component code in `/admin-components`
3. Ensure you're not modifying `/components` (mobile app)

---

## 🎉 Summary

**Admin Panel is LIVE and WORKING!**

✅ **Working Features:**
- Admin/Staff login with demo accounts
- Beautiful dashboard with stats
- Shelter management (view, add, edit, toggle)
- 3 language support (TR/EN/AR)
- Complete separation from mobile app

🚧 **Next Phase:**
- Build remaining 8 screens
- Backend integration
- Testing & deployment

**The mobile app is 100% safe and untouched!** 🔒
