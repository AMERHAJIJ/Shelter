import { useState } from 'react';
import { LayoutDashboard, Building2, Activity, AlertCircle, QrCode, Users, UserX, Package, Bell, Settings, LogOut, Menu, X } from 'lucide-react';
import AdminLoginScreen from './admin-components/AdminLoginScreen';
import AdminDashboard from './admin-components/AdminDashboard';
import ManageSheltersScreen from './admin-components/ManageSheltersScreen';
import ManageCapacityScreen from './admin-components/ManageCapacityScreen';
import EmergencyRequestsScreen from './admin-components/EmergencyRequestsScreen';
import QRLogsScreen from './admin-components/QRLogsScreen';
import FamilyManagementScreen from './admin-components/FamilyManagementScreen';
import UnregisteredScreen from './admin-components/UnregisteredScreen';
import ResourceManagementScreen from './admin-components/ResourceManagementScreen';
import NotificationsScreen from './admin-components/NotificationsScreen';

export default function AdminApp() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'staff'>('admin');
  const [username, setUsername] = useState('');
  const [language, setLanguage] = useState<'tr' | 'en' | 'ar'>('tr');
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogin = (role: 'admin' | 'staff', user: string) => {
    setUserRole(role);
    setUsername(user);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setCurrentPage('dashboard');
  };

  const text = {
    tr: {
      dashboard: 'Kontrol Paneli',
      shelters: 'Barınaklar',
      capacity: 'Kapasite',
      emergency: 'Acil Durum',
      qrLogs: 'QR Kayıtları',
      families: 'Aileler',
      unregistered: 'Kayıtsız',
      resources: 'Kaynaklar',
      notifications: 'Bildirimler',
      settings: 'Ayarlar',
      logout: 'Çıkış'
    },
    en: {
      dashboard: 'Dashboard',
      shelters: 'Shelters',
      capacity: 'Capacity',
      emergency: 'Emergency',
      qrLogs: 'QR Logs',
      families: 'Families',
      unregistered: 'Unregistered',
      resources: 'Resources',
      notifications: 'Notifications',
      settings: 'Settings',
      logout: 'Logout'
    },
    ar: {
      dashboard: 'لوحة التحكم',
      shelters: 'المآوي',
      capacity: 'السعة',
      emergency: 'الطوارئ',
      qrLogs: 'سجلات QR',
      families: 'العائلات',
      unregistered: 'غير المسجلين',
      resources: 'الموارد',
      notifications: 'الإشعارات',
      settings: 'الإعدادات',
      logout: 'تسجيل خروج'
    }
  };

  const t = text[language];
  const isRTL = language === 'ar';

  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard, color: 'blue' },
    { id: 'shelters', label: t.shelters, icon: Building2, color: 'green' },
    { id: 'capacity', label: t.capacity, icon: Activity, color: 'purple' },
    { id: 'emergency', label: t.emergency, icon: AlertCircle, color: 'red' },
    { id: 'qr-logs', label: t.qrLogs, icon: QrCode, color: 'indigo' },
    { id: 'families', label: t.families, icon: Users, color: 'pink' },
    { id: 'unregistered', label: t.unregistered, icon: UserX, color: 'gray' },
    { id: 'resources', label: t.resources, icon: Package, color: 'orange' },
    { id: 'notifications', label: t.notifications, icon: Bell, color: 'yellow' }
  ];

  if (!isLoggedIn) {
    return <AdminLoginScreen onLogin={handleLogin} language={language} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <AdminDashboard role={userRole} username={username} language={language} onNavigate={setCurrentPage} />;
      case 'shelters':
        return <ManageSheltersScreen language={language} onBack={() => setCurrentPage('dashboard')} />;
      case 'capacity':
        return <ManageCapacityScreen language={language} shelterId={1} />;
      case 'emergency':
        return <EmergencyRequestsScreen language={language} />;
      case 'qr-logs':
        return <QRLogsScreen language={language} />;
      case 'families':
        return <FamilyManagementScreen language={language} />;
      case 'unregistered':
        return <UnregisteredScreen language={language} />;
      case 'resources':
        return <ResourceManagementScreen language={language} />;
      case 'notifications':
        return <NotificationsScreen language={language} />;
      default:
        return <AdminDashboard role={userRole} username={username} language={language} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50" dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-white border-${isRTL ? 'l' : 'r'} border-gray-200 transition-all duration-300 flex flex-col`}>
        {/* Logo & Toggle */}
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          {sidebarOpen && (
            <div className="flex items-center gap-2">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                userRole === 'admin' ? 'bg-blue-600' : 'bg-green-600'
              }`}>
                <LayoutDashboard className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-gray-900 text-sm">Shelter Smart</h2>
                <p className={`text-xs ${userRole === 'admin' ? 'text-blue-600' : 'text-green-600'}`}>
                  {userRole === 'admin' ? 'Admin' : 'Staff'}
                </p>
              </div>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Menu Items */}
        <div className="flex-1 overflow-y-auto py-4">
          {menuItems.map(item => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 transition-colors ${
                  isActive
                    ? `bg-${item.color}-50 text-${item.color}-600 border-${isRTL ? 'l' : 'r'}-4 border-${item.color}-600`
                    : 'text-gray-600 hover:bg-gray-50'
                } ${!sidebarOpen && 'justify-center'}`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && <span className="font-semibold text-sm">{item.label}</span>}
              </button>
            );
          })}
        </div>

        {/* User & Logout */}
        <div className="p-4 border-t border-gray-200">
          {sidebarOpen && (
            <div className="mb-3 p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-1">Logged in as</p>
              <p className="font-bold text-gray-900 text-sm">{username}</p>
            </div>
          )}

          {/* Language Switcher */}
          {sidebarOpen && (
            <div className="mb-3">
              <div className="flex gap-2">
                <button
                  onClick={() => setLanguage('tr')}
                  className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
                    language === 'tr' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  TR
                </button>
                <button
                  onClick={() => setLanguage('en')}
                  className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
                    language === 'en' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  EN
                </button>
                <button
                  onClick={() => setLanguage('ar')}
                  className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
                    language === 'ar' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  AR
                </button>
              </div>
            </div>
          )}

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            {sidebarOpen && <span className="font-semibold text-sm">{t.logout}</span>}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        {renderPage()}
      </div>
    </div>
  );
}
