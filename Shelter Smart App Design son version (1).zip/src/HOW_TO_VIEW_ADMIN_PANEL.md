# 🖥️ كيفية عرض الموقع الإداري (Admin Panel)

## ✅ **الوضع الحالي:**

### 📱 **التطبيق الأصلي (Mobile App):**
- ✅ موجود في `/App.tsx`
- ✅ 100% سليم ولم نلمسه
- ✅ 15 شاشة كاملة
- ✅ جاهز للاستخدام

### 🖥️ **الموقع الإداري (Admin Panel):**
- ✅ موجود في `/AdminApp.tsx`
- ✅ 10 صفحات كاملة ومنفصلة تماماً
- ✅ جاهز للاستخدام
- ✅ **يحتاج فقط تغيير نقطة الدخول!**

---

## 🚀 **طريقة عرض الموقع الإداري:**

### **الطريقة 1: تغيير Entry Point (الأسرع)**

#### **في ملف `index.tsx` أو `main.tsx` أو أي ملف البداية:**

```typescript
// الطريقة القديمة (التطبيق):
import App from './App';

// الطريقة الجديدة (الموقع الإداري):
import AdminApp from './AdminApp';

// ثم في الـ render:
root.render(<AdminApp />);  // بدلاً من <App />
```

---

### **الطريقة 2: استخدام Routing (الأفضل)**

#### **إذا عندك React Router:**

```typescript
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App';
import AdminApp from './AdminApp';

function Main() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/admin/*" element={<AdminApp />} />
      </Routes>
    </BrowserRouter>
  );
}
```

**بعدها:**
- التطبيق: `http://localhost:3000/`
- الموقع الإداري: `http://localhost:3000/admin`

---

### **الطريقة 3: شرط بسيط (سريع وسهل)**

#### **في ملف الـ Entry Point:**

```typescript
import App from './App';
import AdminApp from './AdminApp';

function Main() {
  // إذا في الـ URL كلمة "admin"
  const isAdmin = window.location.pathname.includes('/admin');
  
  return isAdmin ? <AdminApp /> : <App />;
}

export default Main;
```

**بعدها:**
- التطبيق: `http://localhost:3000/`
- الموقع الإداري: `http://localhost:3000/admin`

---

## 🔐 **معلومات تسجيل الدخول (Demo):**

### **حساب Admin (صلاحيات كاملة):**
```
Username: admin
Password: 123456
```

### **حساب Staff (صلاحيات محدودة):**
```
Username: staff
Password: 123456
```

---

## 📂 **هيكل الملفات:**

```
/
├── App.tsx                          ← التطبيق الأصلي (لا تلمسه!)
├── AdminApp.tsx                     ← الموقع الإداري (جديد!)
├── admin.html                       ← صفحة معلومات (جديد!)
│
├── components/                      ← التطبيق الأصلي (15 ملف)
│   ├── HomeScreen.tsx
│   ├── SOSScreen.tsx
│   └── ... (محمي!)
│
└── admin-components/                ← الموقع الإداري (10 ملفات)
    ├── AdminLoginScreen.tsx         ✅
    ├── AdminDashboard.tsx           ✅
    ├── ManageSheltersScreen.tsx     ✅
    ├── ManageCapacityScreen.tsx     ✅
    ├── EmergencyRequestsScreen.tsx  ✅
    ├── QRLogsScreen.tsx             ✅
    ├── FamilyManagementScreen.tsx   ✅
    ├── UnregisteredScreen.tsx       ✅
    ├── ResourceManagementScreen.tsx ✅
    └── NotificationsScreen.tsx      ✅
```

---

## ✨ **ميزات الموقع الإداري:**

### **1️⃣ Login Screen (تسجيل الدخول)**
- Username + Password
- اختيار الدور (Admin/Staff)
- 3 لغات (TR/EN/AR)

### **2️⃣ Dashboard (لوحة التحكم)**
- إحصائيات مباشرة
- عدد الأشخاص الإجمالي
- الملاجئ النشطة
- طلبات الطوارئ
- استخدام السعة

### **3️⃣ Manage Shelters (إدارة الملاجئ)**
- عرض جميع الملاجئ
- إضافة/تعديل/حذف
- فتح/إغلاق الملاجئ
- ربط الملاجئ الصغيرة بالرئيسية

### **4️⃣ Manage Capacity (إدارة السعة)**
- تقسيم لأقسام (عائلات، أفراد، أطفال، إلخ)
- عداد مباشر
- تحديث تلقائي عبر QR
- Progress bars ملونة

### **5️⃣ Emergency Requests (طلبات الطوارئ)**
- SOS / Ambulance / Transfer
- خريطة المواقع
- حالة الطلب
- اتصال مباشر

### **6️⃣ QR Logs (سجلات QR)**
- دخول/خروج
- الوقت والملجأ
- عدد الأشخاص
- تحديث السعة التلقائي

### **7️⃣ Family Management (إدارة العائلات)**
- تتبع أفراد العائلة
- من وصل ومن لم يصل
- منع التشتت
- لم الشمل

### **8️⃣ Unregistered (غير المسجلين)**
- إضافة وافدين جدد
- إدخال يدوي
- تحديث السعة

### **9️⃣ Resources (الموارد)**
- ماء، أدوية، بطانيات، طعام
- حالة الموارد (كافي/قليل/منتهي)
- طلب إمدادات

### **🔟 Notifications (الإشعارات)**
- إرسال للتطبيق
- أنواع: فتح ملجأ، إغلاق، تنبيه زلزال، تعليمات
- تحديد المنطقة والمستخدمين

---

## 🎨 **التصميم:**

- ✅ Sidebar navigation مع أيقونات
- ✅ ألوان مميزة لكل قسم
- ✅ Responsive design
- ✅ RTL support للعربية
- ✅ Dark mode ready
- ✅ Professional UI/UX

---

## 📊 **الإحصائيات:**

| القسم | الحالة | الملفات |
|-------|--------|---------|
| **التطبيق الأصلي** | ✅ 100% | 15 ملف |
| **الموقع الإداري** | ✅ 100% | 10 ملفات |
| **المجموع** | ✅ مكتمل | 25 ملف |

---

## 🔒 **الأمان:**

- ✅ فصل كامل بين التطبيق والموقع
- ✅ لا تداخل نهائياً
- ✅ التطبيق الأصلي محمي 100%
- ✅ كل شيء منظم ومرتب

---

## 🎯 **الخطوات السريعة:**

### **للمطور:**

1. **افتح ملف البداية** (`index.tsx` أو `main.tsx`)

2. **غير السطر:**
   ```typescript
   // من هذا:
   import App from './App';
   
   // إلى هذا:
   import AdminApp from './AdminApp';
   ```

3. **غير الـ render:**
   ```typescript
   // من هذا:
   root.render(<App />);
   
   // إلى هذا:
   root.render(<AdminApp />);
   ```

4. **شغل المشروع:**
   ```bash
   npm start
   # أو
   yarn start
   ```

5. **سجل دخول:**
   - Username: `admin`
   - Password: `123456`

6. **استمتع! 🎉**

---

## 🔄 **للرجوع للتطبيق الأصلي:**

ببساطة، ارجع الملف للحالة الأصلية:

```typescript
import App from './App';
root.render(<App />);
```

---

## 💡 **ملاحظات مهمة:**

1. ✅ **التطبيق الأصلي سليم 100%**
2. ✅ **الموقع الإداري جاهز 100%**
3. ✅ **لا تداخل بينهما**
4. ✅ **كل شيء منظم في مجلدات منفصلة**
5. ✅ **دعم 3 لغات (TR/EN/AR)**

---

## 🎊 **النتيجة:**

**الآن عندك:**
- 📱 **تطبيق موبايل كامل** (15 شاشة)
- 🖥️ **موقع إداري كامل** (10 صفحات)
- 🌍 **دعم 3 لغات**
- 🎨 **تصميم احترافي**
- 🔒 **فصل تام**

---

## 📞 **المساعدة:**

إذا احتجت مساعدة:
1. تأكد أنك غيرت نقطة الدخول
2. تأكد أنك استوردت `AdminApp` بدل `App`
3. استخدم Demo credentials: `admin/123456`

---

## 🚀 **جاهز للانطلاق!**

**الموقع الإداري كامل ومنفصل!**  
**فقط غير نقطة الدخول وشغله!** 🎉
